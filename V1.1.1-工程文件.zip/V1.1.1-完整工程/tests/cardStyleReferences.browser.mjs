import assert from "node:assert/strict";
import { chromium, expect } from "@playwright/test";

const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 1500, height: 1100 } });
  const errors = [];
  page.on("pageerror", error => errors.push(error.message));
  await page.goto(process.env.EA_CARD_STYLES_URL);
  await expect(page.locator(".design")).toHaveCount(4);
  await expect(page.locator(".card")).toHaveCount(8);
  for (const width of ["1300", "1100"]) {
    await page.locator(`[data-width="${width}"]`).click();
    await expect(page.locator(`[data-width="${width}"]`)).toHaveAttribute("aria-pressed", "true");
    for (const card of await page.locator(".card").all()) {
      await expect(card.locator("[data-metric]")).toHaveCount(4);
      assert.deepEqual((await card.locator("[data-metric]").evaluateAll(elements => elements.map(element => element.dataset.metric))).sort(), ["0","1","2","3"]);
      const failures = await card.evaluate(element => {
        const bounds = element.getBoundingClientRect();
        return Array.from(element.querySelectorAll(".metric")).flatMap(metric => {
          const label = metric.querySelector("dt"), value = metric.querySelector("dd");
          const m = metric.getBoundingClientRect(), l = label.getBoundingClientRect(), v = value.getBoundingClientRect();
          const overlap = Math.min(l.right, v.right) - Math.max(l.left, v.left) > 1 && Math.min(l.bottom, v.bottom) - Math.max(l.top, v.top) > 1;
          return m.right > bounds.right + 1 || m.left < bounds.left - 1 || value.scrollWidth > value.clientWidth + 1 || label.scrollWidth > label.clientWidth + 1 || overlap ? [label.textContent] : [];
        });
      });
      assert.deepEqual(failures, [], `${await card.getAttribute("aria-label")} at ${width}`);
    }
    assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    for (const selector of [".status", ".people > span:first-child", ".relations"]) {
      const positions = await page.locator(`.scheme-c ${selector}`).evaluateAll(elements => elements.map(element => element.getBoundingClientRect().x));
      assert.ok(Math.max(...positions) - Math.min(...positions) < 1, `${selector} aligns across C cards at ${width}`);
    }
    for (const card of await page.locator(".scheme-c").all()) {
      const layout = await card.evaluate(element => {
        const info = element.querySelector(".meta").getBoundingClientRect();
        const people = element.querySelector(".people").getBoundingClientRect();
        const title = element.querySelector(".name").getBoundingClientRect();
        const peopleFields = Array.from(element.querySelectorAll(".people > span"), node => node.getBoundingClientRect());
        const metrics = element.querySelector(".metric-grid").getBoundingClientRect();
        return { separated: info.right <= people.left, sameRow: Math.abs(info.y + info.height / 2 - people.y - people.height / 2) < 1,
          inline: peopleFields[0].right <= peopleFields[1].left, titleInInfoRow: title.top >= info.top && title.bottom <= info.bottom, metricsSecond: metrics.top >= Math.max(info.bottom, people.bottom), metricHeight: metrics.height, cardHeight: element.getBoundingClientRect().height,
          fits: Array.from(element.querySelectorAll(".people, .relations")).every(node => node.scrollWidth <= node.clientWidth) };
      });
      assert.deepEqual(layout, { separated: true, sameRow: true, inline: true, titleInInfoRow: true, metricsSecond: true, metricHeight: 40, cardHeight: 90, fits: true });
      const metricSpacing = await card.evaluate(element => {
        const grid = element.querySelector(".metric-grid").getBoundingClientRect();
        const items = Array.from(element.querySelectorAll(".metric-grid .metric"));
        return {
          leftSpace: items[0].getBoundingClientRect().left - grid.left,
          rightSpace: grid.right - items.at(-1).getBoundingClientRect().right,
          gaps: items.map(item => getComputedStyle(item).gap),
        };
      });
      assert.ok(metricSpacing.leftSpace > 150);
      assert.equal(metricSpacing.rightSpace, 18);
      assert.deepEqual(metricSpacing.gaps, ["6px", "6px", "6px", "6px"]);
      await expect(card.locator(".people")).toContainText("Case Owner");
      await expect(card.locator(".people")).toContainText("部门关系");
    }
  }
  assert.deepEqual(errors, []);
  console.log("PASS four card designs, all four metrics, no metric overlap/overflow at both desktop widths");
} finally { await browser.close(); }
