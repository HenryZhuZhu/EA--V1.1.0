import assert from "node:assert/strict";
import { chromium, expect } from "@playwright/test";
const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 1800, height: 1100 } });
  const errors = [];
  page.on("pageerror", e => errors.push(e.message));
  await page.goto(new URL("../V1.1.1.html", import.meta.url).href);
  for (let i=0;i<16;i++) {
    const b=page.getByRole("button",{name:/^(下一步|下一页|开始使用|开始体验|进入系统|知道了)$/}).last();
    if (!await b.isVisible()) break;
    await b.click(); await page.waitForTimeout(100);
  }
  await page.getByText("万能看板",{exact:true}).first().click();
  const card=page.locator('[data-cycle-case-card="cycle-external-scope"]');
  const primary=card.locator('[data-case-summary-row="primary"]');
  const secondary=card.locator('[data-case-summary-row="secondary"]');
  await expect(primary).toContainText("Case Owner");
  await expect(primary).toContainText("部门关系");
  await expect(primary).not.toContainText("Cycle Time");
  assert.deepEqual(await secondary.locator("b").evaluateAll(nodes => nodes.map(node => ({ size: getComputedStyle(node).fontSize, weight: getComputedStyle(node).fontWeight }))), Array(4).fill({ size: "14px", weight: "500" }));
  for (const [selector,value] of [["data-case-total-cycle","12.0"],["data-case-effective-cycle","9.0"],["data-case-tat","9.0"],["data-department-effective-cycle","9.0"]]) {
    await expect(secondary.locator(`[${selector}] b`)).toHaveText(value);
  }
  for (const width of [1440,1800]) {
    await page.setViewportSize({width,height:1100});
    const geometry=await card.evaluate(el=>{
      const top=el.querySelector('[data-case-summary-row="primary"]').getBoundingClientRect();
      const bottom=el.querySelector('[data-case-summary-row="secondary"]').getBoundingClientRect();
      const metrics=Array.from(el.querySelector('[data-case-summary-row="secondary"]').children).map(n=>n.getBoundingClientRect());
      return {height:el.getBoundingClientRect().height,top:top.height,bottom:bottom.height,
        fits:metrics.every((r,i)=>r.right<=bottom.right&&(!i||r.left>=metrics[i-1].right)),
        right:bottom.right-metrics.at(-1).right};
    });
    assert.deepEqual(geometry,{height:90,top:48,bottom:40,fits:true,right:18});
    const states=await page.locator("[data-case-status]").evaluateAll(nodes=>nodes.slice(0,5).map(n=>n.getBoundingClientRect().x));
    assert.ok(Math.max(...states)-Math.min(...states)<1);
  }
  const expand=card.getByRole("button",{name:"展开 EA-260901000095",exact:true});
  await expand.click();
  await expect(card.locator("[data-gantt-row]")).toHaveCount(7);
  await page.getByLabel("万能看板 Case 排序").selectOption("tat");
  await page.getByRole("button",{name:"切换排序方向"}).click();
  await expect(expand).toHaveAttribute("aria-expanded","true");
  await card.locator('[data-gantt-row="external-scope-a"] button').first().click();
  await expect(page.getByRole("button",{name:"查看 Case 全貌 →",exact:true})).toBeVisible();
  assert.deepEqual(errors,[]);
  console.log("PASS C card layout, 90px height, four right-aligned metrics, status alignment, sorting and task navigation");
} finally { await browser.close(); }
