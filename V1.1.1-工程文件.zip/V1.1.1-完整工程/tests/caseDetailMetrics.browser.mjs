import assert from "node:assert/strict";
import { chromium, expect } from "@playwright/test";

const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  const errors = [];
  page.on("pageerror", error => errors.push(error.message));
  await page.goto(new URL("../V1.1.1.html", import.meta.url).href);
  for (let i = 0; i < 16; i++) {
    const next = page.getByRole("button", { name: /^(下一步|下一页|开始使用|开始体验|进入系统|知道了)$/ }).last();
    if (!await next.isVisible()) break;
    await next.click(); await page.waitForTimeout(100);
  }
  await page.getByRole("button", { name: /搜索 Case、任务/ }).click();
  await page.getByPlaceholder("搜索 Case、任务、用户…（多个关键词用空格分隔）").fill("EA-260901000095");
  await page.getByRole("button").filter({ hasText: "EA-260901000095" }).filter({ hasText: "外部验证 · 分析中与方案产出后" }).click();
  const metrics = page.locator("[data-case-detail-metrics]");
  await expect(metrics).toBeVisible();
  for (const [key, value] of [["total", "12.0 天"], ["effective", "9.0 天"], ["tat", "9.0 天"]]) {
    await expect(metrics.locator(`[data-case-detail-metric="${key}"]`).locator("span").last()).toHaveText(value);
  }
  const due = await page.getByText("距到期", { exact: true }).boundingBox();
  const bounds = await metrics.boundingBox();
  assert.ok(bounds.y > due.y && bounds.x >= due.x - 1);
  assert.ok(bounds.x + bounds.width <= 1440);
  assert.deepEqual(errors, []);
  console.log("PASS Case detail sidebar: total 12 days, effective 9 days, TAT 9 days below due date");
} finally {
  await browser.close();
}
