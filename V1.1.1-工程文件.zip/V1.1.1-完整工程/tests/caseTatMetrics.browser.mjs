import assert from "node:assert/strict";
import { chromium, expect } from "@playwright/test";

const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 1600, height: 1100 } });
  const errors = [];
  page.on("pageerror", error => errors.push(error.message));
  await page.clock.setFixedTime(new Date("2026-09-11T00:00:00Z"));
  await page.addInitScript(() => {
    if (sessionStorage.getItem("tat-seeded")) return;
    const at = day => new Date(Date.UTC(2026, 8, 1 + day)).toISOString();
    const task = (id, from, to, external = false) => ({
      id, code: id, title: id, owner: "张伟", supervisor: "张伟", department: "PTE", urgency: "一般",
      status: "已完成", createdAt: at(from),
      statusHistory: [{ status: "进行中", at: at(from) }, { status: "已完成", at: at(to) }],
      ...(external ? { externalVerification: { sourceId: id, parentTaskId: "tat-internal" }, type: "验证" } : {}),
    });
    localStorage.setItem("ea_case_task_trees_v1", JSON.stringify({ c001: [
      task("tat-internal", 0, 4), task("tat-external", 2, 8, true), task("tat-parallel", 6, 7),
    ] }));
    localStorage.setItem("ea_case_closures_v4", JSON.stringify({ c001: {
      caseId: "c001", state: "reopened",
      caseEdits: { name: "Case TAT 状态回归", createdAt: at(0), status: "进行中", owner: "张伟" },
    } }));
    sessionStorage.setItem("tat-seeded", "1");
  });
  await page.goto(process.env.EA_PREVIEW_URL || new URL("../V1.1.0.html", import.meta.url).href);
  const openDashboard = async () => {
    for (let i = 0; i < 16; i++) {
      const next = page.getByRole("button", { name: /^(下一步|下一页|开始使用|开始体验|进入系统|知道了)$/ }).last();
      if (!await next.isVisible()) break;
      await next.click(); await page.waitForTimeout(100);
    }
    await page.getByText("万能看板", { exact: true }).first().click();
  };
  await openDashboard();
  const card = page.getByRole("button", { name: "展开 EA-260511000001", exact: true }).locator("xpath=ancestor::div[contains(@class,'shadow-')][1]");
  await expect(card.locator("[data-case-tat]")).toHaveText("Case TAT · 7.0 天");
  const setState = async (patch, expected) => {
    await page.evaluate(patch => {
      const records = JSON.parse(localStorage.getItem("ea_case_closures_v4"));
      records.c001 = { ...records.c001, ...patch };
      records.c001.caseEdits.status = patch.state === "closed" ? "已关闭" : patch.state === "rootcause" ? "验证中" : "进行中";
      localStorage.setItem("ea_case_closures_v4", JSON.stringify(records));
    }, patch);
    await page.reload(); await openDashboard();
    await expect(card.locator("[data-case-tat]")).toHaveText(`Case TAT · ${expected}`);
    await expect(card.locator("[data-case-tat]")).not.toContainText("累计");
  };
  await setState({ state: "rootcause", verificationStartedAt: "2026-09-07T00:00:00Z" }, "4.0 天");
  await setState({ state: "reopened", verificationStartedAt: null, verificationHistory: [
    { id: "failed", result: "failed", by: "张伟", startedAt: "2026-09-07T00:00:00Z", at: "2026-09-08T00:00:00Z" },
  ] }, "7.0 天");
  await setState({ state: "rootcause", verificationStartedAt: "2026-09-10T00:00:00Z" }, "6.0 天");
  await setState({ state: "closed", closedAt: "2026-09-11T00:00:00Z" }, "6.0 天");
  const summary = page.getByRole("table", { name: "部门 Cycle Time 统计" });
  await expect(summary.getByRole("columnheader", { name: "Case TAT · 平均", exact: true })).toBeVisible();
  const boxes = await card.locator('[data-case-summary-row="secondary"] > div').evaluateAll(elements => elements.map(element => element.getBoundingClientRect().toJSON()));
  assert.ok(boxes[0].right <= boxes[1].left, "secondary role fields and TAT metrics must not overlap");
  assert.deepEqual(errors, []);
  console.log("PASS Case TAT current/verification/reanalysis/latest-entry/closed snapshots, stable label, persistence and card layout");
} finally { await browser.close(); }
