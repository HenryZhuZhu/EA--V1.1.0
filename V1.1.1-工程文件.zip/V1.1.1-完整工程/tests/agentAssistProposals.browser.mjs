import assert from "node:assert/strict";
import { chromium, expect } from "@playwright/test";
const browser = await chromium.launch({headless:true});
try {
  const page=await browser.newPage({viewport:{width:1600,height:1100}});
  const errors=[],remote=[];
  page.on("pageerror",e=>errors.push(e.message));
  page.on("request",r=>{if(/^https?:/.test(r.url()))remote.push(r.url())});
  await page.goto(process.env.EA_AGENT_PROPOSAL_URL);
  const status=page.locator("#statusText");
  await page.getByRole("button",{name:"填入示例并体验",exact:true}).click();
  await expect(status).toContainText("2/2 个物料有记录",{timeout:8000});
  for(const scheme of ["a","b","c"]){
    await page.locator(`[data-scheme="${scheme}"]`).click();
    const cards=page.locator("#map .reference");
    await expect(cards).toHaveCount(2);
    await expect(page.getByRole("button",{name:/展开数据|收起数据/})).toHaveCount(0);
    await expect(page.locator("[data-chip-select]")).toHaveCount(0);
    for(let i=0;i<2;i++){
      const card=cards.nth(i),chip=`CHIP-DEMO-00${i+1}`,wafer=i===0?"WAFER-07":"WAFER-12";
      await expect(card).toContainText(chip);
      await expect(card.getByRole("button")).toHaveCount(1);
      await card.getByRole("button",{name:"查看查询结果",exact:true}).click();
      const detail=page.getByRole("complementary",{name:"物料数据查看面板"});
      await expect(page.getByRole("dialog")).toHaveCount(0);
      await expect(card).toHaveClass(/selected/);
      assert.deepEqual(await card.evaluate(node=>({background:getComputedStyle(node).backgroundColor,radius:getComputedStyle(node).borderRadius})),{background:"rgb(255, 255, 255)",radius:"12px"});
      await expect(detail).toContainText(chip);
      await expect(detail).toContainText(wafer);
      await expect(detail.getByRole("table").locator("tbody tr")).toHaveCount(2);
      await detail.getByRole("button",{name:"Wafer 图片",exact:true}).click();
      await expect(detail.getByRole("img",{name:`${wafer} 合成 Wafer Map`})).toBeVisible();
      await detail.getByRole("button",{name:`放大 ${wafer} 图片`,exact:true}).click();
      const imageDialog=page.getByRole("dialog");
      await imageDialog.getByRole("button",{name:"放大 Wafer 图片",exact:true}).click();
      await expect(imageDialog.locator("#zoomLabel")).toHaveText("125%");
      await page.keyboard.press("Escape");
      await expect(detail).toBeVisible();
    }
    const overlaps=await page.locator("#map").evaluate(map=>{
      const nodes=[...map.querySelectorAll(".node")];
      return nodes.flatMap((n,i)=>nodes.slice(i+1).filter(o=>{
        const a=n.getBoundingClientRect(),b=o.getBoundingClientRect();
        return Math.min(a.right,b.right)>Math.max(a.left,b.left)+1&&Math.min(a.bottom,b.bottom)>Math.max(a.top,b.top)+1;
      }).map(o=>`${n.id}/${o.id}`));
    });
    assert.deepEqual(overlaps,[],scheme);
    await page.getByRole("button",{name:"关闭物料面板",exact:true}).click();
    await expect(page.locator("#drawer")).toBeHidden();
    await expect(page.locator("#map .reference.selected")).toHaveCount(0);
  }
  await page.getByLabel("物料 · Chip ID",{exact:false}).fill("CHIP-DEMO-001, UNKNOWN, CHIP-DEMO-001");
  await expect(page.locator("#drawer")).toBeHidden();
  await expect(status).toContainText("1/2 个物料有记录",{timeout:8000});
  await expect(page.locator("#map .reference")).toHaveCount(2);
  const missing=page.locator("#map .reference").filter({hasText:"UNKNOWN"});
  await expect(missing).toContainText("未查询到记录");
  await missing.getByRole("button",{name:"查看查询结果"}).click();
  await expect(page.locator("#drawer")).toContainText("UNKNOWN");
  await expect(page.locator("#drawer table, #drawer svg")).toHaveCount(0);
  const version=await page.locator("#version").innerText();
  await page.getByLabel("问题背景",{exact:false}).fill("补充背景，不重复查询相同物料");
  await page.waitForTimeout(1200);
  assert.equal(await page.locator("#version").innerText(),version);
  await page.getByLabel("演示返回场景").selectOption("noimage");
  await expect(status).toContainText("0 张 Wafer 图",{timeout:8000});
  await page.locator("#material-0").getByRole("button",{name:"查看查询结果"}).click();
  await page.locator("#drawer").getByRole("button",{name:"Wafer 图片",exact:true}).click();
  await expect(page.locator("#drawer [data-missing-image]")).toBeVisible();
  await page.getByRole("button",{name:"重新查询",exact:true}).click();
  await page.getByRole("button",{name:"取消本次",exact:true}).click();
  await page.waitForTimeout(1600);
  await expect(status).toContainText("查询已取消");
  await expect(page.locator("#map .reference button:enabled")).toHaveCount(0);
  await page.getByLabel("演示返回场景").selectOption("error");
  await expect(status).toContainText("查询失败",{timeout:8000});
  await page.getByRole("button",{name:"＋ 人工思路",exact:true}).click();
  await page.getByRole("dialog").getByLabel("思路内容").fill("用户手动检查");
  await page.getByRole("dialog").getByRole("button",{name:"保存思路"}).click();
  await expect(page.locator("#formalCount")).toHaveText("人工思路 2 · 执行任务 0");
  await page.getByLabel("演示返回场景").selectOption("empty");
  await expect(status).toContainText("未查询到记录",{timeout:8000});
  await expect(page.locator("#map .reference")).toHaveCount(2);
  await page.setViewportSize({width:1280,height:1000});
  assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
  assert.deepEqual(errors,[]);assert.deepEqual(remote,[]);
  console.log("PASS one card per unique Chip ID, sole result action, exact form/image association, three schemes, missing/error/cancel states and no external requests");
}finally{await browser.close()}
