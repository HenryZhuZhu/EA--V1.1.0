import assert from "node:assert/strict";
import { chromium, expect } from "@playwright/test";

const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 1800, height: 1100 } });
  const errors = [];
  page.on("pageerror", error => errors.push(error.message));
  await page.addInitScript(() => {
    const wait = { parentTaskId: "style-parent", title: "验证报告", reason: "验证", verificationKind: "external", description: "报告确认", owner: "张伟", assignedBy: "张伟", createdAt: "2026-09-22T00:00:00Z" };
    localStorage.setItem("ea_case_task_trees_v1", JSON.stringify({ c001: [{
      id: "style-parent", code: "STYLE.001", title: "等待明细样式原任务", owner: "张伟", department: "PTE", urgency: "紧急", status: "进行中", createdAt: "2026-09-20T00:00:00Z",
      waitingTasks: [
        { ...wait, id: "style-done", status: "已完成", endedAt: "2026-09-24T00:00:00Z" },
        { ...wait, id: "style-cancelled", status: "已中止", endedAt: "2026-09-23T00:00:00Z" },
        { ...wait, id: "style-planned", status: "待开始" },
      ],
    }] }));
  });
  await page.goto(new URL("../V1.1.0.html", import.meta.url).href);
  for (let i = 0; i < 16; i++) {
    const next = page.getByRole("button", { name: /^(下一步|下一页|开始使用|开始体验|进入系统|知道了)$/ }).last();
    if (!await next.isVisible()) break;
    await next.click(); await page.waitForTimeout(100);
  }
  await page.getByText("万能看板", { exact: true }).first().click();
  await page.getByRole("button", { name: /^普通任务明细/ }).click();
  const checkSpacing = async (list, row) => {
    const header = list.locator(":scope > div > div").first();
    const headCells = await header.locator(":scope > span").evaluateAll(elements => elements.map(element => element.getBoundingClientRect().toJSON()));
    const rowCells = await row.locator(":scope > *").evaluateAll(elements => elements.slice(1).map(element => element.getBoundingClientRect().toJSON()));
    assert.equal(headCells.length, rowCells.length);
    for (let i = 0; i < headCells.length; i++) {
      assert.ok(Math.abs(headCells[i].x - rowCells[i].x) < 1);
      assert.ok(Math.abs(headCells[i].width - rowCells[i].width) < 1);
      if (i) assert.ok(rowCells[i].x - rowCells[i - 1].right >= 23);
    }
    assert.equal(await row.evaluate(element => getComputedStyle(element).columnGap), "24px");
    assert.ok((await row.boundingBox()).height >= 72);
  };
  await checkSpacing(page.getByRole("region", { name: "普通任务列表", exact: true }), page.locator('[data-department-task="style-parent"]'));
  await page.getByRole("button", { name: /^外部验证任务 ·/ }).click();
  const list = page.getByRole("region", { name: "验证等待列表", exact: true });
  await expect(list).toBeVisible();
  const headers = ["状态", "任务 / Case", "验证时长", "开始 / 结束时间", "任务类型", "任务负责人"];
  await expect(list.locator(":scope > div > div").first().locator(":scope > span")).toHaveText(headers);
  for (const label of headers) {
    await expect(list.getByText(label, { exact: true })).toBeVisible();
  }
  const done = list.locator('[data-department-wait="external-task:style-parent:style-done"]');
  const cells = await done.locator(":scope > *").allTextContents();
  assert.match(cells[1], /已完成/);
  assert.match(cells[2], /验证报告/);
  assert.equal(cells[3], "2.0 天");
  assert.match(cells[4], /2026/);
  assert.equal(cells[5], "外部验证");
  assert.match(cells[6], /PTE · 张伟/);
  await checkSpacing(list, done);
  await expect(done.getByText("2.0 天", { exact: true })).toBeVisible();
  await expect(done.getByText("PTE · 张伟", { exact: true })).toBeVisible();
  await expect(done.getByText("我", { exact: true })).toBeVisible();
  await expect(done.locator("svg")).toHaveCount(1);
  await expect(list.locator('[data-department-wait="external-task:style-parent:style-cancelled"]').getByText("已取消", { exact: true })).toBeVisible();
  await expect(list.locator('[data-department-wait="external-task:style-parent:style-planned"]').getByText("待接受", { exact: true })).toBeVisible();
  await expect(list.locator('[data-department-wait="external-task:style-parent:style-planned"]')).not.toContainText("未计时");
  await page.setViewportSize({ width: 1440, height: 1000 });
  await checkSpacing(list, done);
  await done.getByRole("button", { name: "验证报告", exact: true }).click();
  await expect(page.getByRole("button", { name: "查看 Case 全貌 →", exact: true })).toBeVisible();
  assert.deepEqual(errors, []);
  console.log("PASS matching task-row style, retained fields, owner avatar, wait durations, planned/cancelled states and task navigation");
} finally { await browser.close(); }
