import assert from "node:assert/strict";
import { chromium, expect } from "@playwright/test";
const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  const errors = [];
  page.on("pageerror", error => errors.push(error.message));
  await page.addInitScript(() => {
    localStorage.setItem("ea_case_closures_v4", JSON.stringify({ c001: {
      caseId: "c001", state: "reopened",
      caseEdits: { owner: "张伟", createdBy: "张伟", participants: [{ name: "刘洋", department: "PTE" }] },
    } }));
  });
  await page.goto(new URL("../V1.1.1.html", import.meta.url).href);
  for (let i=0;i<16;i++) {
    const b=page.getByRole("button",{name:/^(下一步|下一页|开始使用|开始体验|进入系统|知道了)$/}).last();
    if(!await b.isVisible()) break;
    await b.click(); await page.waitForTimeout(100);
  }
  await page.getByText("万能看板",{exact:true}).first().click();
  const card=page.locator('[data-cycle-case-card="c001"]');
  const relations=card.getByLabel("部门关系",{exact:true});
  await expect(relations.getByRole("button")).toHaveText("+2");
  for (const width of [1440,1800]) {
    await page.setViewportSize({width,height:1000});
    assert.ok(await relations.evaluate(el => el.scrollWidth <= el.clientWidth));
    const fits=await card.evaluate(el=>{
      const bounds=el.getBoundingClientRect();
      const tags=el.querySelector('[aria-label="部门关系"]');
      return [...tags.children].every(child=>child.getBoundingClientRect().right<=bounds.right);
    });
    assert.ok(fits);
    assert.equal((await card.boundingBox()).height,90);
  }
  await relations.getByRole("button").click();
  const popup=page.getByLabel("全部部门关系",{exact:true});
  await expect(popup).toBeVisible();
  await expect(popup.locator("dt")).toHaveText(["Owner","创建人","协作者","任务负责人"]);
  await expect(popup).toContainText("刘洋");
  await page.keyboard.press("Escape");
  await expect(popup).toHaveCount(0);
  assert.deepEqual(errors,[]);
  console.log("PASS four-role tags fit card, +2 reveals all roles and people, 90px height retained");
} finally { await browser.close(); }
