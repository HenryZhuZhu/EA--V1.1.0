import assert from "node:assert/strict";
import { chromium, expect } from "@playwright/test";

const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 1800, height: 1100 } });
  const errors = [], remote = [];
  page.on("pageerror", error => errors.push(error.message));
  page.on("request", request => { if (/^https?:/.test(request.url())) remote.push(request.url()); });
  await page.goto(process.env.EA_PREVIEW_URL || new URL("../V1.1.1.html", import.meta.url).href);
  const dismissIntro = async () => {
    for (let i = 0; i < 16; i++) {
      const next = page.getByRole("button", { name: /^(下一步|下一页|开始使用|开始体验|进入系统|知道了)$/ }).last();
      if (!await next.isVisible()) break;
      await next.click(); await page.waitForTimeout(100);
    }
  };
  await dismissIntro();
  const openCase = async code => {
    await page.getByRole("button", { name: /搜索 Case、任务/ }).click();
    await page.getByPlaceholder("搜索 Case、任务、用户…（多个关键词用空格分隔）").fill(code);
    await page.getByRole("button").filter({ hasText: code }).filter({ hasText: "DDR5 量产边界失效" }).click();
  };
  await openCase("EA-260813000015");
  const graph = page.locator("[data-case-mindmap-window]");
  const drawer = graph.getByRole("dialog", { name: / CP Index分析结果$/ });
  await graph.scrollIntoViewIfNeeded();
  await expect(graph.locator("[data-material-agent-thought]")).toHaveCount(1);
  await expect(graph.locator("[data-material-agent-thought]")).toContainText("查询物料cp index结果，辅助后续分析");
  await expect(graph.locator("[data-material-chip]")).toHaveCount(2);
  await expect(graph.locator(".react-flow__node-actionNode").first()).toBeAttached();
  const verifyDrawer = async () => {
    await expect(drawer).toBeVisible();
    await expect(drawer).not.toContainText("只读参考 · 合成演示数据，不自动生成分析结论");
    await page.waitForTimeout(300);
    const panel = await drawer.boundingBox(), bounds = await graph.boundingBox();
    assert.ok(panel.x >= bounds.x && panel.x + panel.width <= bounds.x + bounds.width + 1);
    assert.ok(panel.y >= bounds.y && panel.y + panel.height <= bounds.y + bounds.height + 1);
    await expect(page.locator('[data-slot="sheet-overlay"]')).toHaveCount(0);
  };
  for (const [chip, wafer] of [["CHIP-DEMO-001", "WAFER-07"], ["CHIP-DEMO-002", "WAFER-12"]]) {
    const card = graph.locator(`[data-material-chip="${chip}"]`);
    await expect(card.locator("[data-agent-task-name]")).toHaveText(`${chip} cp index分析`);
    await expect(card.locator("[data-agent-task-type]")).toHaveText("agent分析");
    await expect(card.locator("[data-agent-task-owner]")).toHaveText("DS agent");
    await expect(card.locator("[data-agent-task-department]")).toHaveText("PTE");
    await expect(card).not.toContainText("正在查询");
    await expect(graph.locator(`.react-flow__edge[data-id="thought-material-query:${chip}"]`)).toHaveCount(1);
    await card.getByRole("button", { name: "查看查询结果" }).click();
    await verifyDrawer();
    await expect(drawer.getByRole("heading", { name: `${chip} CP Index分析结果`, exact: true })).toBeVisible();
    await expect(drawer.getByText(chip, { exact: true })).toHaveCount(0);
    await expect(drawer).toContainText(chip);
    await expect(drawer.getByRole("table").locator("tbody tr")).toHaveCount(2);
    await drawer.getByRole("button", { name: "Wafer 图片", exact: true }).click();
    await expect(drawer.getByRole("img", { name: `${wafer} 合成 Wafer Map` })).toBeVisible();
    await drawer.getByRole("button", { name: "放大 Wafer 图片" }).click();
    await expect(drawer).toContainText("125%");
    await drawer.getByRole("button", { name: "关闭查询结果", exact: true }).click();
  }
  const cards = await graph.locator("[data-material-chip]").all();
  const firstBounds = await cards[0].boundingBox(), secondBounds = await cards[1].boundingBox();
  assert.ok(firstBounds.y + firstBounds.height < secondBounds.y, "Agent task cards must not overlap");
  await graph.getByTitle("全屏", { exact: true }).click();
  await graph.locator('[data-material-chip="CHIP-DEMO-001"]').getByRole("button", { name: "查看查询结果" }).click();
  await verifyDrawer();
  await drawer.getByRole("button", { name: "刷新该物料", exact: true }).click();
  await expect(drawer).toContainText("正在查询");
  await expect(drawer.getByRole("table")).toBeVisible();
  await page.keyboard.press("Escape");
  await graph.getByTitle("退出全屏", { exact: true }).click();
  await page.reload();
  await dismissIntro();
  await openCase("EA-260813000015");
  await expect(graph.locator("[data-material-chip]")).toHaveCount(2);
  assert.deepEqual(errors, []);
  assert.deepEqual(remote, []);
  console.log("PASS existing Case detail: saved Agent branch, two material results, scoped/fullscreen drawer, table/image, refresh and reload");
} finally {
  await browser.close();
}
