import assert from "node:assert/strict";
import { chromium, expect } from "@playwright/test";

const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({ viewport: { width: 1800, height: 1100 } });
const errors = [];
page.on("pageerror", error => errors.push(error.message));
const parent = async () => page.evaluate(() => JSON.parse(localStorage.getItem("ea_case_task_trees_v1")).c001.find(task => task.id === "t1b"));
async function dismissGuides() {
  for (let i = 0; i < 16; i++) {
    const next = page.getByRole("button", { name: /^(下一步|下一页|开始使用|开始体验|进入系统|知道了)$/ }).last();
    if (!await next.isVisible()) break;
    await next.click();
    await page.waitForTimeout(100);
  }
}
async function openTask() {
  await dismissGuides();
  await page.getByText("万能看板", { exact: true }).first().click();
  await page.getByRole("button", { name: "展开 EA-260511000001", exact: true }).click();
  await page.locator('[data-gantt-row="t1b"] button').first().click();
}
try {
  await page.addInitScript(() => {
    if (sessionStorage.getItem("waiting-test-seed")) return;
    const base = { owner: "张伟", supervisor: "刘洋", department: "PTE", urgency: "紧急", createdAt: "2026-09-22T09:00:00+08:00", dueDate: "2026-10-30", conclusion: "验证结论" };
    localStorage.setItem("ea_case_task_trees_v1", JSON.stringify({ c001: [
      { ...base, id: "t1b", code: "EA-260511000001.002", title: "验证分支流程测试", status: "进行中" },
      { ...base, id: "t2", code: "EA-260511000001.004", title: "旧等待迁移验证", status: "等待反馈", waitingFeedbackPeriods: [
        { id: "legacy-open", reason: "等待内部验证", description: "旧记录保留", startedBy: "张伟", startedAt: "2026-10-24T10:00:00+08:00" },
      ] },
    ] }));
    sessionStorage.setItem("waiting-test-seed", "1");
  });
  await page.goto(process.env.EA_PREVIEW_URL || new URL("../V1.1.0.html", import.meta.url).href);
  await openTask();
  await expect(page.getByRole("region", { name: "等待任务", exact: true })).toHaveCount(0);
  await expect(page.getByRole("button", { name: "新建等待任务", exact: true })).toHaveCount(0);
  if (!process.env.EA_TASK_MAP) await page.getByRole("button", { name: "查看 Case 全貌 →", exact: true }).click();
  await dismissGuides();
  const legacy = page.locator('.react-flow__node[data-id="t2"]');
  await expect(legacy.getByText(/计时暂停/)).toHaveCount(0);
  const legacyWait = await page.evaluate(() => JSON.parse(localStorage.getItem("ea_case_task_trees_v1")).c001.find(task => task.id === "t2").waitingTasks[0]);
  assert.equal(legacyWait.reason, "等待内部验证");
  assert.equal(legacyWait.verificationKind, "internal");
  assert.equal(legacyWait.createdAt, "2026-10-24T10:00:00+08:00");
  await expect(page.getByText("历史记录（不扣时）", { exact: true })).toHaveCount(1);
  const original = page.locator('.react-flow__node[data-id="t1b"]');
  await page.waitForTimeout(1000);
  await original.hover();
  await page.waitForTimeout(350);
  await original.hover();
  await original.getByTitle("基于此动作添加思路", { exact: true }).click();
  const editor = page.locator(".react-flow__node").filter({ has: page.getByLabel("思路标签") });
  await editor.getByLabel("思路标签").selectOption("validation");
  await editor.getByPlaceholder("请填写工作思路").fill("外部结果验证");
  await editor.getByRole("button", { name: "确认", exact: true }).click();
  const thoughtId = (await parent()).verificationNode.thoughtId;
  const verification = page.locator(`.react-flow__node[data-id="${thoughtId}"]`);
  await expect(verification).toBeVisible();
  await expect(verification).toHaveClass(/react-flow__node-thoughtNode/);
  await expect(verification.getByText("validation", { exact: true })).toBeVisible();
  assert.ok((await parent()).verificationNode);
  assert.equal((await parent()).waitingTasks?.length ?? 0, 0);
  await verification.hover(); await page.waitForTimeout(350); await verification.hover();
  await verification.getByTitle("新增验证任务", { exact: true }).click();
  const cancelledDraft = page.locator('.react-flow__node[data-id="special-view:t1b:verification-draft"]');
  await cancelledDraft.getByRole("button", { name: "取消", exact: true }).click();
  await expect(cancelledDraft).toHaveCount(0);
  assert.equal((await parent()).waitingTasks?.length ?? 0, 0);
  for (const reason of ["客户样品复测", "客户平台确认"]) {
    await page.waitForTimeout(800);
    await verification.hover();
    await page.waitForTimeout(350);
    await verification.hover();
    await verification.getByTitle("新增验证任务", { exact: true }).click();
    const editor = page.locator('.react-flow__node[data-id="special-view:t1b:verification-draft"]');
    await expect(page.getByRole("dialog")).toHaveCount(0);
    await expect(editor).toHaveClass(/react-flow__node-actionNode/);
    await expect(editor.getByLabel("任务标签")).toHaveValue("验证");
    await expect(editor.getByLabel("任务标签")).toBeDisabled();
    await expect(editor.locator(".react-flow__handle.source")).toHaveCount(0);
    await editor.getByLabel("验证任务名称").fill(reason);
    await editor.getByLabel("验证任务预期").fill(`${reason}测试说明`);
    await editor.getByRole("button", { name: "确认", exact: true }).click();
  }
  await expect(original.getByText(/计时暂停/)).toHaveCount(0);
  const saved = await parent();
  assert.equal(saved.status, "进行中");
  assert.equal(saved.waitingTasks.length, 2);
  for (const task of saved.waitingTasks) {
    const node = page.locator(`.react-flow__node[data-id="external-task:t1b:${task.id}"]`);
    await expect(node).toBeVisible();
    await expect(node).toHaveClass(/react-flow__node-actionNode/);
    await expect(node.getByText("验证", { exact: true })).toBeVisible();
    assert.equal(task.reason, "验证");
    assert.equal(task.verificationKind, "external");
    assert.equal(task.dueDate, undefined);
    await expect(node.getByRole("button", { name: task.title, exact: true })).toBeEnabled();
    const edgeId = `${thoughtId}-external-task:t1b:${task.id}`;
    await expect(page.locator(`.react-flow__edge[data-id="${edgeId}"]`)).toHaveCount(1);
  }
  if (process.env.EA_SCREENSHOT) {
    await page.mouse.move(240, 50);
    await page.waitForTimeout(1000);
    await page.screenshot({ path: process.env.EA_SCREENSHOT, fullPage: true });
  }
  assert.equal(await page.evaluate(() => JSON.parse(localStorage.getItem("ea_case_task_trees_v1")).c001.length), 2);
  const first = page.locator(`.react-flow__node[data-id="external-task:t1b:${saved.waitingTasks[0].id}"]`);
  await first.getByRole("button", { name: saved.waitingTasks[0].title, exact: true }).click();
  await expect(page.getByRole("button", { name: "查看 Case 全貌 →", exact: true })).toBeVisible();
  assert.equal((await parent()).status, "进行中");
  assert.equal((await parent()).children.find(child => child.id === thoughtId).children.length, 2);
  await page.reload();
  await openTask();
  if (!process.env.EA_TASK_MAP) await page.getByRole("button", { name: "查看 Case 全貌 →", exact: true }).click();
  await dismissGuides();
  await expect(verification).toBeVisible();
  assert.equal((await parent()).waitingTasks.length, 2);
  assert.deepEqual(errors, []);
  console.log("PASS external tasks are independent ordinary clickable nodes, original timer is not paused, no duplicate projections and refresh persistence");
} catch (error) {
  console.error("Runtime errors:", errors);
  console.error("Mind map nodes:", await page.locator(".react-flow__node").allTextContents());
  console.error("Page tail:", (await page.locator("body").innerText()).slice(-2200));
  throw error;
} finally { await browser.close(); }
