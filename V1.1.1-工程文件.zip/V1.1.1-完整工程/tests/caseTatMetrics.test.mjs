import assert from "node:assert/strict";
import test from "node:test";
import vm from "node:vm";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";

const { outputFiles } = await build({
  entryPoints: [fileURLToPath(new URL("../src/app/components/departmentAnalytics.ts", import.meta.url))],
  bundle: true, write: false, platform: "node", format: "cjs",
});
const box = { module: { exports: {} } };
vm.runInNewContext(outputFiles[0].text, box);
const { caseTatMetrics, caseCycleMetrics, departmentCaseRecord, summarizeDepartment } = box.module.exports;
const day = 86400000;
const at = n => new Date(Date.UTC(2026, 8, 1 + n)).toISOString();
const task = (id, from, to, external = false, department = "PTE") => ({
  id, code: id, title: id, owner: "张伟", department, urgency: "一般", status: "已完成",
  createdAt: at(from), statusHistory: [{ status: "进行中", at: at(from) }, { status: "已完成", at: at(to) }],
  ...(external ? { externalVerification: { sourceId: id, parentTaskId: "internal" } } : {}),
});
const item = {
  id: "tat", status: "进行中", owner: "张伟", createdBy: "李娜", createdAt: at(0),
  tasks: [task("internal", 0, 4), task("external", 2, 8, true), task("parallel", 6, 7, false, "CP")],
};
test("Case TAT uses current snapshot before validation and excludes only external-exclusive time", () => {
  const result = caseTatMetrics(item, undefined, Date.parse(at(10)));
  assert.equal(result.total, 10 * day);
  assert.equal(result.excluded, 3 * day);
  assert.equal(result.value, 7 * day);
  assert.equal(result.end, Date.parse(at(10)));
  assert.equal(caseTatMetrics(item, undefined, Date.parse(at(11))).value, 8 * day);
});
test("Case TAT freezes at validation entry, clips crossing waits, and retains parallel internal work", () => {
  const closure = { state: "rootcause", verificationStartedAt: at(6), rootCauseAt: at(9) };
  for (const now of [10, 20]) {
    const result = caseTatMetrics(item, closure, Date.parse(at(now)));
    assert.equal(result.total, 6 * day);
    assert.equal(result.excluded, 2 * day);
    assert.equal(result.value, 4 * day);
  }
  const closed = { ...closure, state: "closed", closedAt: at(10) };
  assert.equal(caseTatMetrics(item, closed, Date.parse(at(20))).value, 4 * day);
  assert.equal(caseCycleMetrics(item, closed, Date.parse(at(20))).effective, 5 * day);
});
test("reanalysis resumes from original creation; latest reentry replaces earlier endpoint", () => {
  const history = [{ result: "failed", startedAt: at(3), at: at(4) }];
  const reopened = { state: "reopened", verificationStartedAt: null, rootCauseAt: at(3), verificationHistory: history };
  assert.equal(caseTatMetrics({ ...item, status: "验证中" }, reopened, Date.parse(at(10))).value, 7 * day);
  const reentered = { ...reopened, state: "rootcause", verificationStartedAt: at(9) };
  assert.equal(caseTatMetrics(item, reentered, Date.parse(at(20))).value, 6 * day);
  const recovered = { state: "rootcause", rootCauseAt: at(3), recovery: [{ kind: "reopen", at: at(5) }], verificationHistory: history };
  assert.equal(caseTatMetrics(item, recovered, Date.parse(at(10))).value, null);
});
test("explicit entry required for verifying/closed records; bad dates never become zero samples", () => {
  assert.equal(caseTatMetrics({ ...item, status: "验证中" }, undefined, Date.parse(at(10))).value, null);
  assert.equal(caseTatMetrics(item, { state: "closed", closedAt: at(10) }, Date.parse(at(20))).value, null);
  for (const verificationStartedAt of ["bad", at(-1), at(11)]) {
    const result = caseTatMetrics(item, { state: "rootcause", verificationStartedAt }, Date.parse(at(10)));
    assert.equal(result.value, null); assert.ok(result.issue);
  }
  assert.equal(caseTatMetrics({ ...item, createdAt: "bad" }, undefined, Date.parse(at(10))).value, null);
  assert.equal(caseTatMetrics(item, { state: "closed", closedAt: at(8), verificationStartedAt: at(9) }, Date.parse(at(10))).value, null);
  assert.equal(caseTatMetrics(item, { state: "rootcause", verificationStartedAt: at(0) }, Date.parse(at(10))).value, 0);
});
test("latest historical entry is chronological, not array order, and task-level validation is not Case entry", () => {
  const closure = { state: "closed", closedAt: at(10), verificationHistory: [
    { result: "passed", startedAt: at(9), at: at(10) }, { result: "failed", startedAt: at(3), at: at(4) },
  ] };
  assert.equal(caseTatMetrics(item, closure, Date.parse(at(20))).value, 6 * day);
  const withTaskValidation = { ...item, tasks: [task("external-only", 0, 4, true)] };
  assert.equal(caseTatMetrics(withTaskValidation, undefined, Date.parse(at(10))).total, 10 * day);
  assert.equal(caseTatMetrics(withTaskValidation, { state: "closed", closedAt: at(10), rootCauseAt: at(8) }, Date.parse(at(10))).value, 4 * day);
});
test("Case TAT mean follows role filters, deduplicates Cases and includes relationship-only Cases", () => {
  const now = Date.parse(at(10));
  const directory = { 张伟: "PTE", 李娜: "DA" };
  const a = departmentCaseRecord(item, item.tasks, undefined, now, directory); // 7 days, owner PTE
  const b = departmentCaseRecord({ ...item, id: "creator", owner: "李娜", createdBy: "张伟", tasks: [], createdAt: at(6) }, [], undefined, now, directory); // 4 days
  const invalid = departmentCaseRecord({ ...item, id: "invalid", status: "验证中", tasks: [] }, [], undefined, now, directory);
  const result = summarizeDepartment([a, a, b, invalid], new Set(["PTE"]));
  assert.equal(result.count, 3); assert.equal(result.caseTatSampleCount, 2);
  assert.equal(result.caseTatAverage, 5.5 * day);
  assert.equal(summarizeDepartment([a, b], new Set(["PTE"]), ["creator"]).caseTatAverage, 4 * day);
  assert.equal(summarizeDepartment([a, b], new Set(["PTE"]), ["owner"]).caseTatAverage, 7 * day);
  assert.equal(summarizeDepartment([a, b], new Set(["PTE"]), []).caseTatAverage, null);
});
