import assert from "node:assert/strict";
import { chromium, expect } from "@playwright/test";
const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 1600, height: 1100 } });
  const errors = [];
  page.on("pageerror", error => errors.push(error.message));
  await page.goto(new URL("../V1.1.1.html", import.meta.url).href);
  for (let i=0;i<16;i++) {
    const b=page.getByRole("button",{name:/^(下一步|下一页|开始使用|开始体验|进入系统|知道了)$/}).last();
    if(!await b.isVisible())break;
    await b.click();await page.waitForTimeout(100);
  }
  await page.getByText("万能看板",{exact:true}).first().click();
  await page.getByRole("tab",{name:"产品视角",exact:true}).click();
  const scope=page.getByRole("button",{name:"分析范围",exact:true});
  await expect(scope).toBeVisible();
  const positions=await page.locator("#product-analysis-global-tools").evaluate(host=>{
    const header=host.previousElementSibling;
    return {below:host.getBoundingClientRect().top>=header.getBoundingClientRect().bottom, outsideHeader:!host.closest("header"), count:document.querySelectorAll("#product-analysis-global-tools").length};
  });
  assert.deepEqual(positions,{below:true,outsideHeader:true,count:1});
  await page.getByRole("button",{name:"按周",exact:true}).click();
  await scope.click();
  await page.getByLabel("开始日期",{exact:true}).fill("2026-09-01");
  await page.getByLabel("结束日期",{exact:true}).fill("2026-10-29");
  await page.getByRole("button",{name:"应用",exact:true}).click();
  await scope.click();
  await expect(page.getByLabel("开始日期",{exact:true})).toHaveValue("2026-09-01");
  await expect(page.getByLabel("结束日期",{exact:true})).toHaveValue("2026-10-29");
  await page.getByRole("button",{name:"取消",exact:true}).click();
  await page.getByRole("tab",{name:"部门视角",exact:true}).click();
  await expect(scope).toHaveCount(0);
  await page.getByRole("tab",{name:"产品视角",exact:true}).click();
  await expect(scope).toBeVisible();
  assert.deepEqual(errors,[]);
  console.log("PASS product scope controls below divider, date apply, grain selection and perspective switching");
} finally { await browser.close(); }
