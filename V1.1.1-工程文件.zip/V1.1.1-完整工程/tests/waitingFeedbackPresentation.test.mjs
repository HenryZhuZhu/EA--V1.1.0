import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

const source = name => readFileSync(new URL(`../src/app/components/${name}`, import.meta.url), "utf8");
test("special tasks are created in verification mind-map nodes, not task detail panels", () => {
  const modal = source("WaitFeedbackModal.tsx");
  assert.match(modal, /title="新增验证任务"/);
  assert.doesNotMatch(modal, /WAIT_TASK_REASONS\.map/);
  assert.match(modal, /验证任务预期/);
  assert.match(modal, /reason: "验证"/);
  assert.match(modal, /预计完成日期（可选）/);
  assert.match(modal, /maxLength=\{500\}/);
  assert.match(modal, /!description\.trim\(\) \|\| !ownerToDepartment\[owner\]/);
  for (const file of ["TaskDetail.tsx", "StandaloneTaskResult.tsx"]) {
    assert.doesNotMatch(source(file), /<WaitFeedbackModal|<WaitingTaskPanel|setWaitingForFeedback/);
  }
  assert.doesNotMatch(source("TaskDetailActions.tsx"), /新建等待任务/);
  assert.match(source("MindMapFlow.tsx"), /verificationMindMap\(withDraft\(filtered\)\)/);
  assert.match(source("MindMapFlow.tsx"), /saveValidationThought/);
  assert.match(source("validationThoughts.ts"), /THOUGHT_CATEGORIES = \[\.\.\.PROBLEM_DOMAINS, "Other", "validation"\]/);
  for (const file of ["MindMapFlow.tsx", "CreateCaseMindMapFlow.tsx", "CreateCaseWbsTable.tsx"]) {
    assert.match(source(file), /import \{ THOUGHT_CATEGORIES.*from "\.\/validationThoughts"/);
    assert.doesNotMatch(source(file), /THOUGHT_CATEGORIES\.filter/);
  }
  assert.doesNotMatch(source("MindMapFlow.tsx"), /<WaitFeedbackModal/);
  assert.match(source("MindMapFlow.tsx"), /isEditing: special\.specialTask\.id === "verification-draft"/);
});
