import assert from "node:assert/strict";
import { chromium, expect } from "@playwright/test";
const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 1800, height: 1100 } });
  const errors = [];
  page.on("pageerror", error => errors.push(error.message));
  await page.goto(new URL("../V1.1.1.html", import.meta.url).href);
  for (let i = 0; i < 16; i++) {
    const next = page.getByRole("button", { name: /^(下一步|下一页|开始使用|开始体验|进入系统|知道了)$/ }).last();
    if (!await next.isVisible()) break;
    await next.click(); await page.waitForTimeout(100);
  }
  await page.getByRole("button", { name: "新建", exact: true }).click();
  await page.getByRole("button").filter({ hasText: "需要找根因" }).click();
  for (const variant of ["标准版", "创新版"]) {
    await page.getByRole("button", { name: variant, exact: true }).click();
    const toggle = page.getByRole("switch", { name: "启用 TAT 截止日期" }).filter({ visible: true });
    const deadline = page.getByLabel("截止日期", { exact: true }).filter({ visible: true });
    const tat = page.getByLabel("TAT截止日期", { exact: true }).filter({ visible: true });
    await expect(toggle).not.toBeChecked();
    await expect(tat).toHaveCount(0);
    await deadline.fill("2026-11-30");
    await toggle.click();
    await expect(tat).toHaveValue("");
    assert.equal(await tat.evaluate(input => input.required), false);
    await tat.fill("2026-11-20");
    const a = await deadline.boundingBox(), b = await tat.boundingBox();
    assert.ok(b.y >= a.y + a.height && Math.abs(a.x - b.x) < 1);
    await toggle.click();
    await expect(tat).toHaveCount(0);
    await expect(deadline).toHaveValue("2026-11-30");
    await toggle.click();
    await expect(tat).toHaveValue("");
    await tat.fill("2026-11-22");
    await page.getByRole("button", { name: "重置", exact: true }).filter({ visible: true }).click();
    await expect(toggle).not.toBeChecked();
    await expect(tat).toHaveCount(0);
  }
  assert.deepEqual(errors, []);
  console.log("PASS both creation forms: optional TAT date, below deadline, off clears, reset clears");
} finally { await browser.close(); }
