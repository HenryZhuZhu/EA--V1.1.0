import assert from "node:assert/strict";
import test from "node:test";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import vm from "node:vm";
import { build } from "esbuild";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";

const require = createRequire(import.meta.url);
const { outputFiles } = await build({
  stdin: { resolveDir: fileURLToPath(new URL("../", import.meta.url)), contents: `export * from "./src/app/components/CycleTimeCaseCard"; export * from "./src/app/components/externalVerificationTasks";` },
  bundle: true, write: false, platform: "node", format: "cjs", jsx: "automatic", packages: "external",
  external: ["./data", "./closures", "./caseTaskTrees", "./CaseProductPill", "./CaseMarkCodePill"],
});
const sandbox = { module: { exports: {} }, require(name) {
  if (name === "./data") return {
    flattenTasks: function walk(nodes, depth = 0, path = []) { return nodes.flatMap(task => [{ task, depth, path }, ...walk(task.children ?? [], depth + 1, [...path, task.title])]); },
    levelColors: { L1: "" }, urgencyBar: { 一般: "" },
  };
  if (name === "./closures") return { useClosures: () => ({ get: id => id === "open" ? undefined : ({ state: "closed", closedAt: "2026-10-01T10:00:00Z", rootCauseAt: "2026-10-01T06:00:00Z" }) }) };
  if (name === "./caseTaskTrees") return { useCaseTaskRevision() {}, loadCaseTaskTree: (_id, tasks) => sandbox.module.exports.materializeExternalVerificationTasks(tasks, { 李娜: "DA", 李四: "QA", 张伟: "PTE" }) };
  if (name === "./CaseProductPill") return { CaseProductPill: () => null };
  if (name === "./CaseMarkCodePill") return { CaseMarkCodePill: () => null };
  return require(name);
} };
vm.runInNewContext(outputFiles[0].text, sandbox);
const { CycleTimeCaseCard } = sandbox.module.exports;
const caseItem = {
  id: "case", code: "EA-test", name: "测试 Case", owner: "张伟", level: "L1", urgency: "一般", status: "进行中",
  createdAt: "2026-10-01T00:00:00Z",
  tasks: [{
    id: "task", code: "EA-test.001", title: "跨部门任务", owner: "李四", department: "QA", status: "已完成",
    createdAt: "2026-10-01T00:00:00Z",
    statusHistory: [{ status: "已完成", at: "2026-10-01T10:00:00Z" }],
    waitingFeedbackPeriods: [{ reason: "等待外部反馈", startedAt: "2026-10-01T02:00:00Z", endedAt: "2026-10-01T04:00:00Z" }],
    children: [{ id: "missing", code: "EA-test.002", title: "无时间任务", owner: "王五", status: "已完成" }],
  }],
};
const render = (expanded, item = caseItem) => renderToStaticMarkup(createElement(CycleTimeCaseCard, { caseItem: item, expanded, onToggle() {}, onOpenTask() {} }));
test("Case summary adds standalone TAT while preserving primary fields and renaming department metric", () => {
  const html = renderToStaticMarkup(createElement(CycleTimeCaseCard, {
    caseItem: { ...caseItem, createdBy: "王芳", participants: [{ name: "李娜", department: "DA" }] },
    expanded: false, onToggle() {}, onOpenTask() {},
    departmentInfo: { relations: [{ role: "owner", name: "张伟", departmentId: "PTE" }], totalCycleTime: 36000000, cycleTime: 28800000, taskCount: 1, timingIssues: ["任务时间超出 Case 生命周期"] },
  }));
  const secondary = html.slice(html.indexOf('data-case-summary-row="secondary"'));
  const primary = html.slice(0, html.indexOf('data-case-summary-row="secondary"'));
  assert.doesNotMatch(primary, /Cycle Time|Case TAT/);
  assert.match(primary, /Case Owner/);
  assert.match(primary, /部门关系/);
  for (const label of ["Case 总 Cycle Time", "Case 有效 Cycle Time", "Case TAT", "部门有效 Cycle Time"]) assert.ok(secondary.includes(label), label);
  for (const label of ["创建人 ·", "创建日期 ·", "Case Owner", "协作者 ·", "本部门普通任务", "本部门总 Cycle Time", "Case 级等待验证时长"]) assert.ok(!secondary.includes(label), label);
  assert.match(secondary.replace(/<[^>]*>/g, ""), /8\.0小时/);
  assert.match(secondary.replace(/<[^>]*>/g, ""), /6\.0小时/);
  assert.doesNotMatch(html, />本部门有效 Cycle Time/);
  assert.doesNotMatch(html, /时间记录需核对/);
});

test("Case card shows effective Case cycle and reuses detail Gantt with all tasks", () => {
  const html = render(true);
  assert.match(html, /跨部门任务/);
  assert.match(html, /无时间任务/);
  assert.match(html, /10\.0 小时/);
  assert.match(html, /未记录/);
  assert.match(html, /Case 有效 Cycle Time/);
  assert.match(html, /Case 总 Cycle Time/);
  assert.doesNotMatch(html, /Case Cycle Time/);
  assert.match(html, /data-gantt-row="task"/);
  assert.match(html, /data-gantt-row="missing"/);
  assert.match(html, /data-gantt-cycle-time="task"[^>]*>10\.0 小时/);
  assert.match(html, />日<\/button>/);
  assert.match(html, />周<\/button>/);
});
test("external verification renders once as ordinary task rows with independent lifecycle", () => {
  const waits = [
    { id: "done", parentTaskId: "task", title: "外部反馈", reason: "等待外部反馈", owner: "李娜", assignedBy: "李四", createdAt: "2026-10-01T02:00:00Z", endedAt: "2026-10-01T04:00:00Z", status: "已完成" },
    { id: "cancelled", parentTaskId: "task", title: "客户取消复测", reason: "外部验证", owner: "李娜", assignedBy: "李四", createdAt: "2026-10-01T05:00:00Z", endedAt: "2026-10-01T06:00:00Z", status: "已中止" },
    { id: "unknown", parentTaskId: "task", title: "外部复测缺失结束记录", reason: "外部验证", owner: "李娜", assignedBy: "李四", createdAt: "2026-10-01T05:00:00Z", status: "已完成" },
  ];
  const item = { ...caseItem, tasks: [{ ...caseItem.tasks[0], waitingTasks: waits }] };
  const html = render(true, item);
  assert.equal((html.match(/data-gantt-row=/g) ?? []).length, 6);
  assert.equal((html.match(/data-gantt-verification=/g) ?? []).length, 0);
  assert.match(html, /data-gantt-cycle-time="external-task:task:done"[^>]*>2\.0 小时/);
  assert.match(html, /已中止/);
  assert.match(html, /data-gantt-row="external-task:task:unknown"/);
  assert.doesNotMatch(html, /bg-violet-50\/30|border-violet-500 bg-violet-400/);
  const scoped = renderToStaticMarkup(createElement(CycleTimeCaseCard, { caseItem: item, expanded: true, onToggle() {}, onOpenTask() {}, scopedTaskIds: ["missing"] }));
  assert.doesNotMatch(scoped, /data-gantt-verification=/);
});
test("external task without optional due date has an independent numeric duration", () => {
  const createdAt = new Date(Date.now() - 3600000).toISOString();
  const html = render(true, { ...caseItem, id: "open", tasks: [{
    ...caseItem.tasks[0], status: "进行中", children: [],
    waitingTasks: [{ id: "no-due", title: "验证结果", reason: "验证", verificationKind: "external", owner: "张伟", assignedBy: "李娜", createdAt, status: "进行中" }],
  }] });
  assert.match(html, /data-gantt-row="external-task:task:no-due"/);
  assert.match(html, /data-gantt-cycle-time="external-task:task:no-due"[^>]*>1\.0 小时/);
});
test("collapsed Case hides Gantt, empty Case has an explicit empty state", () => {
  assert.doesNotMatch(render(false), /任务甘特图/);
  assert.match(render(false).replace(/<[^>]*>/g, ""), /10\.0小时/);
  assert.match(render(false), /title="紧急度：一般"/);
  assert.match(render(false), /w-1 shrink-0/);
  assert.match(render(true, { ...caseItem, tasks: [] }), /暂无可展示的任务/);
});
test("dashboard hides thought rows and keeps all nested executable tasks without indentation", () => {
  const html = render(true, { ...caseItem, tasks: [{ id: "thought", title: "隐藏的思路", children: caseItem.tasks }] });
  assert.doesNotMatch(html, /隐藏的思路|个思路|思路 \/ 任务/);
  assert.match(html, /data-gantt-row="task"/);
  assert.match(html, /data-gantt-row="missing"/);
  assert.doesNotMatch(html, /padding-left:(20|40)px/);
});
test("unfinished task Cycle Time continues while external verification runs", () => {
  const createdAt = new Date(Date.now() - 5 * 3600000).toISOString();
  const html = render(true, { ...caseItem, id: "open", tasks: [{
    ...caseItem.tasks[0], status: "进行中", createdAt, children: [],
    waitingFeedbackPeriods: [{ reason: "等待外部反馈", startedAt: createdAt }],
  }] });
  assert.match(html, /data-gantt-cycle-time="task"[^>]*>5\.0 小时/);
});
test("department-scoped Gantt retains nested selected tasks exactly once and does not change Case totals", () => {
  const html = renderToStaticMarkup(createElement(CycleTimeCaseCard, {
    caseItem, expanded: true, onToggle() {}, onOpenTask() {}, scopedTaskIds: ["missing"],
  }));
  assert.match(html, /当前部门任务/);
  assert.match(html, /全部任务/);
  assert.doesNotMatch(html, /data-gantt-row="task"/);
  assert.equal((html.match(/data-gantt-row="missing"/g) ?? []).length, 1);
  assert.match(html.replace(/<[^>]*>/g, ""), /10\.0小时/);
});
