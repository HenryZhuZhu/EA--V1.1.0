import assert from "node:assert/strict";
import { chromium, expect } from "@playwright/test";

const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 1800, height: 1100 } });
  const errors = [];
  page.on("pageerror", error => errors.push(error.message));
  await page.goto(process.env.EA_PREVIEW_URL || new URL("../V1.1.0.html", import.meta.url).href);
  for (let i = 0; i < 16; i++) {
    const next = page.getByRole("button", { name: /^(下一步|下一页|开始使用|开始体验|进入系统|知道了)$/ }).last();
    if (!await next.isVisible()) break;
    await next.click(); await page.waitForTimeout(100);
  }
  await page.getByText("万能看板", { exact: true }).first().click();
  const tree = page.getByRole("complementary", { name: "部门", exact: true });
  await expect(tree.getByRole("heading", { name: "部门", exact: true })).toBeVisible();
  await expect(tree).not.toContainText("个部门");
  await tree.getByRole("button", { name: "PTE", exact: true }).click();
  const table = page.getByRole("table", { name: "部门 Cycle Time 统计" });
  await expect(table.locator("tbody tr")).toHaveCount(1);
  await expect(table.locator("tbody td").first()).toHaveText("PTE");
  assert.equal(await table.locator("tbody td").nth(1).evaluate(element => getComputedStyle(element).fontSize), "18px");
  await expect(table.getByRole("columnheader", { name: "Case 数", exact: true })).toHaveCount(1);
  await expect(table.locator('th[scope="col"]')).toHaveText(["部门", "Case 数", "Case TAT · 平均", "部门 Cycle Time · 平均", "任务数", "任务Cycle Time·平均"]);
  await expect(page.getByRole("button", { name: /^任务 ·/ })).toHaveCount(1);
  await expect(page.getByRole("button", { name: /^普通任务明细/ })).toHaveCount(0);
  await expect(table.locator('th[scope="colgroup"]')).toHaveCount(0);
  await expect(table.locator("thead tr")).toHaveCount(1);
  assert.equal(await table.locator("thead th").nth(4).evaluate(cell => getComputedStyle(cell).borderLeftWidth), "1px");
  assert.equal(await table.locator("tbody td").nth(4).evaluate(cell => getComputedStyle(cell).borderLeftWidth), "1px");
  for (const row of await table.locator("tbody tr").all()) await expect(row.locator("td")).toHaveCount(6);
  const dataColors = await table.locator("tbody td").evaluateAll(cells => cells.map(cell => getComputedStyle(cell).color));
  assert.equal(new Set(dataColors).size, 1, "all department summary values use the same dark text");
  await expect(table.locator("tbody tr")).toHaveClass(/text-slate-900/);
  for (const width of [1440, 1800]) {
    await page.setViewportSize({ width, height: 1100 });
    const geometry = await table.evaluate(element => ({
      width: element.getBoundingClientRect().width,
      headerHeight: element.querySelector("thead").getBoundingClientRect().height,
      heads: Array.from(element.querySelectorAll('th[scope="col"]'), cell => ({ x: cell.getBoundingClientRect().x, width: cell.getBoundingClientRect().width, padding: getComputedStyle(cell).paddingLeft, fits: cell.scrollWidth <= cell.clientWidth })),
      cells: Array.from(element.querySelectorAll("tbody td"), cell => ({ x: cell.getBoundingClientRect().x, width: cell.getBoundingClientRect().width, padding: getComputedStyle(cell).paddingLeft })),
    }));
    assert.ok(geometry.headerHeight <= 44, `single-row header: ${geometry.headerHeight}px`);
    for (const [index, ratio] of [0.18, 0.12, 0.17, 0.20, 0.13, 0.20].entries()) {
      assert.ok(Math.abs(geometry.heads[index].width - geometry.width * ratio) < 2);
      assert.equal(geometry.heads[index].x, geometry.cells[index].x);
      assert.equal(geometry.heads[index].padding, "24px");
      assert.equal(geometry.cells[index].padding, "24px");
      assert.ok(geometry.heads[index].fits);
    }
  }
  await expect(page.getByText(/个含本部门任务的 Case 缺少有效任务时间/)).toHaveCount(0);
  await expect(page.getByText(/个 Case 缺少有效创建／进入验证中时间/)).toHaveCount(0);
  await expect(table).not.toContainText("中位数");
  await expect(table).not.toContainText("实际处理");
  await expect(page.getByLabel("Case 统计范围", { exact: true })).toHaveCount(0);
  const count = async () => Number(await table.locator("tbody tr").first().locator("td").nth(1).innerText());
  const all = await count();
  assert.ok(all > 0);
  const roles = page.getByRole("group", { name: "人员身份", exact: true });
  await expect(roles).toBeVisible();
  const labels = ["作为 Case Owner", "作为创建人", "作为协作者", "作为任务负责人"];
  for (const label of labels) await roles.getByLabel(label, { exact: true }).uncheck();
  assert.equal(await count(), 0);
  await expect(table.locator("[data-department-case-tat]")).toHaveText("—");
  await expect(page.getByRole("button", { name: "Case · 0", exact: true })).toHaveCount(1);
  const totals = [];
  for (const label of labels) {
    await roles.getByLabel(label, { exact: true }).check();
    const total = await count();
    totals.push(total);
    await expect(page.getByRole("button", { name: `Case · ${total}`, exact: true })).toHaveCount(1);
    assert.ok(total <= all);
    await roles.getByLabel(label, { exact: true }).uncheck();
  }
  assert.ok(new Set(totals).size > 1, "different role selections must use their corresponding Case populations");
  await page.getByRole("button", { name: "筛选", exact: true }).click();
  const filter = page.getByLabel("Cycle Time Case 筛选");
  await expect(filter.getByRole("checkbox")).toHaveCount(0);
  await filter.getByRole("button", { name: "重置全部", exact: true }).click();
  assert.equal(await count(), all);
  await expect(filter.getByLabel("Case 状态", { exact: true })).toBeVisible();
  await filter.getByRole("button", { name: "完成", exact: true }).click();
  await tree.getByRole("button", { name: "测试中心", exact: true }).click();
  await expect(table.locator("tbody tr")).toHaveCount(1);
  await expect(table.locator("tbody td").first()).toHaveText("测试中心");
  assert.deepEqual(errors, []);
  console.log(`PASS six columns including Case TAT, removed timing notices, role-linked Case counts ${totals.join("/")} and reset ${all}`);
} finally { await browser.close(); }
