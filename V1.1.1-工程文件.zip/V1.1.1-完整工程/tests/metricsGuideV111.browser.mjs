import assert from "node:assert/strict";
import { chromium, expect } from "@playwright/test";

const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  const errors = [];
  page.on("pageerror", error => errors.push(error.message));
  await page.goto(new URL("../万能看板_指标与甘特图说明.html", import.meta.url).href);
  await expect(page).toHaveTitle("万能看板 V1.1.1 · 统计指标与甘特图说明");
  await expect(page.getByRole("table", { name: "V1.1.1 部门统计示例" }).locator("tbody td")).toHaveText(["PTE（含下级）", "1", "9.0 天", "12.0 天", "7", "4.33 天"]);
  await expect(page.locator("[data-metric]")).toHaveCount(7);
  for (const [index, duration] of [[0, 12], [1, 9], [2, 12], [3, 9], [6, 9]]) {
    await page.locator(`[data-metric="${index}"]`).click();
    await expect(page.locator("#selectedResult .value")).toHaveText(`${duration} 天`);
    if (index === 6) await expect(page.locator("#originalChart .removed")).toHaveCount(1);
  }
  await page.locator('[data-metric="4"]').click();
  await expect(page.locator("#originalChart .selected .value")).toHaveText(["7 天", "4 天", "2 天"]);
  for (const [index, duration] of [7, 4, 2].entries()) {
    await page.getByLabel("选择普通任务").selectOption(String(index));
    await expect(page.locator("#originalChart .selected .value")).toHaveText(`${duration} 天`);
  }
  await page.locator('[data-metric="5"]').click();
  await expect(page.locator("#originalChart .selected .value")).toHaveText(["2 天", "1 天", "1 天", "2 天"]);
  for (const [index, duration] of [2, 1, 1, 2].entries()) {
    await page.getByLabel("选择外部验证", { exact: true }).selectOption(String(index));
    await expect(page.locator("#originalChart .selected .value")).toHaveText(`${duration} 天`);
  }
  for (const id of ["calculationLogic", "filterGuide", "productGuide", "tatPlanGuide", "agentGuide"]) {
    const details = page.locator(`#${id}`);
    assert.equal(await details.evaluate(element => element.open), false);
    await details.locator("summary").click();
    assert.equal(await details.evaluate(element => element.open), true);
  }
  await expect(page.getByRole("table", { name: "三个页签排序" }).locator("tbody tr")).toHaveCount(3);
  await expect(page.getByRole("table", { name: "产品视角指标" }).locator("tbody tr")).toHaveCount(4);
  await expect(page.locator("#tatPlanGuide")).toContainText("不作为实际 TAT 截止点");
  await expect(page.locator("#agentGuide")).toContainText("不计任务数");
  for (const width of [1440, 1280]) {
    await page.setViewportSize({ width, height: 1000 });
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
  }
  assert.deepEqual(errors, []);
  console.log("PASS V1.1.1 metrics guide: six-column summary, seven interactive metrics, selectors, folded sections, desktop layout");
} finally {
  await browser.close();
}
