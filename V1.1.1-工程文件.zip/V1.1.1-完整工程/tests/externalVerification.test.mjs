import assert from "node:assert/strict";
import test from "node:test";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";
import vm from "node:vm";
import { webcrypto } from "node:crypto";

const { outputFiles } = await build({
  stdin: { resolveDir: fileURLToPath(new URL("../", import.meta.url)), contents: `
    export * from "./src/app/components/externalVerification";
    export * from "./src/app/components/waitingTasks";
    export * from "./src/app/components/departmentAnalytics";
    export { dashboardDemoScenarios } from "./src/app/components/dashboardDemoScenarios";
  ` }, bundle: true, write: false, platform: "node", format: "cjs",
});
const box = { module: { exports: {} }, crypto: webcrypto };
vm.runInNewContext(outputFiles[0].text, box);
const api = box.module.exports;
const day = 86400000;
const at = n => new Date(Date.UTC(2026, 8, 1 + n, 1)).toISOString();
const wait = (id, reason, start, end, extra = {}) => ({ id, parentTaskId: "a", title: reason, reason, owner: "张伟", assignedBy: "张伟", description: "历史原文不改变", status: end === undefined ? "进行中" : "已完成", createdAt: at(start), endedAt: end === undefined ? undefined : at(end), ...extra });
const caseWait = (id, phase, start, end, extra = {}) => ({ id, title: id, scope: "case", pausesCase: true, verificationKind: "external", phase, status: end === undefined ? "进行中" : "已完成", startedAt: at(start), endedAt: end === undefined ? undefined : at(end), ...extra });

test("legacy internal, borrowed equipment and unclassified verification never become external or deduct time", () => {
  const internal = wait("internal", "等待内部验证", 1, 8);
  const record = { id: "a", owner: "张伟", status: "进行中", waitingTasks: [internal, wait("machine", "等待借机", 2), wait("unknown", "验证", 1)] };
  const before = JSON.stringify(record);
  assert.equal(api.taskEffectiveCycleMs(record, Date.parse(at(0)), Date.parse(at(10))), 10 * day);
  assert.equal(api.activeWaitingTasks(record).length, 0);
  assert.equal(api.waitingTaskTiming(internal, Date.parse(at(10))), null);
  assert.equal(JSON.stringify(record), before);
  assert.equal(api.isExternalVerification({ ...internal, verificationKind: "external" }), false);
  const legacy = { id: "a", owner: "张伟", status: "等待反馈", waitingFeedbackPeriods: [{ id: "old", reason: "等待内部验证", startedAt: at(1), startedBy: "张伟" }] };
  const migrated = api.migrateWaitingTasks(legacy);
  assert.equal(migrated.waitingTasks[0].reason, "等待内部验证");
  assert.equal(migrated.waitingTasks[0].verificationKind, "internal");
  assert.equal(api.isTaskWaiting(migrated), false);
  assert.equal(api.taskEffectiveCycleMs(migrated, Date.parse(at(0)), Date.parse(at(10))), 10 * day);
});

test("external records never deduct their parent's own task lifecycle", () => {
  const external = wait("external", "验证", 1, 4, { verificationKind: "external", legacyPeriodId: "legacy" });
  const record = { waitingTasks: [external, wait("overlap", "等待外部反馈", 3, 5), wait("internal", "等待内部验证", 0, 10)],
    waitingFeedbackPeriods: [{ id: "legacy", reason: "等待外部反馈", startedAt: at(1), endedAt: at(4) }] };
  assert.equal(api.taskEffectiveCycleMs(record, Date.parse(at(0)), Date.parse(at(10))), 10 * day);
  assert.equal(api.taskEffectiveCycleMs(record, Date.parse(at(2)), Date.parse(at(4))), 2 * day);
  assert.equal(api.waitingTaskTiming(wait("future", "外部验证", 9), Date.parse(at(8))), null);
});

test("Case external periods count without manual pause, union duplicates and exclude internal records", () => {
  const item = { id: "c", status: "已关闭", createdAt: at(0), tasks: [{ waitingTasks: [wait("task", "外部验证", 0, 12)] }] };
  const closure = { state: "closed", closedAt: at(12), verificationStartedAt: at(10), verificationEndedAt: at(11),
    externalVerificationPeriods: [
      caseWait("analysis", "analysis", 2, 4), caseWait("duplicate", "analysis", 3, 5),
      caseWait("solution", "solution", 10, 11),
      caseWait("not-pausing", "analysis", 5, 9, { pausesCase: false }),
      caseWait("internal", "solution", 5, 9, { verificationKind: "internal" }),
      caseWait("planned", "analysis", 5, 9, { status: "待开始" }),
    ],
  };
  const result = api.caseCycleMetrics(item, closure, Date.parse(at(12)));
  assert.equal(result.total, 12 * day, "closing, not external-validation end, defines total");
  assert.equal(result.excluded, 8 * day);
  assert.equal(result.effective, 4 * day);
  assert.equal(api.caseCycleMetrics(item, { state: "closed", closedAt: at(12), rootCauseAt: at(5) }).effective, 12 * day);
});

test("open Case analysis wait is counted without requiring rootcause/solution state", () => {
  const item = { status: "进行中", createdAt: at(0) };
  const closure = { state: "reopened", externalVerificationPeriods: [caseWait("analysis", "analysis", 3)] };
  const result = api.caseCycleMetrics(item, closure, Date.parse(at(8)));
  assert.equal(result.total, 8 * day);
  assert.equal(result.effective, 3 * day);
  assert.equal(result.excluded, 5 * day);
});

test("new example: Case 12/9, center 12/9, PTE 8/7, internal mean 13/3 excludes four external tasks", () => {
  const { caseItem, closure } = api.dashboardDemoScenarios.find(s => s.caseItem.id === "cycle-external-scope");
  const now = Date.parse(closure.closedAt);
  const metrics = api.caseCycleMetrics(caseItem, closure, now);
  assert.equal(metrics.total, 12 * day); assert.equal(metrics.effective, 9 * day);
  const record = api.departmentCaseRecord(caseItem, caseItem.tasks, closure, now);
  const center = api.summarizeDepartment([record], new Set(["PTE", "CP"]));
  assert.equal(center.totalAverage, 12 * day); assert.equal(center.average, 9 * day);
  assert.equal(center.taskCount, 7); assert.equal(center.internalTaskCount, 3);
  assert.equal(center.taskAverage, 13 / 3 * day);
  const pte = api.summarizeDepartment([record], new Set(["PTE"]));
  assert.equal(pte.totalAverage, 8 * day); assert.equal(pte.average, 7 * day);
  const hierarchy = api.departmentTreeFor(["PTE", "CP", "DA"]);
  const pteWithChildren = api.summarizeDepartment([record], api.departmentScope(hierarchy, "PTE", true));
  assert.equal(pteWithChildren.totalAverage, 12 * day);
  assert.equal(pteWithChildren.average, 9 * day);
  assert.equal(pteWithChildren.taskCount, 7);
  assert.equal(pteWithChildren.taskAverage, 13 / 3 * day);
  assert.equal(api.summarizeDepartment([record], api.departmentScope(hierarchy, "SAE", true)).count, 0);
  assert.deepEqual(Array.from(caseItem.tasks.slice(0, 3), task => api.taskEffectiveCycleMs(task, Date.parse(task.createdAt), Date.parse(task.statusHistory.at(-1).at)) / day), [7, 4, 2]);
});

test("partial overlap, full overlap and disjoint external time use interval difference automatically", () => {
  const task = (id, department, start, end, external = false) => ({
    id, code: id, title: id, department, owner: department, status: "已完成", createdAt: at(start),
    statusHistory: [{ status: "进行中", at: at(start) }, { status: "已完成", at: at(end) }],
    ...(external ? { externalVerification: { sourceId: id, parentTaskId: "i" } } : {}),
  });
  for (const [externalStart, externalEnd, total, effective, excluded] of [
    [2, 6, 6, 4, 2], [1, 3, 4, 4, 0], [5, 7, 6, 4, 2],
  ]) {
    const tasks = [task("i", "PTE", 0, 4), task("e", "PTE", externalStart, externalEnd, true)];
    const item = { id: "c", status: "已关闭", createdAt: at(0), tasks };
    const closure = { state: "closed", closedAt: at(8) };
    const result = api.caseCycleMetrics(item, closure, Date.parse(at(8)));
    assert.equal(result.excluded, excluded * day);
    assert.equal(result.effective, (8 - excluded) * day, "Case retains non-verification gaps");
    const department = api.summarizeDepartment([api.departmentCaseRecord(item, tasks, closure, Date.parse(at(8)))], new Set(["PTE"]));
    assert.equal(department.totalAverage, total * day);
    assert.equal(department.average, effective * day);
    assert.equal(department.taskCount, 2);
    assert.equal(department.taskAverage, 4 * day);
  }
  const tasks = [task("i", "CP", 0, 4), task("e", "PTE", 2, 6, true)];
  const item = { id: "c", status: "已关闭", createdAt: at(0), tasks };
  const closure = { state: "closed", closedAt: at(6) };
  const record = api.departmentCaseRecord(item, tasks, closure, Date.parse(at(6)));
  const pte = api.summarizeDepartment([record], new Set(["PTE"]));
  assert.equal(pte.totalAverage, 4 * day); assert.equal(pte.average, 0);
  assert.equal(pte.taskAverage, null); assert.equal(pte.taskSampleCount, 0);
  const center = api.summarizeDepartment([record], new Set(["PTE", "CP"]));
  assert.equal(center.totalAverage, 6 * day); assert.equal(center.average, 4 * day);
  assert.equal(api.caseCycleMetrics(item, closure, Date.parse(at(6))).effective, 4 * day);
});
