import assert from "node:assert/strict";
import { chromium, expect } from "@playwright/test";
import { build } from "esbuild";
import { readdirSync } from "node:fs";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../", import.meta.url));
const { outputFiles } = await build({
  stdin: { resolveDir: root, loader: "tsx", contents: `
    import React from "react";
    import { createRoot } from "react-dom/client";
    import { CreateCaseMindMapFlow } from "./src/app/components/CreateCaseMindMapFlow";
    import { CreateCaseWbsTable } from "./src/app/components/CreateCaseWbsTable";
    import { mockCases } from "./src/app/components/data";
    function App() {
      const [groups, setGroups] = React.useState([{id:"root", thought:"原始分析",category:"Other",actions:[{id:"parent",title:"原任务",assignee:"张伟",department:"PTE",urgency:"一般",dueDate:"2026-12-01",childGroups:[]}]}]);
      const [table,setTable] = React.useState(false);
      window.draftGroups = groups;
      return <><button onClick={()=>setTable(!table)}>切换视图</button>{table
        ? <CreateCaseWbsTable caseData={mockCases[0]} thoughtGroups={groups} onGroupsChange={setGroups}/>
        : <CreateCaseMindMapFlow caseData={mockCases[0]} thoughtGroups={groups} onGroupsChange={setGroups} coachEnabled={false}/>}</>;
    }
    createRoot(document.getElementById("root")).render(<App/>);
  ` },
  bundle: true, write: false, format: "iife", platform: "browser", jsx: "automatic",
  loader: { ".css": "empty", ".png": "dataurl", ".svg": "dataurl" },
  define: { "process.env.NODE_ENV": '"production"' },
});
const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 1800, height: 1100 } });
  const errors = [];
  page.on("pageerror", error => errors.push(error.message));
  await page.goto(new URL("../V1.1.0.html", import.meta.url).href);
  await page.setContent('<html><head></head><body><div id="root"></div></body></html>');
  await page.addStyleTag({ path: `${root}/dist/assets/${readdirSync(`${root}/dist/assets`).find(name => name.endsWith(".css"))}` });
  await page.addScriptTag({ content: outputFiles[0].text });
  const parent = page.locator('.react-flow__node[data-id="parent"]');
  await expect(parent).toBeVisible();
  await page.waitForTimeout(1000);
  await parent.hover(); await page.waitForTimeout(350); await parent.hover();
  await parent.getByTitle("基于此动作添加思路", { exact: true }).click();
  await page.getByLabel("思路标签").selectOption("validation");
  await page.getByPlaceholder("请填写工作思路").fill("内部与外部验证");
  await page.getByRole("button", { name: "确认", exact: true }).click();
  const thoughtId = await page.evaluate(() => window.draftGroups[0].actions[0].childGroups[0].id);
  const thought = page.locator(`.react-flow__node[data-id="${thoughtId}"]`);
  await thought.hover(); await page.waitForTimeout(350); await thought.hover();
  await thought.getByTitle("新增验证任务", { exact: true }).click();
  const action = page.locator(".react-flow__node").filter({ has: page.getByLabel("任务标签") });
  await expect(action.getByLabel("任务标签")).toHaveValue("验证");
  await expect(action.getByLabel("任务标签")).toBeDisabled();
  await action.getByPlaceholder("符合预期怎么做 + 不符合怎么做").fill("验证报告");
  await action.getByPlaceholder("预期", { exact: true }).fill("报告与结果一致");
  await action.getByPlaceholder("@ 选择任务负责人", { exact: true }).fill("张伟");
  await action.getByRole("button").filter({ hasText: "张伟" }).click();
  await action.getByRole("button", { name: "确认", exact: true }).click();
  const saved = await page.evaluate(() => window.draftGroups[0].actions[0].childGroups[0].actions[0]);
  assert.equal(saved.type, "验证"); assert.equal(saved.dueDate, "");
  const leaf = page.locator(`.react-flow__node[data-id="${saved.id}"]`);
  await expect(leaf.locator(".react-flow__handle.source")).toHaveCount(0);
  await expect(leaf.getByTitle("基于此动作添加思路", { exact: true })).toHaveCount(0);
  await page.getByRole("button", { name: "切换视图", exact: true }).click();
  await expect(page.getByText("内部与外部验证", { exact: true })).toBeVisible();
  await expect(page.getByText("验证报告", { exact: true })).toBeVisible();
  const row = page.getByRole("row").filter({ hasText: "验证报告" });
  await expect(row.getByRole("button", { name: "新增思路", exact: true })).toHaveCount(0);
  assert.deepEqual(errors, []);
  console.log("PASS new Case validation label, free text, verification-only task, optional date, leaf constraints and WBS view switch");
} finally { await browser.close(); }
