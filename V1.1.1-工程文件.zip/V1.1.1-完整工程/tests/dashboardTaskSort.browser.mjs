import assert from "node:assert/strict";
import { chromium, expect } from "@playwright/test";
const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 1800, height: 1100 } });
  const errors = [];
  page.on("pageerror", e => errors.push(e.message));
  await page.addInitScript(() => {
    const task = (id, day, duration, urgency, external = false) => ({
      id, code: id, title: id, owner: "张伟", supervisor: "张伟", department: "PTE", urgency, status: "已完成",
      createdAt: `2026-09-${day}T00:00:00Z`,
      statusHistory: [{status:"进行中",at:`2026-09-${day}T00:00:00Z`},{status:"已完成",at:`2026-09-${Number(day)+duration}T00:00:00Z`}],
      ...(external ? {type:"验证",externalVerification:{sourceId:id,parentTaskId:"sort-internal"}} : {}),
    });
    const rows = [
      task("sort-internal", "20", 2, "一般"),
      task("sort-external-a", "21", 3, "紧急", true),
      task("sort-external-b", "22", 1, "不紧急", true),
      {...task("sort-external-missing", "20", 1, "一般", true), createdAt: undefined, statusHistory: []},
    ];
    localStorage.setItem("ea_case_task_trees_v1",JSON.stringify({c001:rows}));
  });
  await page.goto(new URL("../V1.1.1.html",import.meta.url).href);
  for(let i=0;i<16;i++){
    const b=page.getByRole("button",{name:/^(下一步|下一页|开始使用|开始体验|进入系统|知道了)$/}).last();
    if(!await b.isVisible())break;
    await b.click();await page.waitForTimeout(100);
  }
  await page.getByText("万能看板",{exact:true}).first().click();
  const summary=await page.getByRole("table",{name:"部门 Cycle Time 统计"}).innerText();
  await page.getByLabel("万能看板 Case 排序").selectOption("tat");
  await page.getByRole("button",{name:/^任务 ·/}).click();
  const taskSort=page.getByLabel("万能看板任务排序",{exact:true});
  await expect(taskSort.locator("option")).toHaveText(["紧迫度","创建时间","任务 Cycle Time"]);
  const direction=page.getByRole("button",{name:"切换排序方向"});
  const order=async attr=>page.locator(`[${attr}^="sort-"]`).evaluateAll((nodes,attr)=>nodes.map(n=>n.getAttribute(attr)),attr);
  await taskSort.selectOption("cycle");
  assert.deepEqual(await order("data-department-task"),["sort-external-a","sort-internal","sort-external-b","sort-external-missing"]);
  await direction.click();
  assert.deepEqual(await order("data-department-task"),["sort-external-b","sort-internal","sort-external-a","sort-external-missing"]);
  await page.getByRole("button",{name:/^外部验证任务 ·/}).click();
  const externalSort=page.getByLabel("万能看板外部验证任务排序",{exact:true});
  await expect(externalSort.locator("option")).toHaveText(["紧迫度","创建时间","验证时长","开始时间","结束时间"]);
  await expect(direction).toHaveText("倒序");
  for(const [key,desc] of [
    ["created",["sort-external-b","sort-external-a","sort-external-missing"]],
    ["cycle",["sort-external-a","sort-external-b","sort-external-missing"]],
    ["started",["sort-external-b","sort-external-a","sort-external-missing"]],
    ["ended",["sort-external-a","sort-external-b","sort-external-missing"]],
  ]){
    await externalSort.selectOption(key);
    assert.deepEqual(await order("data-department-wait"),desc);
    await direction.click();
    assert.deepEqual(await order("data-department-wait"),[desc[1],desc[0],desc[2]]);
    await direction.click();
  }
  await page.getByRole("button",{name:/^任务 ·/}).click();
  await expect(taskSort).toHaveValue("cycle");await expect(direction).toHaveText("正序");
  await page.getByRole("button",{name:/^Case ·/}).click();
  await expect(page.getByLabel("万能看板 Case 排序")).toHaveValue("tat");
  await expect(direction).toHaveText("倒序");
  assert.equal(await page.getByRole("table",{name:"部门 Cycle Time 统计"}).innerText(),summary);
  await expect(page.getByRole("button",{name:/^(Case|任务|外部验证任务)明细/})).toHaveCount(0);
  assert.deepEqual(errors,[]);
  console.log("PASS three renamed tabs, independent sorts/directions, numeric/date ordering, nulls last and unchanged statistics");
} finally { await browser.close(); }
