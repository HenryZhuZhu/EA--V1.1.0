import assert from "node:assert/strict";
import { chromium, expect } from "@playwright/test";
import { build } from "esbuild";
import vm from "node:vm";
import { fileURLToPath } from "node:url";

const { outputFiles } = await build({
  stdin: { resolveDir: fileURLToPath(new URL("../", import.meta.url)), contents: `
    export { mockCases } from "./src/app/components/data";
    export { buildCaseWorkbenchRows, sortCaseWorkbenchRows } from "./src/app/components/caseWorkbenchModel";` },
  bundle: true, write: false, format: "cjs", platform: "node",
});
const box = { module: { exports: {} }, btoa, atob };
vm.runInNewContext(outputFiles[0].text, box);
const api = box.module.exports;
const base = JSON.parse(JSON.stringify(api.mockCases[0]));
const cases = [
  { ...base, id: "sort-a", code: "SORT-A", name: "排序示例 A", level: "L3", urgency: "非常紧急", updatedAt: "2026-09-10", tasks: [{ id: "sort-task-a", code: "SORT-A.001", title: "排序任务 A", owner: "张伟", department: "PTE", progress: 90, status: "进行中", createdAt: "2026-09-01", urgency: "一般" }] },
  { ...base, id: "sort-b", code: "SORT-B", name: "排序示例 B", level: "L1", urgency: "一般", updatedAt: "2026-09-25", tasks: [{ id: "sort-task-b", code: "SORT-B.001", title: "排序任务 B", owner: "张伟", department: "PTE", progress: 10, status: "进行中", createdAt: "2026-09-01", urgency: "一般" }] },
  { ...base, id: "sort-c", code: "SORT-C", name: "排序示例 C", level: "L2", urgency: "紧急", updatedAt: "2026-09-15", tasks: [{ id: "sort-task-c", code: "SORT-C.001", title: "排序任务 C", owner: "张伟", department: "PTE", progress: 50, status: "进行中", createdAt: "2026-09-01", urgency: "一般" }] },
].map(item => ({ ...item, owner: "张伟", createdBy: "张伟", status: "进行中", createdAt: "2026-09-01", participants: [], fanoutSourceCaseId: undefined, source: "手动" }));
const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 1800, height: 1100 } });
  const errors = [];
  page.on("pageerror", error => errors.push(error.message));
  await page.goto(process.env.EA_PREVIEW_URL || new URL("../V1.1.1.html", import.meta.url).href);
  await page.evaluate(cases => {
    const domain = JSON.parse(localStorage.getItem("ea_domain_v6"));
    domain.spawnedCases.push(...cases);
    localStorage.setItem("ea_domain_v6", JSON.stringify(domain));
    const closures = JSON.parse(localStorage.getItem("ea_case_closures_v4") || "{}");
    for (const [id, rootCauseAt] of [["sort-a", "2026-09-10"], ["sort-b", "2026-09-04"], ["sort-c", null]]) {
      closures[id] = { caseId: id, state: "rootcause", verificationStartedAt: rootCauseAt };
    }
    localStorage.setItem("ea_case_closures_v4", JSON.stringify(closures));
  }, cases);
  await page.reload();
  for (let i = 0; i < 16; i++) {
    const next = page.getByRole("button", { name: /^(下一步|下一页|开始使用|开始体验|进入系统|知道了)$/ }).last();
    if (!await next.isVisible()) break;
    await next.click(); await page.waitForTimeout(100);
  }
  await page.getByText("万能看板", { exact: true }).first().click();
  const sort = page.getByLabel("万能看板 Case 排序", { exact: true });
  await expect(sort.locator("option")).toHaveText(["紧迫度", "层级", "进度", "更新时间", "Case TAT"]);
  const direction = page.getByRole("button", { name: "切换排序方向", exact: true });
  await expect(direction).toHaveText("倒序");
  const table = page.getByRole("table", { name: "部门 Cycle Time 统计" });
  const summary = await table.innerText();
  const rows = api.buildCaseWorkbenchRows(cases, { products: [], closure: () => undefined, isSubscribed: () => false, loadTree: item => item.tasks });
  for (const mode of ["urgency", "level", "progress", "updated"]) {
    await sort.selectOption(mode);
    for (const order of ["desc", "asc"]) {
      const actual = await page.getByRole("button", { name: /^展开 SORT-/ }).evaluateAll(elements => elements.map(element => element.getAttribute("aria-label").replace("展开 ", "")));
      const reverse = mode === "progress" ? order === "desc" : order === "asc";
      assert.deepEqual(actual, Array.from(api.sortCaseWorkbenchRows(rows, mode, new Date(), false, false, reverse), row => row.record.code));
      assert.equal(await table.innerText(), summary);
      await direction.click();
    }
  }
  await sort.selectOption("tat");
  for (const expected of [["SORT-A", "SORT-B", "SORT-C"], ["SORT-B", "SORT-A", "SORT-C"]]) {
    const actual = await page.getByRole("button", { name: /^展开 SORT-/ }).evaluateAll(elements => elements.map(element => element.getAttribute("aria-label").replace("展开 ", "")));
    assert.deepEqual(actual, expected);
    assert.equal(await table.innerText(), summary);
    await direction.click();
  }
  const tabs = await page.getByRole("button", { name: /^Case ·/ }).boundingBox();
  const control = await sort.boundingBox();
  assert.ok(control.x > tabs.x + tabs.width);
  assert.ok(Math.abs(control.y - tabs.y) < 16);
  const expand = page.getByRole("button", { name: "展开 EA-260901000095", exact: true });
  const card = expand.locator("xpath=ancestor::div[contains(@class,'shadow-')][1]");
  const primary = card.locator('[data-case-summary-row="primary"]');
  await expect(primary.locator("[data-case-total-cycle]")).toHaveText("Case 总 Cycle Time · 12.0 天");
  await expect(primary).toContainText("Case 有效 Cycle Time · 9.0 天");
  await expand.click();
  await sort.selectOption("urgency");
  await expect(expand).toHaveAttribute("aria-expanded", "true");
  await page.setViewportSize({ width: 1440, height: 1000 });
  const boxes = await primary.locator(":scope > button[title], :scope > div.ml-auto").evaluateAll(elements => elements.map(element => element.getBoundingClientRect().toJSON()));
  assert.ok(boxes[0].right <= boxes[1].left);
  await page.getByRole("button", { name: /^任务 ·/ }).click();
  await expect(sort).toHaveCount(0);
  await page.getByRole("button", { name: /^Case ·/ }).click();
  await expect(sort).toHaveValue("urgency");
  assert.deepEqual(errors, []);
  console.log("PASS reused sort options and algorithm, all four orders, stable statistics/expansion, toolbar position and both primary cycle metrics");
} finally { await browser.close(); }
