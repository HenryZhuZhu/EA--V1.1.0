import assert from "node:assert/strict";
import { chromium, expect } from "@playwright/test";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";
import vm from "node:vm";

const { outputFiles } = await build({ entryPoints: [fileURLToPath(new URL("../src/app/components/data.ts", import.meta.url))], bundle: true, write: false, format: "cjs", platform: "node" });
const box = { module: { exports: {} }, btoa, atob };
vm.runInNewContext(outputFiles[0].text, box);
const base = JSON.parse(JSON.stringify(box.module.exports.mockCases[0]));
const cases = [
  ["one", "张伟", "2026-10-28T09:00:00+08:00"],
  ["two", "张伟", "2026-10-27T09:00:00+08:00"],
  ["three", "李娜", "2026-10-28T09:00:00+08:00"],
].map(([id, createdBy, createdAt]) => ({
  ...base, id: `filter-${id}`, code: `FILTER-${id}`, name: `共享筛选验收 ${id}`, owner: "张伟",
  createdBy, createdAt, updatedAt: createdAt, status: "进行中", departments: ["PTE"],
  participants: [], source: "手动", fanoutSourceCaseId: undefined,
  tasks: [
    { id: `filter-task-${id}`, code: `FILTER-${id}.001`, title: `普通分析 ${id}`, owner: "张伟", supervisor: "张伟", department: "PTE", urgency: "一般", status: "进行中", createdAt, progress: 10 },
    { id: `filter-ext-${id}`, code: `FILTER-${id}.002`, title: `外部验证 ${id}`, owner: "张伟", supervisor: "张伟", department: "PTE", urgency: "一般", status: "进行中", createdAt, progress: 0, type: "验证", externalVerification: { sourceId: id, parentTaskId: `filter-task-${id}` } },
  ],
}));
const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 1800, height: 1100 } });
  const errors = [];
  page.on("pageerror", error => errors.push(error.message));
  await page.goto(new URL("../V1.1.1.html", import.meta.url).href);
  await page.evaluate(cases => {
    const domain = JSON.parse(localStorage.getItem("ea_domain_v6"));
    domain.spawnedCases.push(...cases);
    localStorage.setItem("ea_domain_v6", JSON.stringify(domain));
  }, cases);
  await page.reload();
  for (let i=0;i<16;i++) {
    const b = page.getByRole("button", { name: /^(下一步|下一页|开始使用|开始体验|进入系统|知道了)$/ }).last();
    if (!await b.isVisible()) break;
    await b.click(); await page.waitForTimeout(100);
  }
  const addRule = async (panel, field, value, entity = "Case") => {
    await panel.getByRole("button", { name: "添加维度", exact: true }).click();
    const picker = page.getByLabel("添加自定义维度", { exact: true });
    await picker.getByRole("button", { name: entity, exact: true }).click();
    await picker.getByPlaceholder("搜索名称、分组或字段路径").fill(field);
    await picker.getByRole("option", { name: field, exact: true }).click();
    await panel.getByRole("button", { name: `${entity}·${field}筛选值`, exact: true }).click();
    const values = page.getByLabel(`${entity}·${field}选择筛选值`, { exact: true });
    await values.getByPlaceholder("搜索筛选值").fill(value);
    await values.getByRole("option", { name: value, exact: true }).click();
    await values.getByRole("button", { name: "完成", exact: true }).click();
    await expect(panel).toBeVisible();
  };
  await page.getByText("万能看板", { exact: true }).first().click();
  const summary = page.getByRole("table", { name: "部门 Cycle Time 统计" });
  const originalCount = await summary.locator("tbody td").nth(1).innerText();
  await page.getByRole("button", { name: /^筛选/ }).click();
  const panel = page.getByLabel("Cycle Time Case 筛选", { exact: true });
  await expect(panel.locator('[data-slot="case-filter-panel"]')).toHaveCount(1);
  const baseLabels = ["Case 层级", "Case 紧急程度", "Case 状态", "Case 产品", "Case 部门", "Case 创建人 / 任务分派人"];
  for (const label of baseLabels) await expect(panel.getByLabel(label, { exact: true })).toBeVisible();
  await addRule(panel, "创建人", "张伟");
  await addRule(panel, "创建部门", "PTE");
  await addRule(panel, "创建时间", "2026-10-28");
  await expect(summary.locator("tbody td").nth(1)).toHaveText("1");
  await panel.getByRole("button", { name: "完成", exact: true }).click();
  await expect(page.getByRole("button", { name: "Case · 1", exact: true })).toBeVisible();
  await expect(page.locator("[data-cycle-case-card]")).toHaveCount(1);
  await expect(page.locator('[data-cycle-case-card="filter-one"]')).toBeVisible();
  await page.getByRole("button", { name: "任务 · 2", exact: true }).click();
  await expect(page.locator("[data-department-task]")).toHaveCount(2);
  await page.getByRole("button", { name: "外部验证任务 · 1", exact: true }).click();
  await expect(page.locator('[data-department-wait="filter-ext-one"]')).toBeVisible();
  await page.getByRole("button", { name: /^筛选/ }).click();
  await panel.getByLabel("Case 产品", { exact: true }).selectOption(base.product);
  await expect(summary.locator("tbody td").nth(1)).toHaveText("1");
  await panel.getByRole("button", { name: "重置全部", exact: true }).click();
  await expect(summary.locator("tbody td").nth(1)).toHaveText(originalCount);
  await expect(panel.getByRole("group", { name: "Case·创建部门", exact: true })).toHaveCount(0);
  await panel.getByRole("button", { name: "完成", exact: true }).click();
  await page.getByRole("navigation").getByRole("button", { name: "分析中心", exact: true }).click();
  await page.getByRole("button", { name: /^全部 Case 列表/ }).click();
  await page.getByRole("button", { name: /^筛选/ }).click();
  const analysis = page.getByLabel("分析中心 Case 筛选", { exact: true });
  for (const label of baseLabels) await expect(analysis.getByLabel(label, { exact: true })).toBeVisible();
  await addRule(analysis, "创建人", "张伟");
  await addRule(analysis, "创建部门", "PTE");
  await addRule(analysis, "创建时间", "2026-10-28");
  await analysis.getByRole("button", { name: "完成", exact: true }).click();
  await expect(page.getByText("共享筛选验收 one", { exact: true }).first()).toBeVisible();
  await expect(page.getByText("共享筛选验收 two", { exact: true })).toHaveCount(0);
  await expect(page.getByText("共享筛选验收 three", { exact: true })).toHaveCount(0);
  assert.deepEqual(errors, []);
  console.log("PASS analysis/dashboard share six basic fields and creator/department/date custom filters; all three dashboard lists and statistics follow AND filtering and reset");
} finally { await browser.close(); }
