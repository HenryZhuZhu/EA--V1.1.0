import assert from "node:assert/strict";
import { chromium, expect } from "@playwright/test";

const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 1800, height: 1100 } });
  const errors = [];
  page.on("pageerror", error => errors.push(error.message));
  await page.goto(new URL("../V1.1.1.html", import.meta.url).href);
  for (let i = 0; i < 16; i++) {
    const next = page.getByRole("button", { name: /^(下一步|下一页|开始使用|开始体验|进入系统|知道了)$/ }).last();
    if (!await next.isVisible()) break;
    await next.click(); await page.waitForTimeout(100);
  }
  const nav = page.getByRole("navigation");
  const child = nav.getByRole("button", { name: "业务看板", exact: true });
  await expect(page.locator("#dashboard-subnav").getByRole("button", { name: "业务看板" })).toBeVisible();
  await child.click();
  await expect(child).toHaveAttribute("aria-current", "page");
  await expect(page.getByRole("region", { name: "业务看板" })).toContainText("内容待补充");
  await nav.getByRole("button", { name: "收起万能看板菜单" }).click();
  await expect(child).toHaveCount(0);
  await expect(page.getByRole("heading", { name: "业务看板", exact: true })).toBeVisible();
  await nav.getByRole("button", { name: "展开万能看板菜单" }).click();
  await expect(child).toHaveAttribute("aria-current", "page");
  await nav.getByRole("button", { name: "万能看板", exact: true }).click();
  await expect(page.getByRole("region", { name: "业务看板" })).toBeVisible();
  await expect(child).toHaveCount(0);
  await nav.getByRole("button", { name: "万能看板", exact: true }).click();
  const cycle = nav.getByRole("button", { name: "Cycle Time看板", exact: true });
  await cycle.click();
  await expect(cycle).toHaveAttribute("aria-current", "page");
  await expect(page.getByRole("heading", { name: "Cycle Time看板", exact: true })).toBeVisible();
  await expect(page.getByRole("region", { name: "业务看板" })).toHaveCount(0);
  await expect(page.getByText("部门分析", { exact: true }).first()).toBeVisible();
  await page.getByTitle("收起侧栏", { exact: true }).click();
  await nav.getByTitle("万能看板", { exact: true }).click();
  await expect(child).toBeVisible();
  await child.click();
  await expect(page.getByRole("region", { name: "业务看板" })).toBeVisible();
  await page.getByTitle("收起侧栏", { exact: true }).click();
  await nav.getByTitle("万能看板", { exact: true }).click();
  await expect(page.getByRole("region", { name: "业务看板" })).toBeVisible();
  assert.deepEqual(errors, []);
  console.log("PASS business dashboard child navigation, placeholder, collapse/expand and original dashboard");
} finally {
  await browser.close();
}
