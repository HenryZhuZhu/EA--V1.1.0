import assert from "node:assert/strict";
import { chromium, expect } from "@playwright/test";

const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 1800, height: 1100 } });
  const errors = [];
  page.on("pageerror", error => errors.push(error.message));
  await page.goto(process.env.EA_GUIDE_URL || new URL("../万能看板_指标与甘特图说明.html", import.meta.url).href);
  const expected = [12, 9, 12, 9];
  for (let index = 0; index < expected.length; index++) {
    await page.locator(`[data-metric="${index}"]`).click();
    await expect(page.locator("#selectedResult .value")).toHaveText(`${expected[index]} 天`);
    await expect(page.locator(`[data-metric="${index}"]`)).toHaveAttribute("aria-pressed", "true");
    if (index === 1) {
      await expect(page.locator("#originalChart .row").nth(1).locator(".removed")).toHaveCount(2);
      await expect(page.locator("#metricExplanation")).toContainText("独占");
      await expect(page.locator("#metricExplanation")).toContainText("重合");
    }
  }
  await expect(page.locator("section.panel")).toHaveCount(1);
  const logic = page.locator("#calculationLogic");
  assert.equal(await logic.evaluate(element => element.open), false);
  await expect(logic.getByRole("table", { name: "指标计算公式" })).toBeHidden();
  await logic.locator("summary").click();
  await expect(logic.getByRole("table", { name: "指标计算公式" })).toBeVisible();
  await expect(logic.getByRole("table", { name: "指标计算公式" }).locator("tbody tr")).toHaveCount(8);
  await expect(logic.getByRole("table", { name: "重合扣时示例" }).locator("tbody tr")).toHaveCount(3);
  await expect(logic).toContainText("外部验证不进入分子或分母");
  await logic.locator("summary").click();
  assert.equal(await logic.evaluate(element => element.open), false);
  await expect(page.locator("[data-metric]")).toHaveCount(7);
  await page.locator('[data-metric="6"]').click();
  await expect(page.locator("#selectedResult .value")).toHaveText("9 天");
  await expect(page.locator("#originalChart .row").nth(1).locator(".removed")).toHaveCount(1);
  await expect(page.locator("#originalChart .row").nth(1)).toContainText("9/11 截止");
  await expect(page.locator("#metricExplanation")).toContainText("重新分析");
  await expect(page.locator('[data-metric="2"]')).toContainText("部门 Cycle Time");
  await expect(page.locator('[data-metric="3"]')).toContainText("部门有效 Cycle Time");
  await page.locator('[data-metric="4"]').click();
  await expect(page.getByLabel("选择普通任务")).toHaveValue("-1");
  await expect(page.locator("#selectedResult")).toBeHidden();
  await expect(page.locator("#originalChart .selected .value")).toHaveText(["7 天", "4 天", "2 天"]);
  await expect(page.locator("#originalChart .selected").last()).toContainText("CP 任务 C");
  await expect(page.locator('[data-metric="4"]')).toContainText("平均 4.33 天");
  await page.locator('[data-metric="5"]').click();
  await expect(page.getByLabel("选择外部验证")).toHaveValue("-1");
  await expect(page.locator("#originalChart .selected .value")).toHaveText(["2 天", "1 天", "1 天", "2 天"]);
  await expect(page.locator("#originalChart .bar:not(.ghost):not(.removed)")).toHaveCount(4);
  await expect(page.locator('[data-metric="5"]')).toContainText("合计 6 天");
  await expect(page.locator("#metricExplanation")).toContainText("重合而保留");
  await expect(page.locator("#metricExplanation")).toContainText("不参与任务平均");
  for (const [index, duration] of [2, 1, 1, 2].entries()) {
    await page.getByLabel("选择外部验证").selectOption(String(index));
    await expect(page.locator("#originalChart .selected .value")).toHaveText(`${duration} 天`);
    await expect(page.locator('[data-metric="5"]')).toContainText("合计 6 天");
    await expect(page.locator("#originalChart .bar:not(.ghost):not(.removed)")).toHaveCount(1);
  }
  await page.locator('[data-metric="4"]').click();
  await expect(page.locator("#originalChart .selected .value")).toHaveText(["7 天", "4 天", "2 天"]);
  await page.locator('[data-metric="4"]').click();
  for (const [index, duration] of [7, 4, 2].entries()) {
    await page.getByLabel("选择普通任务").selectOption(String(index));
    await expect(page.locator("#originalChart .selected .value")).toHaveText(`${duration} 天`);
  }
  assert.deepEqual(await page.evaluate(() => numbers), { caseTotal: 12, caseEffective: 9, centerTotal: 12, centerEffective: 9, pteTotal: 12, pteEffective: 9, a: 7, b: 4, c: 2 });
  await expect(page.locator("#originalChart")).not.toContainText("内部验证");
  await expect(page.locator("body")).toContainText("旧内部验证仅保留历史");
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);

  await page.goto(process.env.EA_PREVIEW_URL || new URL("../V1.1.0.html", import.meta.url).href);
  for (let i = 0; i < 16; i++) {
    const next = page.getByRole("button", { name: /^(下一步|下一页|开始使用|开始体验|进入系统|知道了)$/ }).last();
    if (!await next.isVisible()) break;
    await next.click(); await page.waitForTimeout(100);
  }
  await page.getByText("万能看板", { exact: true }).first().click();
  await page.getByRole("complementary", { name: "部门", exact: true }).getByRole("button", { name: "PTE", exact: true }).click();
  const expand = page.getByRole("button", { name: "展开 EA-260901000095", exact: true });
  const card = expand.locator("xpath=ancestor::div[contains(@class,'shadow-')][1]");
  await expect(card.locator('[data-case-summary-row="primary"]')).toContainText("Case 有效 Cycle Time · 9.0 天");
  await expect(card.locator('[data-case-summary-row="secondary"]')).toContainText("部门有效 Cycle Time · 9.0 天");
  await expect(card.locator("[data-case-tat]")).toContainText("Case TAT · 9.0 天");
  await expand.click();
  await expect(card.locator('[data-gantt-cycle-time="external-scope-a"]')).toHaveText("7.0 天");
  await expect(card.locator('[data-gantt-cycle-time="external-scope-b"]')).toHaveText("4.0 天");
  await expect(card.locator("[data-gantt-verification]")).toHaveCount(0);
  await expect(card.locator("[data-gantt-row]")).toHaveCount(7);
  const tree = page.getByRole("complementary", { name: "部门", exact: true });
  await tree.getByRole("button", { name: "CP", exact: true }).click();
  await expect(card.locator('[data-case-summary-row="secondary"]')).toContainText("部门有效 Cycle Time · 2.0 天");
  await expect(card.locator("[data-case-tat]")).toContainText("Case TAT · 9.0 天");
  await expand.click();
  await expect(card.locator("[data-gantt-row]")).toHaveCount(2);
  await tree.getByRole("button", { name: "SAE", exact: true }).click();
  await expect(expand).toHaveCount(0);
  await expect(tree.getByRole("button", { name: "展开SAE", exact: true })).toHaveAttribute("aria-expanded", "true");
  await expect(tree.getByRole("button", { name: "DA", exact: true })).toBeVisible();
  await tree.getByRole("button", { name: "DA", exact: true }).click();
  await expect(expand).toHaveCount(0);
  await page.getByRole("complementary", { name: "部门", exact: true }).getByRole("button", { name: "测试中心", exact: true }).click();
  await expect(card.locator('[data-case-summary-row="secondary"]')).toContainText("部门有效 Cycle Time · 9.0 天");
  await page.getByRole("button", { name: /^外部验证任务 ·/ }).click();
  const waits = page.getByRole("region", { name: "验证等待列表", exact: true });
  await expect(waits.locator('[data-department-wait="external-task:external-scope-a:external-scope-a-external"]')).toContainText("2.0 天");
  await expect(waits.locator('[data-department-wait="external-task:external-scope-b:external-scope-b-external"]')).toContainText("1.0 天");
  await expect(waits).not.toContainText("等待内部验证");
  await expect(waits.locator('[data-department-wait="serial-pte-wait"]')).toHaveCount(0);
  assert.deepEqual(errors, []);
  console.log("PASS seven interactive metrics including Case TAT, matching app values, renamed department metrics and external overlap calculations");
} finally { await browser.close(); }
