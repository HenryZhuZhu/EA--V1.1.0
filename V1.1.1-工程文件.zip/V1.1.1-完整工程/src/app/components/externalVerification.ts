import type { ClosureRecord } from "./closures";
import { mergeTatIntervals, type TatInterval } from "./caseTatMath";

export type VerificationKind = "external" | "internal" | "unknown";
export interface CaseExternalVerificationPeriod {
  id: string;
  title: string;
  verificationKind: VerificationKind;
  scope: "case";
  pausesCase: boolean;
  phase: "analysis" | "solution";
  status: "进行中" | "已完成" | "已中止" | "待开始";
  startedAt?: string;
  endedAt?: string;
}

export function isExternalVerification(record: { reason?: string; verificationKind?: VerificationKind }) {
  if (record.reason === "等待内部验证" || record.reason === "等待借机") return false;
  if (record.verificationKind !== undefined) return record.verificationKind === "external";
  return record.reason === "等待外部反馈" || record.reason === "外部验证";
}

// 旧 Case 验证起止字段已明确属于 Case 级验证；只有 rootCauseAt 不能证明发生过外部等待。
export function caseExternalVerificationIntervals(record: ClosureRecord | undefined, end: number): TatInterval[] {
  const intervals: TatInterval[] = [];
  const add = (from?: string | null, to?: string | null) => {
    const start = Date.parse(from ?? ""), finish = Date.parse(to ?? "");
    if (Number.isFinite(start) && Number.isFinite(finish) && finish > start) intervals.push({ start, end: Math.min(finish, end) });
  };
  if (record?.verificationKind !== "internal" && record?.verificationKind !== "unknown") {
    add(record?.verificationStartedAt, record?.verificationEndedAt
      ?? (record?.state === "rootcause" ? new Date(end).toISOString() : record?.state === "closed" ? record.closedAt : undefined));
  }
  record?.verificationHistory?.forEach(entry => {
    if (entry.verificationKind !== "internal" && entry.verificationKind !== "unknown") add(entry.startedAt, entry.at);
  });
  record?.externalVerificationPeriods?.forEach(period => {
    if (period.verificationKind !== "external" || period.scope !== "case" || period.status === "待开始") return;
    add(period.startedAt, period.endedAt ?? (period.status === "进行中" ? new Date(end).toISOString() : undefined));
  });
  return mergeTatIntervals(intervals.filter(interval => interval.end > interval.start));
}
