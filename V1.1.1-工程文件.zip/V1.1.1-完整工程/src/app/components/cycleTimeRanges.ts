import type { CaseItem, TaskNode } from "./data";
import type { ClosureRecord } from "./closures";
import { taskLifecycleTimes } from "./caseTiming";
import type { TatInterval } from "./caseTatMath";

export function cycleTimestamp(value?: string | null) {
  const parsed = Date.parse(value ?? "");
  return Number.isFinite(parsed) ? parsed : undefined;
}

export function caseCycleRange(item: CaseItem, closure?: ClosureRecord, now = Date.now()) {
  const closed = closure ? closure.state === "closed" : ["已关闭", "已结案", "已归档", "已结束"].includes(item.status);
  const start = cycleTimestamp(item.createdAt);
  const finish = closed ? cycleTimestamp(closure?.closedAt) ?? cycleTimestamp(closure?.verificationEndedAt) : now;
  const end = finish === undefined ? undefined : Math.min(finish, now);
  return { closed, interval: start !== undefined && end !== undefined && end >= start ? { start, end } : null };
}

// 部门归属时间必须落在 Case 生命周期内。保留原始事件，不用截断后的值覆写历史。
export function taskCaseRange(item: CaseItem, task: TaskNode, closure?: ClosureRecord, now = Date.now()): { interval: TatInterval | null; issue?: string } {
  const window = caseCycleRange(item, closure, now).interval;
  const lifecycle = taskLifecycleTimes(task, new Date(now));
  const start = cycleTimestamp(lifecycle.createdAt), end = cycleTimestamp(lifecycle.cycleEnd);
  if (!window) return { interval: null, issue: "Case 创建／结案时间缺失或无效，无法统计归属周期" };
  if (start === undefined || end === undefined || end < start) return { interval: null, issue: "任务创建／结束时间缺失或无效" };
  if (end < window.start || start > window.end) return { interval: null, issue: "任务时间完全位于 Case 生命周期之外，不计入周期样本" };
  const clipped = { start: Math.max(start, window.start), end: Math.min(end, window.end) };
  return { interval: clipped, issue: start < window.start || end > window.end ? "任务原始时间超出 Case 生命周期，统计仅取两者交集" : undefined };
}
