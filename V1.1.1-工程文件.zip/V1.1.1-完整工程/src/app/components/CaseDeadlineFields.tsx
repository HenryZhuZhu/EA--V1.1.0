import { Switch } from "./ui/switch";

export function CaseDeadlineFields({ dueDate, onDueDateChange, tatEnabled, onTatEnabledChange, tatDueDate, onTatDueDateChange, allowTat = true }: {
  dueDate: string;
  onDueDateChange: (value: string) => void;
  tatEnabled: boolean;
  onTatEnabledChange: (value: boolean) => void;
  tatDueDate: string;
  onTatDueDateChange: (value: string) => void;
  allowTat?: boolean;
}) {
  const inputClass = "w-full h-10 px-3 rounded-md border border-slate-200 bg-slate-50/60 focus:bg-white focus:border-[#0052D9] outline-none text-sm";
  return <div>
    <div className="mb-1.5 flex items-center gap-2 text-xs tracking-wide text-slate-600">
      <span>截止日期 <span className="text-red-500">*</span></span>
      {allowTat && <Switch aria-label="启用 TAT 截止日期" title="启用 TAT 截止日期" checked={tatEnabled} onCheckedChange={enabled => {
        onTatEnabledChange(enabled);
        if (!enabled) onTatDueDateChange("");
      }} />}
    </div>
    <input aria-label="截止日期" type="date" value={dueDate} onChange={event => onDueDateChange(event.target.value)} className={inputClass} />
    {allowTat && tatEnabled && <label className="mt-3 block text-xs tracking-wide text-slate-600">
      TAT截止日期
      <input aria-label="TAT截止日期" type="date" value={tatDueDate} onChange={event => onTatDueDateChange(event.target.value)} className={`${inputClass} mt-1.5 block`} />
    </label>}
  </div>;
}
