import type { TaskNode } from "./data";
import type { WaitingTask } from "./waitingTasks";
import { isExternalVerification } from "./externalVerification";

export type VerificationDisplayNode =
  | { kind: "verification"; parent: TaskNode }
  | { kind: "specialTask"; parent: TaskNode; specialTask: WaitingTask };

// 展示节点参与布局，但不写入普通任务树，避免影响执行任务数量和完成率。
export function verificationMindMap(nodes: TaskNode[]) {
  const displayNodes = new Map<string, VerificationDisplayNode>();
  const project = (items: TaskNode[]): TaskNode[] => items.map(parent => {
    let children = parent.children ? project(parent.children) : [];
    if (!parent.code || (!parent.verificationNode && !parent.waitingTasks?.length)) {
      return { ...parent, children };
    }
    const savedThought = parent.children?.find(child => child.id === parent.verificationNode?.thoughtId);
    const id = savedThought?.id ?? `verification-view:${parent.id}`;
    children = children.filter(child => child.id !== savedThought?.id);
    const specialTasks = (parent.waitingTasks ?? []).filter(task => !isExternalVerification(task)).map(specialTask => {
      const taskId = `special-view:${parent.id}:${specialTask.id}`;
      displayNodes.set(taskId, { kind: "specialTask", parent, specialTask });
      return {
        id: taskId, code: specialTask.id, title: specialTask.title, owner: specialTask.owner,
        expectation: specialTask.description, dueDate: specialTask.dueDate, createdAt: specialTask.createdAt,
        department: specialTask.department ?? parent.department, urgency: specialTask.urgency ?? parent.urgency, status: specialTask.status,
        attachments: specialTask.attachments, voiceNote: specialTask.voiceNote, note: specialTask.note,
        progress: specialTask.status === "已完成" ? 100 : 0,
      } satisfies TaskNode;
    });
    displayNodes.set(id, { kind: "verification", parent });
    children.push({
      id, title: savedThought?.title || parent.verificationNode?.title || "验证", category: "validation", owner: parent.owner, department: parent.department, urgency: parent.urgency,
      status: "进行中", progress: 0, children: [...(savedThought?.children ?? []), ...specialTasks],
    });
    return { ...parent, children };
  });
  return { tasks: project(nodes), displayNodes };
}
