import type { CaseItem, TaskNode } from "./data";
import type { ClosureRecord } from "./closures";

const date = (day: number) => `2026-09-${String(day).padStart(2, "0")}T09:00:00+08:00`;
function task(id: string, department: string, owner: string, start: number, end: number, wait?: [number, number]): TaskNode {
  return {
    id, code: id, title: `${department} ${wait ? "验证结果分析" : "阶段处理"}`, department, owner, supervisor: "张伟",
    urgency: "一般", status: "已完成", progress: 100, type: "通用", createdAt: date(start), dueDate: date(end).slice(0, 10),
    conclusion: "阶段结果已确认", statusHistory: [{ status: "进行中", at: date(start) }, { status: "已完成", at: date(end) }],
    ...(wait ? {
      verificationNode: { id: `${id}-verification`, createdAt: date(wait[0]) },
      waitingTasks: [{ id: `${id}-wait`, parentTaskId: id, title: "等待内部验证", reason: "等待内部验证" as const,
        owner: "李娜", assignedBy: owner, description: "独立验证期间暂停原任务，其他部门照常推进",
        createdAt: date(wait[0]), endedAt: date(wait[1]), endedBy: "李娜", status: "已完成" as const, result: "验证通过" }],
    } : {}),
  };
}
const specs = [
  { id: "cycle-serial", code: "EA-260901000091", name: "部门串行交接 · 两天等待", start: 1, end: 14, verify: 12,
    tasks: [task("serial-pte", "PTE", "张伟", 3, 8, [4, 6]), task("serial-cp", "CP", "王芳", 8, 12)] },
  { id: "cycle-parallel", code: "EA-260905000092", name: "跨部门并行 · 各自等待", start: 5, end: 20, verify: 18,
    tasks: [task("parallel-pte", "PTE", "刘洋", 7, 16, [9, 12]), task("parallel-ft", "FT", "赵敏", 10, 18)] },
  { id: "cycle-gap", code: "EA-260902000093", name: "同部门分段处理 · 空档不累计", start: 2, end: 23, verify: 21,
    tasks: [task("gap-pte-a", "PTE", "张伟", 4, 7), task("gap-pte-b", "PTE", "刘洋", 15, 19, [16, 18]), task("gap-cp", "CP", "王芳", 7, 12)] },
  { id: "cycle-creator", code: "EA-260906000094", name: "PTE 仅创建 · 无部门任务归属", start: 6, end: 16, verify: 14,
    tasks: [task("creator-da", "DA", "李娜", 8, 14)] },
];
export const dashboardDemoScenarios: { caseItem: CaseItem; closure: ClosureRecord }[] = specs.map((spec, index) => ({
  caseItem: {
    id: spec.id, code: spec.code, name: spec.name, owner: index === 3 ? "李娜" : "张伟", createdBy: "张伟",
    participants: [{ name: "陈磊", department: "EFA" }], level: "L2", urgency: "一般", status: "已关闭",
    reason: "部门周期核对示例", background: spec.name, impact: "模拟数据", levelReason: "周期核对",
    product: index % 2 ? "LPDDR5-7500" : "DDR5-X-6400", material: "Die/IC", density: "16Gb", ioType: "x8",
    failStage: "CP", customer: "演示客户", failPlatform: "演示平台", failMode: "周期对照", ppm: "—", pdId: "—",
    createdAt: date(spec.start), updatedAt: date(spec.end), dueDate: date(spec.end).slice(0, 10), dueIn: 0,
    departments: [...new Set(spec.tasks.map(t => t.department))], tasks: spec.tasks.map(t => ({ ...t, code: `${spec.code}.${spec.tasks.indexOf(t) + 1}` })),
    source: "手动", aiSummary: { progress: "已结案", method: "阶段对照", conclusion: "验证通过", solution: "归档", risk: "无" },
    timeline: [{ time: date(spec.start), user: "张伟", content: "创建示例" }, { time: date(spec.verify), user: "张伟", content: "开始 Case 验证" }, { time: date(spec.end), user: "张伟", content: "结案" }],
  },
  closure: { caseId: spec.id, state: "closed", closedAt: date(spec.end), verificationStartedAt: date(spec.verify), verificationEndedAt: date(spec.end) },
}));

const externalCaseId = "cycle-external-scope";
const externalCode = "EA-260901000095";
const externalTasks = [
  task("external-scope-a", "PTE", "张伟", 1, 8),
  task("external-scope-b", "PTE", "刘洋", 4, 8),
  task("external-scope-c", "CP", "王芳", 9, 11),
].map((item, index): TaskNode => ({
  ...item, code: `${externalCode}.${String(index + 1).padStart(3, "0")}`,
  title: ["客户样品主分析", "客户平台并行分析", "方案回归确认"][index],
  ...(index < 2 ? {
    verificationNode: { id: `${item.id}-verification`, createdAt: date(index === 0 ? 3 : 5), title: "等待外部验证结果" },
    waitingTasks: [{
      id: `${item.id}-external`, parentTaskId: item.id, title: index === 0 ? "客户样品复测" : "客户平台结果确认",
      reason: "外部验证", verificationKind: "external", department: item.department, description: "分析过程中独立开展客户验证，原任务与其他任务照常计时。",
      owner: item.owner, assignedBy: "张伟", createdAt: date(index === 0 ? 3 : 5),
      endedAt: date(index === 0 ? 5 : 6), status: "已完成", result: "客户结果已收到",
    }],
  } : {}),
}));
externalTasks.push(
  { ...task("external-boundary", "PTE", "张伟", 8, 9), code: `${externalCode}.006`, title: "客户确认关键边界", type: "验证", externalVerification: { sourceId: "external-case-analysis", parentTaskId: "external-scope-a" } },
  { ...task("external-acceptance", "CP", "王芳", 11, 13), code: `${externalCode}.007`, title: "客户验收最终方案", type: "验证", externalVerification: { sourceId: "external-case-solution", parentTaskId: "external-scope-c" } },
);
dashboardDemoScenarios.push({
  caseItem: {
    ...dashboardDemoScenarios[0].caseItem,
    id: externalCaseId, code: externalCode, name: "外部验证 · 分析中与方案产出后",
    createdAt: date(1), updatedAt: date(13), dueDate: "2026-09-13", tasks: externalTasks,
    background: "内部分析与客户验证均为独立普通任务。四项客户验证分别归属内部对接负责人的 PTE／CP 部门，不暂停其他任务。",
    timeline: [
      { time: date(1), user: "张伟", content: "创建 Case 并启动分析" },
      { time: date(8), user: "张伟", content: "分析中：独立任务对接客户确认关键边界" },
      { time: date(9), user: "张伟", content: "客户确认完成，恢复分析与回归" },
      { time: date(11), user: "张伟", content: "方案产出，Case 进入验证中；王芳独立对接客户验收" },
      { time: date(13), user: "张伟", content: "外部验收通过，结案" },
    ],
  },
  closure: {
    caseId: externalCaseId, state: "closed", closedAt: date(13), rootCauseAt: date(11),
    externalVerificationPeriods: [
      { id: "external-case-analysis", title: "客户确认关键边界", verificationKind: "external", scope: "case", pausesCase: true, phase: "analysis", status: "已完成", startedAt: date(8), endedAt: date(9) },
      { id: "external-case-solution", title: "客户验收最终方案", verificationKind: "external", scope: "case", pausesCase: true, phase: "solution", status: "已完成", startedAt: date(11), endedAt: date(13) },
    ],
  },
});

export function demoTaskTimeSignature(task: TaskNode) {
  return JSON.stringify({
    status: task.status, createdAt: task.createdAt, statusHistory: task.statusHistory,
    dueDate: task.dueDate, requestedDueDate: task.requestedDueDate,
    activityLog: task.activityLog, recovery: task.recovery, waitingTasks: task.waitingTasks,
    waitingFeedbackPeriods: task.waitingFeedbackPeriods,
  });
}
