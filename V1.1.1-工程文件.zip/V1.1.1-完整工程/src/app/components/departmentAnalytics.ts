import type { CaseItem, TaskNode } from "./data";
import { caseExternalVerificationIntervals } from "./externalVerification";
import { executionTasks, materializeExternalVerificationTasks } from "./externalVerificationTasks";
import { caseCycleRange, cycleTimestamp, taskCaseRange } from "./cycleTimeRanges";
import type { ClosureRecord } from "./closures";
import { mergeTatIntervals, subtractTatIntervals, tatIntervalDuration, type TatInterval } from "./caseTatMath";

export interface DepartmentNode { id: string; name: string; parentId: string | null }
export const DEPARTMENT_TREE: DepartmentNode[] = [
  { id: "test", name: "测试中心", parentId: null },
  ...["SAE", "PTE"].map(name => ({ id: name, name, parentId: "test" })),
  { id: "DA", name: "DA", parentId: "SAE" },
  ...["CP", "FT", "SLT"].map(name => ({ id: name, name, parentId: "PTE" })),
  { id: "pte-product", name: "产品测试组", parentId: "PTE" },
  { id: "pte-ddr", name: "DDR 测试小组", parentId: "pte-product" },
  { id: "pte-lpddr", name: "LPDDR 测试小组", parentId: "pte-product" },
  { id: "pte-dev", name: "测试开发组", parentId: "PTE" },
  { id: "quality", name: "工艺与质量中心", parentId: null },
  ...["PE", "QA", "EFA", "PKG"].map(name => ({ id: name, name, parentId: "quality" })),
  { id: "design", name: "设计与项目中心", parentId: null },
  ...["RD", "PM"].map(name => ({ id: name, name, parentId: "design" })),
];

// 已确认方案的细分组织演示归属，不修改任务原有的一级业务部门。
const DEMO_TASK_DEPARTMENTS: Record<string, string> = {
  "c001/t1": "pte-ddr",
  "c001/t1b": "pte-dev",
  "c001/t1c": "pte-product",
  "c001/t1c_r2": "pte-dev",
  "c001/t3c": "PTE",
};

export function taskDepartmentId(caseId: string, task: TaskNode) {
  return (task.department === "PTE" && DEMO_TASK_DEPARTMENTS[`${caseId}/${task.id}`]) || task.department || "未记录部门";
}

export function departmentTreeFor(departments: string[]): DepartmentNode[] {
  const known = new Set(DEPARTMENT_TREE.map(node => node.id));
  const unknown = [...new Set(departments)].filter(name => !known.has(name));
  return [...DEPARTMENT_TREE, ...(unknown.length ? [
    { id: "__other", name: "其他组织", parentId: null },
    ...unknown.map(name => ({ id: name, name, parentId: "__other" })),
  ] : [])];
}

export function departmentScope(tree: DepartmentNode[], id: string, includeChildren: boolean): Set<string> {
  const result = new Set([id]);
  if (includeChildren) tree.filter(node => node.parentId === id).forEach(child => {
    departmentScope(tree, child.id, true).forEach(value => result.add(value));
  });
  return result;
}

export function departmentPath(tree: DepartmentNode[], id: string): DepartmentNode[] {
  const node = tree.find(item => item.id === id);
  return node ? [...(node.parentId ? departmentPath(tree, node.parentId) : []), node] : [];
}

export interface DepartmentCaseRecord {
  caseItem: CaseItem;
  caseTat?: ReturnType<typeof caseTatMetrics>;
  tasks: { task: TaskNode; departmentId: string; intervals: TatInterval[] | null; totalIntervals?: TatInterval[] | null; timingIssue?: string }[];
  relations?: DepartmentRelation[];
}
export type DepartmentRole = "owner" | "creator" | "collaborator" | "taskOwner";
export const DEPARTMENT_ROLE_LABELS: Record<DepartmentRole, string> = { owner: "Owner", creator: "创建人", collaborator: "协作者", taskOwner: "任务负责人" };
export interface DepartmentRelation { role: DepartmentRole; name: string; departmentId: string }
export function departmentRelations(record: DepartmentCaseRecord, scope: Set<string>) {
  return (record.relations ?? []).filter(relation => scope.has(relation.departmentId));
}

export function departmentCaseRecord(caseItem: CaseItem, tasks: TaskNode[], closure?: ClosureRecord, now = Date.now(), directory: Record<string, string> = {}): DepartmentCaseRecord {
  tasks = [...new Map(executionTasks(materializeExternalVerificationTasks(tasks, directory)).map(task => [task.id, task])).values()];
  const relations: DepartmentRelation[] = [];
  const add = (role: DepartmentRole, name?: string, departmentId?: string) => {
    if (name && !["待指派", "待分派"].includes(name) && departmentId) relations.push({ role, name, departmentId });
  };
  add("owner", caseItem.owner, directory[caseItem.owner]);
  add("creator", caseItem.createdBy, caseItem.createdBy ? directory[caseItem.createdBy] : undefined);
  caseItem.participants?.forEach(person => add("collaborator", person.name, person.department || directory[person.name]));
  tasks.filter(task => task.code).forEach(task => add("taskOwner", task.owner, taskDepartmentId(caseItem.id, task)));
  return {
    caseItem,
    caseTat: caseTatMetrics({ ...caseItem, tasks }, closure, now),
    relations,
    tasks: tasks.filter(task => Boolean(task.code)).map(task => {
      const range = taskCaseRange(caseItem, task, closure, now);
      return {
        task, departmentId: taskDepartmentId(caseItem.id, task),
        timingIssue: range.issue,
        totalIntervals: range.interval ? [range.interval] : null,
        intervals: range.interval ? [range.interval] : null,
      };
    }),
  };
}

export function medianCycleTime(values: number[]) {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

export function summarizeDepartment(records: DepartmentCaseRecord[], scope: Set<string>, roles: DepartmentRole[] = ["owner", "creator", "collaborator", "taskOwner"]) {
  const related = new Map<string, DepartmentCaseRecord>();
  const grouped = new Map<string, { record: DepartmentCaseRecord; intervals: TatInterval[]; totalIntervals: TatInterval[]; hasTime: boolean }>();
  const taskValues = new Map<string, number | null>();
  const allTaskIds = new Set<string>();
  records.forEach(record => {
    const matches = record.relations
      ? departmentRelations(record, scope).some(relation => roles.includes(relation.role))
      : roles.includes("taskOwner") && record.tasks.some(task => scope.has(task.departmentId));
    if (!matches) return;
    related.set(record.caseItem.id, record);
    const tasks = record.tasks.filter(task => scope.has(task.departmentId));
    if (!tasks.length) return;
    const current = grouped.get(record.caseItem.id) ?? { record, intervals: [], totalIntervals: [], hasTime: false };
    tasks.forEach(task => {
      const key = `${record.caseItem.id}/${task.task?.id ?? task.departmentId}`;
      allTaskIds.add(key);
      if (!task.task?.externalVerification) taskValues.set(key, task.intervals === null ? null : tatIntervalDuration(task.intervals));
      if (task.intervals !== null) {
        current.hasTime = true;
        if (!task.task?.externalVerification) current.intervals.push(...task.intervals);
        current.totalIntervals.push(...(task.totalIntervals ?? task.intervals));
      }
    });
    grouped.set(record.caseItem.id, current);
  });
  const samples = [...grouped.values()].filter(item => item.hasTime)
    .map(item => tatIntervalDuration(mergeTatIntervals(item.intervals)));
  const totalSamples = [...grouped.values()].filter(item => item.hasTime)
    .map(item => tatIntervalDuration(mergeTatIntervals(item.totalIntervals)));
  const taskSamples = [...taskValues.values()].filter((value): value is number => value !== null);
  const tatSamples = [...related.values()].map(record => record.caseTat?.value)
    .filter((value): value is number => typeof value === "number" && Number.isFinite(value));
  return {
    cases: [...related.values()], count: related.size, processingCount: grouped.size, sampleCount: samples.length,
    average: samples.length ? samples.reduce((sum, value) => sum + value, 0) / samples.length : null,
    median: samples.length ? medianCycleTime(samples) : null,
    totalAverage: totalSamples.length ? totalSamples.reduce((sum, value) => sum + value, 0) / totalSamples.length : null,
    totalMedian: totalSamples.length ? medianCycleTime(totalSamples) : null,
    taskCount: allTaskIds.size, internalTaskCount: taskValues.size, taskSampleCount: taskSamples.length,
    taskAverage: taskSamples.length ? taskSamples.reduce((sum, value) => sum + value, 0) / taskSamples.length : null,
    taskMedian: taskSamples.length ? medianCycleTime(taskSamples) : null,
    caseTatAverage: tatSamples.length ? tatSamples.reduce((sum, value) => sum + value, 0) / tatSamples.length : null,
    caseTatSampleCount: tatSamples.length,
  };
}

export function caseCycleMetrics(caseItem: CaseItem, closure?: ClosureRecord, now = Date.now()) {
  const { closed, interval } = caseCycleRange(caseItem, closure, now);
  if (!interval) return { total: null, effective: null, excluded: null, closed };
  const { start, end } = interval;
  const exclusions = caseExternalExclusiveIntervals(caseItem, closure, now);
  const effective = tatIntervalDuration(subtractTatIntervals([{ start, end }], exclusions));
  return { total: end - start, effective, excluded: end - start - effective, closed };
}

function caseExternalExclusiveIntervals(caseItem: CaseItem, closure: ClosureRecord | undefined, now: number) {
  const end = caseCycleRange(caseItem, closure, now).interval?.end ?? now;
  const internal: TatInterval[] = [], external = caseExternalVerificationIntervals(closure, end);
  executionTasks(materializeExternalVerificationTasks(caseItem.tasks ?? [], {})).forEach(task => {
    const range = taskCaseRange(caseItem, task, closure, now).interval;
    if (range) (task.externalVerification ? external : internal).push(range);
  });
  return subtractTatIntervals(mergeTatIntervals(external), mergeTatIntervals(internal));
}

export interface CaseTatMetrics {
  value: number | null;
  total: number | null;
  excluded: number | null;
  end?: number;
  issue?: string;
}

export function caseTatMetrics(caseItem: CaseItem, closure?: ClosureRecord, now = Date.now()): CaseTatMetrics {
  const invalid = (issue: string): CaseTatMetrics => ({ value: null, total: null, excluded: null, issue });
  const start = cycleTimestamp(caseItem.createdAt);
  if (start === undefined || !Number.isFinite(now) || start > now) return invalid("Case 创建时间缺失或无效，无法计算 Case TAT。");
  const closed = closure ? closure.state === "closed" : ["已关闭", "已结案", "已归档", "已结束"].includes(caseItem.status);
  const verifying = closure ? closure.state === "rootcause" : caseItem.status === "验证中";
  let end = now;
  if (closed || verifying) {
    const resetTimes = [
      ...(closure?.recovery ?? []).filter(entry => entry.kind !== "supplement").map(entry => cycleTimestamp(entry.at)),
      ...(closure?.verificationHistory ?? []).filter(entry => entry.result === "failed").map(entry => cycleTimestamp(entry.at)),
    ].filter((value): value is number => value !== undefined);
    const resetAt = Math.max(start, ...resetTimes);
    // 当前轮次的精确开始时间优先；rootCauseAt 仅用于兼容旧状态进入事件，不代表外部等待。
    const currentEntry = closure?.verificationStartedAt !== undefined
      ? cycleTimestamp(closure.verificationStartedAt)
      : cycleTimestamp(closure?.rootCauseAt);
    const candidates = [
      currentEntry,
      ...(closure?.verificationHistory ?? []).map(entry => cycleTimestamp(entry.startedAt)),
    ].filter((value): value is number => value !== undefined && value >= resetAt && value <= now);
    if (!candidates.length) return invalid("缺少本轮进入验证中的时间，无法计算 Case TAT。");
    end = Math.max(...candidates);
    const closedAt = cycleTimestamp(closure?.closedAt);
    if (closedAt !== undefined && end > closedAt) return invalid("进入验证中的时间晚于结案时间，无法计算 Case TAT。");
  }
  const exclusions = caseExternalExclusiveIntervals(caseItem, closure, end);
  const value = tatIntervalDuration(subtractTatIntervals([{ start, end }], exclusions));
  return { value, total: end - start, excluded: end - start - value, end };
}
