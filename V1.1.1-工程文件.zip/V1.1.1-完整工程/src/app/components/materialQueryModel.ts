export interface MaterialQueryInput { sourceId: string; chipId: string }
export interface MaterialData {
  chipId: string;
  lot: string;
  wafer: string;
  die: string;
  recordedAt: string;
  source: string;
  imageId?: string;
  imageVariant?: number;
  tests: { stage: string; temperature: string; voltage: string; result: string; bin: string }[];
}
export type MaterialQueryStatus = "loading" | "ready" | "empty" | "error";
export interface MaterialQueryRecord {
  chipId: string;
  fingerprint: string;
  requestId: number;
  status: MaterialQueryStatus;
  data?: MaterialData;
  error?: string;
  queriedAt?: string;
}
export interface MaterialQueryGroup { chipId: string; fingerprint: string }
export function materialQueryGroups(inputs: MaterialQueryInput[]): MaterialQueryGroup[] {
  const grouped = new Map<string, Set<string>>();
  inputs.forEach(input => {
    const chipId = input.chipId.trim();
    if (!chipId) return;
    const sources = grouped.get(chipId) ?? new Set<string>();
    sources.add(input.sourceId);
    grouped.set(chipId, sources);
  });
  return [...grouped].map(([chipId, sources]) => ({ chipId, fingerprint: JSON.stringify([chipId, [...sources].sort()]) }));
}
export function materialQueryInputError(chipId: string) {
  return chipId.length > 120 || /[\s,，;；<>]/.test(chipId) ? "请每行填写一个 Chip ID，不含空格或分隔符（最多 120 字符）。" : "";
}
export type MaterialQueryExecutor = (chipId: string, signal: AbortSignal) => Promise<MaterialData | null>;

// 仅合成演示数据。未知 ID 返回无记录，不将任意输入伪装成真实查询成功。
export function demoMaterialData(chipId: string): MaterialData | null {
  if (!["CHIP-DEMO-001", "CHIP-DEMO-002", "CHIP-DEMO-NOIMAGE"].includes(chipId)) return null;
  const second = chipId === "CHIP-DEMO-002";
  return {
    chipId, lot: second ? "LOT-DEMO-B" : "LOT-DEMO-A", wafer: second ? "WAFER-12" : "WAFER-07",
    die: second ? "(2, 5)" : "(4, 2)", recordedAt: "2026-10-28 10:20", source: "物料／测试记录库（模拟）",
    imageId: chipId === "CHIP-DEMO-NOIMAGE" ? undefined : second ? "W12-CP1-DEMO" : "W07-CP1-DEMO",
    imageVariant: second ? 3 : 0,
    tests: [
      { stage: "CP1", temperature: "25°C", voltage: "1.10 V", result: "PASS", bin: "BIN 1" },
      { stage: "CP1", temperature: "125°C", voltage: "1.00 V", result: second ? "PASS" : "FAIL", bin: second ? "BIN 1" : "BIN 7" },
    ],
  };
}
export function demoMaterialQueryRecords(): MaterialQueryRecord[] {
  return materialQueryGroups(["CHIP-DEMO-001", "CHIP-DEMO-002"].map(chipId => ({ sourceId: `saved:${chipId}`, chipId }))).map(group => {
    const data = demoMaterialData(group.chipId);
    if (!data) throw new Error(`缺少物料演示数据：${group.chipId}`);
    return { ...group, requestId: 0, status: "ready", data, queriedAt: "2026-10-28T10:30:00+08:00" };
  });
}
export const queryDemoMaterial: MaterialQueryExecutor = (chipId, signal) => new Promise((resolve, reject) => {
  if (signal.aborted) { reject(new DOMException("已取消", "AbortError")); return; }
  const abort = () => { clearTimeout(timer); reject(new DOMException("已取消", "AbortError")); };
  const timer = setTimeout(() => {
    signal.removeEventListener("abort", abort);
    if (chipId === "CHIP-DEMO-ERROR") { reject(new Error("模拟查询服务暂不可用，请重试。")); return; }
    resolve(demoMaterialData(chipId));
  }, 1400);
  signal.addEventListener("abort", abort, { once: true });
});

export class MaterialQuerySession {
  private current = new Map<string, string>();
  private records = new Map<string, MaterialQueryRecord>();
  private pending = new Map<string, AbortController>();
  private sequence = 0;
  constructor(private execute: MaterialQueryExecutor, private changed: () => void, initialRecords: MaterialQueryRecord[] = []) {
    initialRecords.forEach(record => {
      this.records.set(record.chipId, record);
      this.current.set(record.chipId, record.fingerprint);
      this.sequence = Math.max(this.sequence, record.requestId);
    });
  }
  sync(inputs: MaterialQueryInput[]) {
    this.current = new Map(materialQueryGroups(inputs).map(group => [group.chipId, group.fingerprint]));
    let updated = false;
    for (const [chipId, record] of this.records) {
      if (this.current.get(chipId) === record.fingerprint) continue;
      this.pending.get(chipId)?.abort(); this.pending.delete(chipId); this.records.delete(chipId); updated = true;
    }
    if (updated) this.changed();
  }
  list() { return [...this.records.values()]; }
  run(groups: MaterialQueryGroup[], refresh = false) {
    const started: string[] = [];
    for (const group of groups) {
      if (this.current.get(group.chipId) !== group.fingerprint || materialQueryInputError(group.chipId)) continue;
      const old = this.records.get(group.chipId);
      if (old?.status === "loading" || (!refresh && old && old.status !== "error")) continue;
      const controller = new AbortController(), requestId = ++this.sequence;
      this.pending.set(group.chipId, controller);
      this.records.set(group.chipId, { ...group, requestId, status: "loading" }); started.push(group.chipId);
      const valid = () => !controller.signal.aborted && this.current.get(group.chipId) === group.fingerprint
        && this.records.get(group.chipId)?.requestId === requestId;
      Promise.resolve().then(() => this.execute(group.chipId, controller.signal)).then(data => {
        if (!valid()) return;
        if (data && data.chipId !== group.chipId) throw new Error("查询结果与请求的 Chip ID 不一致，请重试。");
        this.records.set(group.chipId, { ...group, requestId, status: data ? "ready" : "empty", data: data ?? undefined, queriedAt: new Date().toISOString() });
      }).catch(error => {
        if (!valid()) return;
        this.records.set(group.chipId, { ...group, requestId, status: "error", error: error instanceof Error ? error.message : "查询失败，请重试。" });
      }).finally(() => {
        if (!valid()) return;
        this.pending.delete(group.chipId); this.changed();
      });
    }
    if (started.length) this.changed();
    return started;
  }
  clear() {
    this.pending.forEach(controller => controller.abort()); this.pending.clear(); this.records.clear(); this.changed();
  }
  dispose() {
    this.pending.forEach(controller => controller.abort()); this.pending.clear(); this.records.clear(); this.current.clear();
  }
}
