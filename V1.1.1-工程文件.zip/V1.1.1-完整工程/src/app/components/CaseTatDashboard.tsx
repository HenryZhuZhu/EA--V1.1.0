import { useEffect, useMemo, useState, type ReactNode } from "react";
import { ArrowDown, ArrowUp, ChevronDown, ChevronRight, Filter, Search } from "lucide-react";
import { currentUser, flattenTasks, mockCases, mockProducts, ownerToDepartment, urgencyBar, type TaskNode } from "./data";
import { StatusBadge } from "./StatusBadge";
import { tatIntervalDuration, type TatInterval } from "./caseTatMath";
import { taskLifecycleTimes } from "./caseTiming";
import { useClosures } from "./closures";
import { loadCaseTaskTree, useCaseTaskRevision } from "./caseTaskTrees";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { CaseFilterPanel, CASE_FILTER_PANEL_CLASS_NAME } from "./CaseFilterPanel";
import { caseFilterOptions, type CaseDimensionValues } from "./CaseFilterFields";
import { activeCustomRules, buildCustomFilterRecords, customFieldCatalog, customFilterOptions, customSelectionRules, matchesCustomRules, type CustomFilterRule } from "./caseCustomFilters";
import { CycleTimeCaseCard } from "./CycleTimeCaseCard";
import { caseDisplayStatus } from "./CaseStatusBadge";
import { WorkbenchSort } from "./WorkbenchSort";
import { buildCaseWorkbenchRows, caseCreators, CASE_WORKBENCH_SORT_OPTIONS, isCaseWorkbenchSort, sortCaseWorkbenchRows, type CaseWorkbenchSort } from "./caseWorkbenchModel";
import {
  departmentCaseRecord, departmentPath, departmentScope, departmentTreeFor, summarizeDepartment, departmentRelations,
} from "./departmentAnalytics";

type PersonRole = "owner" | "creator" | "collaborator" | "taskOwner";
type DashboardCaseSort = CaseWorkbenchSort | "tat";
type DetailTab = "case" | "task" | "waiting";
type TaskDetailSort = "urgency" | "created" | "cycle" | "started" | "ended";
const TASK_SORT_OPTIONS = [
  { value: "urgency", label: "紧迫度" }, { value: "created", label: "创建时间" },
  { value: "cycle", label: "任务 Cycle Time" },
] as const;
const EXTERNAL_SORT_OPTIONS = [
  ...TASK_SORT_OPTIONS.slice(0, 2), { value: "cycle", label: "验证时长" },
  { value: "started", label: "开始时间" }, { value: "ended", label: "结束时间" },
] as const;
function sortDetailTasks<T extends { task: TaskNode; caseItem: { id: string }; intervals: TatInterval[] | null }>(rows: T[], key: TaskDetailSort, direction: "asc" | "desc", now: number): T[] {
  const urgencyRank: Record<string, number> = { 非常紧急: 4, 紧急: 3, 一般: 2, 不紧急: 1 };
  const value = (row: T) => {
    if (key === "urgency") return urgencyRank[row.task.urgency] ?? null;
    if (key === "cycle") return row.intervals === null ? null : tatIntervalDuration(row.intervals);
    const times = taskLifecycleTimes(row.task, new Date(now));
    const raw = key === "created" ? times.createdAt : key === "started" ? times.acceptedAt : times.endedAt;
    const parsed = Date.parse(raw ?? "");
    return Number.isFinite(parsed) ? parsed : null;
  };
  return [...rows].sort((a, b) => {
    const left = value(a), right = value(b);
    const stable = () => a.caseItem.id.localeCompare(b.caseItem.id) || a.task.id.localeCompare(b.task.id);
    if (left === null || right === null) return left === null && right === null ? stable() : left === null ? 1 : -1;
    return (direction === "asc" ? left - right : right - left) || stable();
  });
}
const DASHBOARD_SORT_OPTIONS = [
  ...CASE_WORKBENCH_SORT_OPTIONS.map(option => ({ ...option, label: option.value === "progress" ? "进度" : option.value === "updated" ? "更新时间" : option.label })),
  { value: "tat", label: "Case TAT" },
] as const;
const ROLES: { value: PersonRole; label: string }[] = [
  { value: "owner", label: "作为 Case Owner" }, { value: "creator", label: "作为创建人" },
  { value: "collaborator", label: "作为协作者" }, { value: "taskOwner", label: "作为任务负责人" },
];
const formatDuration = (value: number | null) => value === null ? "—"
  : value < 86400000 ? `${(value / 3600000).toFixed(1)} 小时` : `${(value / 86400000).toFixed(1)} 天`;
const TASK_DETAIL_COLUMNS = "grid grid-cols-[96px_minmax(280px,1fr)_160px_112px] items-center gap-x-6 pl-6 pr-5";
const WAIT_DETAIL_COLUMNS = "grid grid-cols-[96px_minmax(280px,1fr)_112px_176px_112px_160px] items-center gap-x-6 pl-6 pr-5";

export function CaseTatDashboard({ onOpenCase, onOpenTask }: {
  onOpenCase?: (id: string) => void;
  onOpenTask: (caseId: string, taskId: string) => void;
}) {
  const closures = useClosures();
  const revision = useCaseTaskRevision();
  const [now, setNow] = useState(Date.now);
  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 60000);
    return () => window.clearInterval(timer);
  }, []);
  const taskRecords = useMemo(() => mockCases.map(caseItem => ({
    caseItem, tasks: flattenTasks(loadCaseTaskTree(caseItem.id, caseItem.tasks)).map(entry => entry.task).filter(task => Boolean(task.code)),
  })), [revision]);
  const tree = useMemo(() => departmentTreeFor([...Object.values(ownerToDepartment), ...taskRecords.flatMap(record => [
    ...record.tasks.map(task => task.department || "未记录部门"),
    ...(record.caseItem.participants ?? []).map(person => person.department),
  ])].filter(Boolean)), [taskRecords]);
  const [selected, setSelected] = useState("test");
  const [openNodes, setOpenNodes] = useState<string[]>(["test", "PTE", "pte-product"]);
  const [query, setQuery] = useState("");
  const [expandedCases, setExpandedCases] = useState<string[]>([]);
  const [dimensions, setDimensions] = useState<CaseDimensionValues>({ level: "全部", urgency: "全部", status: "全部", product: "全部", department: "全部", creator: "全部" });
  const [customRules, setCustomRules] = useState<CustomFilterRule[]>([]);
  const [personRoles, setPersonRoles] = useState<PersonRole[]>(ROLES.map(role => role.value));
  const [filterOpen, setFilterOpen] = useState(false);
  const [detailTab, setDetailTab] = useState<DetailTab>("case");
  const [sortBy, setSortBy] = useState<DashboardCaseSort>("urgency");
  const [taskSorts, setTaskSorts] = useState<Record<"task" | "waiting", TaskDetailSort>>({ task: "urgency", waiting: "urgency" });
  const [sortDirections, setSortDirections] = useState<Record<DetailTab, "asc" | "desc">>({ case: "desc", task: "desc", waiting: "desc" });
  const sortDirection = sortDirections[detailTab];
  const scope = departmentScope(tree, selected, true);
  const path = departmentPath(tree, selected);
  const current = path[path.length - 1];
  const currentCases = taskRecords.map(({ caseItem, tasks }) => ({ ...caseItem, tasks: tasks.map(task => ({ ...task, children: undefined })) }));
  const filterOptions = caseFilterOptions(currentCases);
  const displayStatus = (item: typeof currentCases[number]) => {
    const closure = closures.get(item.id);
    return caseDisplayStatus(item, { closed: closure?.state === "closed", rootCaused: closure?.state === "rootcause" });
  };
  const customRecords = buildCustomFilterRecords(currentCases, { loadTree: item => item.tasks, status: displayStatus, closure: closures.get, creatorDepartments: ownerToDepartment });
  const customFields = customFieldCatalog(customRecords);
  const appliedCustomRules = activeCustomRules(customSelectionRules(customRules), customFields);
  const customById = new Map(customRecords.map(record => [record.caseData.id, record]));
  const records = taskRecords.filter(({ caseItem: item }) => {
    const custom = customById.get(item.id)!;
    return (dimensions.product === "全部" || item.product === dimensions.product)
      && (dimensions.status === "全部" || displayStatus(item) === dimensions.status)
      && (dimensions.level === "全部" || item.level === dimensions.level)
      && (dimensions.urgency === "全部" || item.urgency === dimensions.urgency)
      && (dimensions.department === "全部" || item.departments?.includes(dimensions.department))
      && (!dimensions.creator || dimensions.creator === "全部" || caseCreators({ ...item, tasks: custom.tasks }).includes(dimensions.creator))
      && matchesCustomRules(custom, appliedCustomRules, customFields);
  }).map(({ caseItem, tasks }) => departmentCaseRecord(caseItem, tasks, closures.get(caseItem.id), now, ownerToDepartment));
  const summary = summarizeDepartment(records, scope, personRoles);
  const sortRows = buildCaseWorkbenchRows(summary.cases.map(record => ({ ...record.caseItem, tasks: record.tasks.map(entry => ({ ...entry.task, children: undefined })) })), {
    products: mockProducts, closure: id => closures.get(id), isSubscribed: () => false, loadTree: item => item.tasks,
  });
  const reverseSort = sortBy === "progress" ? sortDirections.case === "desc" : sortDirections.case === "asc";
  const caseOrder = new Map(sortCaseWorkbenchRows(sortRows, isCaseWorkbenchSort(sortBy) ? sortBy : "urgency", new Date(now), false, false, reverseSort).map((row, index) => [row.id, index]));
  const sortedCases = [...summary.cases].sort((a, b) => {
    if (sortBy === "tat") {
      const left = a.caseTat?.value, right = b.caseTat?.value;
      if (left == null || right == null) return left == null && right == null ? a.caseItem.id.localeCompare(b.caseItem.id) : left == null ? 1 : -1;
      return (sortDirections.case === "desc" ? right - left : left - right) || a.caseItem.id.localeCompare(b.caseItem.id);
    }
    return caseOrder.get(a.caseItem.id)! - caseOrder.get(b.caseItem.id)!;
  });
  const detailTasks = summary.cases.flatMap(record => record.tasks.filter(task => scope.has(task.departmentId)).map(task => ({ ...task, caseItem: record.caseItem })));
  const sortedTasks = sortDetailTasks(detailTasks, taskSorts.task, sortDirections.task, now);
  const waitingDetails = sortDetailTasks(detailTasks.filter(item => item.task.externalVerification), taskSorts.waiting, sortDirections.waiting, now).map(item => {
    const timeline = taskLifecycleTimes(item.task, new Date(now));
    return { ...item, wait: {
      id: item.task.id, title: item.task.title, owner: item.task.owner, department: item.task.department,
      urgency: item.task.urgency, status: item.task.status, createdAt: item.task.createdAt,
      startedAt: timeline.acceptedAt, endedAt: timeline.endedAt,
    } };
  });
  const activeFilterCount = Object.values(dimensions).filter(value => value && value !== "全部").length + appliedCustomRules.length;
  const resetFilters = () => {
    setDimensions({ level: "全部", urgency: "全部", status: "全部", product: "全部", department: "全部", creator: "全部" });
    setCustomRules([]); setPersonRoles(ROLES.map(role => role.value));
  };
  const selectDepartment = (id: string) => {
    setSelected(id);
    setOpenNodes(previous => [...new Set([...previous, ...departmentPath(tree, id).map(node => node.id)])]);
    setExpandedCases([]);
  };
  const renderBranch = (parentId: string | null, depth = 0): ReactNode => tree.filter(node => node.parentId === parentId).map(node => {
    const hasChildren = tree.some(child => child.parentId === node.id);
    const open = openNodes.includes(node.id);
    return <div key={node.id}>
      <div className={`my-0.5 flex min-h-9 items-center rounded-md ${selected === node.id ? "bg-blue-50 text-[#0052D9]" : "text-slate-600 hover:bg-slate-50"}`} style={{ paddingLeft: depth * 14 }}>
        {hasChildren ? <button type="button" aria-label={`展开${node.name}`} aria-expanded={open} onClick={() => setOpenNodes(previous => open ? previous.filter(id => id !== node.id) : [...previous, node.id])} className="grid h-7 w-6 shrink-0 place-items-center text-slate-400"><ChevronRight size={13} className={open ? "rotate-90" : ""} /></button> : <span className="w-6 shrink-0" />}
        <button type="button" aria-current={selected === node.id ? "true" : undefined} onClick={() => selectDepartment(node.id)} className="min-w-0 flex-1 truncate py-2 pr-2 text-left text-xs">{node.name}</button>
      </div>
      {hasChildren && open && renderBranch(node.id, depth + 1)}
    </div>;
  });

  return <div className="grid grid-cols-[240px_minmax(0,1fr)] items-start gap-5">
    <aside aria-label="部门" className="sticky top-4 max-h-[calc(100vh-140px)] overflow-auto rounded-xl border border-slate-200 bg-white p-3">
      <div className="mb-4 px-2"><h3 className="text-sm font-semibold">部门</h3></div>
      <div className="relative mb-3"><Search size={13} className="absolute left-2.5 top-2.5 text-slate-400" /><input aria-label="搜索部门名称" placeholder="搜索部门名称" value={query} onChange={event => setQuery(event.target.value)} className="h-8 w-full rounded-md border border-slate-200 bg-white pl-8 pr-2 text-xs outline-none focus:border-[#0052D9]" /></div>
      {query.trim() ? tree.filter(node => node.name.toLowerCase().includes(query.trim().toLowerCase())).map(node => <button key={node.id} onClick={() => selectDepartment(node.id)} className={`block w-full rounded-md px-2 py-2 text-left text-xs hover:bg-blue-50 ${selected === node.id ? "bg-blue-50 text-[#0052D9]" : ""}`}><span>{node.name}</span><span className="mt-1 block text-[10px] text-slate-400">{departmentPath(tree, node.id).map(item => item.name).join(" / ")}</span></button>) : renderBranch(null)}
      {query.trim() && !tree.some(node => node.name.toLowerCase().includes(query.trim().toLowerCase())) && <div className="py-8 text-center text-xs text-slate-400">未找到匹配部门</div>}
    </aside>
    <div className="min-w-0 space-y-4">
      <section className="overflow-hidden rounded-xl border border-slate-200 bg-white">
        <header className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 px-4 py-3"><h4 className="text-sm font-semibold">部门分析</h4>
        <Popover open={filterOpen} onOpenChange={setFilterOpen}>
          <PopoverTrigger asChild><button className={`inline-flex h-9 items-center gap-1.5 rounded-lg border px-3 text-xs ${filterOpen || activeFilterCount ? "border-[#0052D9]/40 bg-blue-50 text-[#0052D9]" : "border-slate-200 bg-white text-slate-600"}`}><Filter size={13} />筛选{activeFilterCount > 0 && <span className="rounded-full bg-[#0052D9] px-1.5 text-[10px] text-white">{activeFilterCount}</span>}<ChevronDown size={13} /></button></PopoverTrigger>
          <PopoverContent align="end" sideOffset={8} aria-label="Cycle Time Case 筛选" className={CASE_FILTER_PANEL_CLASS_NAME}>
            <CaseFilterPanel values={dimensions} {...filterOptions}
              onChange={(field, value) => setDimensions(previous => ({ ...previous, [field]: value }))}
              customEditor={{ fields: customFields, rules: customRules, optionsFor: field => customFilterOptions(customRecords, field), onChange: rules => setCustomRules(customSelectionRules(rules)) }}
              onReset={resetFilters} onDone={() => setFilterOpen(false)} />
          </PopoverContent>
        </Popover>
        </header>
        <fieldset aria-label="人员身份" className="flex items-center gap-5 border-b border-slate-100 px-4 py-3">
          <span className="shrink-0 text-xs text-slate-500">人员身份</span>
          {ROLES.map(({ value, label }) => <label key={value} className="inline-flex cursor-pointer items-center gap-2 whitespace-nowrap text-xs text-slate-600"><input type="checkbox" checked={personRoles.includes(value)} onChange={event => setPersonRoles(previous => event.target.checked ? [...previous, value] : previous.filter(role => role !== value))} />{label}</label>)}
        </fieldset>
        <div className="overflow-x-auto"><table aria-label="部门 Cycle Time 统计" className="w-full min-w-[960px] table-fixed text-left text-xs [&_th]:px-6 [&_td]:px-6"><colgroup>
          <col style={{ width: "18%" }} /><col style={{ width: "12%" }} /><col style={{ width: "17%" }} />
          <col style={{ width: "20%" }} /><col style={{ width: "13%" }} /><col style={{ width: "20%" }} />
        </colgroup><thead className="whitespace-nowrap bg-slate-50 text-[11px] text-slate-500">
          <tr>
            <th scope="col" className="py-3 font-medium">部门</th>
            <th scope="col" className="py-3 font-medium" title="本部门及下级部门人员以所选身份关联的 Case，按 ID 去重；随人员身份筛选联动">Case 数</th>
            <th scope="col" className="py-3 font-medium" title="所选身份关联的 Case，从创建至最近一次进入验证中（未进入或重新分析则到当前），扣除全案外部独占时段后，按 Case 去重求平均">Case TAT · 平均</th>
            <th scope="col" className="py-3 font-medium" title="按 Case 合并本部门普通任务完整区间，含等待、重叠去重，再按 Case 求平均">部门 Cycle Time · 平均</th>
            <th scope="col" className="border-l border-slate-200 py-3 font-medium" title="包含独立外部验证任务；外部验证不进入右侧任务平均值">任务数</th>
            <th scope="col" className="py-3 font-medium" title="只统计内部任务的创建至结束／当前时长；外部验证任务不参与平均，不扣内部任务自身的并行时间">任务Cycle Time·平均</th>
          </tr>
        </thead><tbody><tr className="bg-blue-50/60 text-lg font-semibold tabular-nums text-slate-900">
          <td className="truncate px-4 py-5 text-base" title={current.name}>{current.name}</td>
          <td className="px-4 py-5">{summary.count}</td>
          <td data-department-case-tat className="px-4 py-5" title={`参与 Case TAT 平均：${summary.caseTatSampleCount} 个 Case（包含仅有关联身份的 Case）`}>{formatDuration(summary.caseTatAverage)}</td>
          <td className="px-4 py-5">{formatDuration(summary.totalAverage)}</td>
          <td className="border-l border-slate-100 py-5" title={`全部任务 ${summary.taskCount} 个；内部任务 ${summary.internalTaskCount} 个，其中 ${summary.taskSampleCount} 个参与任务平均`}>{summary.taskCount}</td>
          <td className="px-4 py-5">{formatDuration(summary.taskAverage)}</td>
        </tr></tbody></table></div>
      </section>
      <div className="flex items-center justify-between gap-4">
        <div className="inline-flex gap-1 rounded-lg bg-slate-100 p-1">{([{ value: "case", label: `Case · ${summary.count}` }, { value: "task", label: `任务 · ${detailTasks.length}` }, { value: "waiting", label: `外部验证任务 · ${waitingDetails.length}` }] as const).map(tab => <button key={tab.value} aria-pressed={detailTab === tab.value} onClick={() => setDetailTab(tab.value)} className={`rounded-md px-3 py-2 text-xs ${detailTab === tab.value ? "bg-white font-medium text-[#0052D9] shadow-sm" : "text-slate-500"}`}>{tab.label}</button>)}</div>
        <div className="flex shrink-0 items-center gap-1.5">
          {detailTab === "case"
            ? <WorkbenchSort value={sortBy} options={DASHBOARD_SORT_OPTIONS} ariaLabel="万能看板 Case 排序" onChange={value => { if (isCaseWorkbenchSort(value) || value === "tat") setSortBy(value); }} />
            : <WorkbenchSort value={taskSorts[detailTab]} options={detailTab === "task" ? TASK_SORT_OPTIONS : EXTERNAL_SORT_OPTIONS} ariaLabel={detailTab === "task" ? "万能看板任务排序" : "万能看板外部验证任务排序"} onChange={value => {
              if (value === "urgency" || value === "created" || value === "cycle" || (detailTab === "waiting" && (value === "started" || value === "ended"))) setTaskSorts(previous => ({ ...previous, [detailTab]: value }));
            }} />}
          <button type="button" aria-label="切换排序方向" title={sortDirection === "asc" ? "当前正序：低到高／旧到新；点击切换倒序" : "当前倒序：高到低／新到旧；点击切换正序"} onClick={() => setSortDirections(previous => ({ ...previous, [detailTab]: previous[detailTab] === "asc" ? "desc" : "asc" }))} className="inline-flex h-8 items-center gap-1 rounded-lg border border-slate-200 bg-white px-2.5 text-xs text-slate-600 hover:bg-slate-50">
            {sortDirection === "asc" ? <ArrowUp size={12} /> : <ArrowDown size={12} />}{sortDirection === "asc" ? "正序" : "倒序"}
          </button>
        </div>
      </div>
      {detailTab === "case" && <div className="space-y-3">{sortedCases.map(record => {
        const local = summarizeDepartment([record], scope, personRoles);
        return <CycleTimeCaseCard key={`${selected}/${record.caseItem.id}`} caseItem={record.caseItem} calculationTime={now} expanded={expandedCases.includes(record.caseItem.id)} onToggle={() => setExpandedCases(previous => previous.includes(record.caseItem.id) ? previous.filter(id => id !== record.caseItem.id) : [...previous, record.caseItem.id])} onOpenCase={onOpenCase} onOpenTask={onOpenTask} scopedTaskIds={record.tasks.filter(task => scope.has(task.departmentId)).map(task => task.task.id)} departmentInfo={{ relations: departmentRelations(record, scope), cycleTime: local.average, totalCycleTime: local.totalAverage, taskCount: local.taskCount, timingIssues: record.tasks.filter(task => scope.has(task.departmentId) && task.timingIssue).map(task => `${task.task.title}：${task.timingIssue}`) }} />;
      })}</div>}
      {detailTab === "task" && <section aria-label="普通任务列表" className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
        <div className="min-w-[900px]">
          <div className={`${TASK_DETAIL_COLUMNS} border-b border-slate-100 bg-slate-50 py-3 text-[11px] text-slate-500`}>
            <span className="w-24 shrink-0">状态</span><span className="min-w-0 flex-1">普通任务 / 所属 Case</span><span className="w-40 shrink-0">任务负责人</span><span className="w-28 shrink-0 text-right">任务 Cycle Time</span>
          </div>
          <div className="divide-y divide-slate-100/70">{sortedTasks.map(({ task, caseItem, intervals, timingIssue }) => <div key={`${caseItem.id}/${task.id}`} data-department-task={task.id} title={timingIssue || `紧急度：${task.urgency}`} className={`${TASK_DETAIL_COLUMNS} group relative min-h-[72px] py-3.5 transition-colors hover:bg-slate-50/60`}>
            <div className={`absolute bottom-1.5 left-0 top-1.5 w-[3px] rounded-r ${urgencyBar[task.urgency]}`} />
            <div className="w-24 shrink-0"><span className="inline-flex items-center gap-1.5 text-[11px] text-slate-500"><StatusBadge status={task.status} size={16} />{task.status}</span></div>
            <div className="min-w-0 flex-1">
              <button onClick={() => onOpenTask(caseItem.id, task.id)} title={task.title} className="block w-full truncate text-left text-sm text-slate-800 hover:text-[#0052D9]">{task.title}</button>
              <button onClick={() => onOpenCase?.(caseItem.id)} disabled={!onOpenCase} title={`${caseItem.code} · ${caseItem.name}`} className="mt-0.5 block w-full truncate text-left text-[11px] text-slate-400 enabled:hover:text-[#0052D9]">{caseItem.code} · {caseItem.name}</button>
            </div>
            <div className="flex w-40 shrink-0 items-center gap-1.5 text-xs text-slate-600">
              <span className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[10px] font-medium ${!task.owner || ["待指派", "待分派"].includes(task.owner) ? "bg-slate-100 text-slate-400" : "bg-[#0052D9]/8 text-[#0052D9]"}`}>{!task.owner || ["待指派", "待分派"].includes(task.owner) ? "—" : task.owner[0]}</span>
              <span className="truncate" title={`${task.department} · ${task.owner}`}>{task.department} · {task.owner}</span>
              {task.owner === currentUser.name && <span className="shrink-0 rounded border border-slate-200 px-1 text-[10px] text-slate-400">我</span>}
            </div>
            <span className="w-28 shrink-0 whitespace-nowrap text-right text-xs tabular-nums text-[#0052D9]">{formatDuration(intervals === null ? null : tatIntervalDuration(intervals))}</span>
          </div>)}</div>
        </div>
        {!detailTasks.length && <div className="p-10 text-center text-xs text-slate-400">相关 Case 中暂无本部门普通任务</div>}
      </section>}
      {detailTab === "waiting" && <section aria-label="验证等待列表" className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
        <div className="min-w-[1160px]">
          <div className={`${WAIT_DETAIL_COLUMNS} border-b border-slate-100 bg-slate-50 py-3 text-[11px] text-slate-500`}>
            <span className="w-24 shrink-0">状态</span><span className="min-w-0 flex-1">任务 / Case</span><span className="w-28 shrink-0 text-right">验证时长</span><span className="w-44 shrink-0">开始 / 结束时间</span><span className="w-28 shrink-0">任务类型</span><span className="w-40 shrink-0">任务负责人</span>
          </div>
          <div className="divide-y divide-slate-100/70">{waitingDetails.map(({ task, caseItem, wait, intervals }) => {
            const unstarted = wait.status === "待接受";
            const department = wait.department || ownerToDepartment[wait.owner] || task.department;
            const unassigned = !wait.owner || ["待指派", "待分派"].includes(wait.owner);
            const urgency = wait.urgency || task.urgency;
            return <div key={`${caseItem.id}/${wait.id}`} data-department-wait={wait.id} title={`紧急度：${urgency}`} className={`${WAIT_DETAIL_COLUMNS} group relative min-h-[72px] py-3.5 transition-colors hover:bg-slate-50/60`}>
              <div className={`absolute bottom-1.5 left-0 top-1.5 w-[3px] rounded-r ${urgencyBar[urgency]}`} />
              <div className="w-24 shrink-0"><span className="inline-flex items-center gap-1.5 text-[11px] text-slate-500"><StatusBadge status={wait.status} size={16} />{wait.status === "已中止" ? "已取消" : wait.status}</span></div>
              <div className="min-w-0 flex-1">
                <button onClick={() => onOpenTask(caseItem.id, task.id)} title={task.title} className="block w-full truncate text-left text-sm text-slate-800 hover:text-[#0052D9]">{task.title}</button>
                <button onClick={() => onOpenCase?.(caseItem.id)} disabled={!onOpenCase} title={`${caseItem.code} · ${caseItem.name}`} className="mt-0.5 block w-full truncate text-left text-[11px] text-slate-400 enabled:hover:text-[#0052D9]">{caseItem.code} · {caseItem.name}</button>
              </div>
              <span className="w-28 shrink-0 whitespace-nowrap text-right text-xs tabular-nums text-[#0052D9]">{formatDuration(intervals === null ? null : tatIntervalDuration(intervals))}</span>
              <div className="w-44 shrink-0 text-[11px] text-slate-500">
                <div>{unstarted ? "尚未接受" : new Date(wait.startedAt ?? wait.createdAt ?? "").toLocaleString("zh-CN")}</div>
                <div className="mt-0.5 text-slate-400">{wait.endedAt ? new Date(wait.endedAt).toLocaleString("zh-CN") : wait.status === "进行中" ? "进行中" : "待任务负责人接受"}</div>
              </div>
              <span className="w-28 shrink-0 truncate text-xs text-slate-600" title={`外部验证 · ${wait.title}`}>外部验证</span>
              <div className="flex w-40 shrink-0 items-center gap-1.5 text-xs text-slate-600">
                <span className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[10px] font-medium ${unassigned ? "bg-slate-100 text-slate-400" : "bg-[#0052D9]/8 text-[#0052D9]"}`}>{unassigned ? "—" : wait.owner[0]}</span>
                <span className="truncate" title={`${department} · ${wait.owner}`}>{department} · {wait.owner}</span>
                {wait.owner === currentUser.name && <span className="shrink-0 rounded border border-slate-200 px-1 text-[10px] text-slate-400">我</span>}
              </div>
            </div>;
          })}</div>
        </div>
        {!waitingDetails.length && <div className="p-10 text-center text-xs text-slate-400">本部门任务暂无验证等待记录</div>}
      </section>}
      {!summary.count && <div className="rounded-xl border border-dashed border-slate-300 bg-white py-12 text-center text-xs text-slate-400">当前范围暂无 Case，请切换部门或重置筛选。</div>}
    </div>
  </div>;
}
