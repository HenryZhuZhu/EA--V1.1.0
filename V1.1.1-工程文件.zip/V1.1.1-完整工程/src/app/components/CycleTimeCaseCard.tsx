import { ChevronDown } from "lucide-react";
import { useEffect, useState } from "react";
import { flattenTasks, levelColors, urgencyBar, type CaseItem } from "./data";
import { useClosures } from "./closures";
import { loadCaseTaskTree, useCaseTaskRevision } from "./caseTaskTrees";
import { caseCycleMetrics, caseTatMetrics, DEPARTMENT_ROLE_LABELS, type DepartmentRelation } from "./departmentAnalytics";
import { formatCaseTime } from "./caseTiming";
import { CaseProductPill } from "./CaseProductPill";
import { CaseMarkCodePill } from "./CaseMarkCodePill";
import { CaseStatusBadge, caseDisplayStatus } from "./CaseStatusBadge";
import { CaseGanttView } from "./CaseGanttView";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";

const durationLabel = (ms: number) => ms < 86400000 ? `${(ms / 3600000).toFixed(1)} 小时` : `${(ms / 86400000).toFixed(1)} 天`;

export function CycleTimeCaseCard({ caseItem, expanded, onToggle, onOpenCase, onOpenTask, scopedTaskIds, departmentInfo, calculationTime }: {
  caseItem: CaseItem;
  expanded: boolean;
  onToggle: () => void;
  onOpenCase?: (id: string) => void;
  onOpenTask: (caseId: string, taskId: string) => void;
  scopedTaskIds?: string[];
  departmentInfo?: { relations: DepartmentRelation[]; cycleTime: number | null; totalCycleTime: number | null; taskCount: number; timingIssues?: string[] };
  calculationTime?: number;
}) {
  const [showAllTasks, setShowAllTasks] = useState(false);
  useCaseTaskRevision();
  const closures = useClosures();
  const closure = closures.get(caseItem.id);
  const taskTree = loadCaseTaskTree(caseItem.id, caseItem.tasks);
  const tasks = flattenTasks(taskTree).map(entry => entry.task).filter(task => Boolean(task.code));
  const visibleTasks = scopedTaskIds && !showAllTasks
    ? tasks.filter(task => scopedTaskIds.includes(task.id)).map(task => ({ ...task, children: undefined }))
    : taskTree;
  const visibleTaskCount = scopedTaskIds && !showAllTasks ? tasks.filter(task => scopedTaskIds.includes(task.id)).length : tasks.length;
  const [now, setNow] = useState(Date.now);
  useEffect(() => { const timer = setInterval(() => setNow(Date.now()), 60000); return () => clearInterval(timer); }, []);
  const metrics = caseCycleMetrics({ ...caseItem, tasks: taskTree }, closure, calculationTime ?? now);
  const tat = caseTatMetrics({ ...caseItem, tasks: taskTree }, closure, calculationTime ?? now);
  const relationRoles = [...new Set(departmentInfo?.relations.map(relation => relation.role) ?? [])];
  const relationNames = (role: DepartmentRelation["role"]) => [...new Set(departmentInfo?.relations.filter(relation => relation.role === role).map(relation => relation.name) ?? [])].join("、");
  const metricValue = (value: number | null) => {
    if (value === null) return <b className="text-sm font-medium text-slate-900">—</b>;
    const [number, unit] = durationLabel(value).split(" ");
    return <span className="min-w-[55px] text-right tabular-nums"><b className="text-sm font-medium text-slate-900">{number}</b><span className="ml-1 text-[11px] text-slate-400">{unit}</span></span>;
  };

  return <div data-cycle-case-card={caseItem.id} className="bg-white border border-slate-200/80 rounded-xl overflow-hidden shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] transition-shadow hover:shadow-md">
    <div className="overflow-x-auto">
    <div className="flex min-w-[820px]">
      <div className={`w-1 shrink-0 ${urgencyBar[caseItem.urgency]}`} title={`紧急度：${caseItem.urgency}`} />
      <div className="min-w-0 flex-1">
        <div data-case-summary-row="primary" className="grid h-12 grid-cols-[minmax(0,1fr)_380px] items-center gap-4 whitespace-nowrap pl-[18px] pr-[18px]">
          <div className="flex min-w-0 items-center gap-[7px]">
          <button aria-label={`展开 ${caseItem.code}`} aria-expanded={expanded} onClick={onToggle} className="grid h-6 w-6 shrink-0 place-items-center rounded text-slate-500 hover:bg-blue-50"><ChevronDown size={14} className={expanded ? "" : "-rotate-90"} /></button>
          <span className={`shrink-0 rounded border px-1.5 py-0.5 text-[10px] ${levelColors[caseItem.level]}`}>{caseItem.level}</span>
          <div className="flex max-w-[100px] min-w-0 items-center gap-1 overflow-hidden"><CaseProductPill caseItem={caseItem} compact /><CaseMarkCodePill caseItem={caseItem} compact /></div>
          <span className="shrink-0 font-mono text-[11px] text-slate-400">{caseItem.code}</span>
          <button title={caseItem.name} onClick={() => onOpenCase ? onOpenCase(caseItem.id) : onToggle()} className="min-w-0 flex-1 truncate text-left text-sm text-slate-800 hover:text-[#0052D9]">{caseItem.name}</button>
          <div data-case-status className="flex w-[64px] shrink-0 justify-center"><CaseStatusBadge status={caseDisplayStatus(caseItem, { closed: closure?.state === "closed", rootCaused: closure?.state === "rootcause" })} /></div>
          </div>
          <div className="grid min-w-0 grid-cols-[110px_minmax(0,1fr)] items-center gap-3 border-l border-slate-100 pl-4 text-[11px] text-slate-500" aria-label="Case Owner 与本部门关系">
          <span className="flex min-w-0 items-center gap-1.5"><span className="shrink-0 text-slate-400">Case Owner</span><span className="truncate text-slate-700" title={caseItem.owner}>{caseItem.owner}</span></span>
          <div className="flex min-w-0 items-center gap-1 overflow-hidden" aria-label="部门关系">
        {departmentInfo && <>
          <span className="shrink-0 text-slate-400">部门关系</span>
          {relationRoles.slice(0, 2).map(role => <span key={role} title={relationNames(role)} className="shrink-0 rounded border border-blue-200 bg-blue-50 px-1 py-px text-[10px] text-[#0052D9]">{DEPARTMENT_ROLE_LABELS[role]}</span>)}
          {relationRoles.length > 2 && <Popover>
            <PopoverTrigger asChild><button type="button" aria-label={`查看全部部门关系，共 ${relationRoles.length} 项`} className="shrink-0 rounded border border-blue-200 bg-blue-50 px-1 py-px text-[10px] text-[#0052D9] hover:bg-blue-100">+{relationRoles.length - 2}</button></PopoverTrigger>
            <PopoverContent align="end" sideOffset={8} aria-label="全部部门关系" className="w-72 p-3">
              <div className="mb-2 text-xs font-medium text-slate-700">部门关系</div>
              <dl className="space-y-2">{relationRoles.map(role => <div key={role} className="grid grid-cols-[72px_minmax(0,1fr)] gap-2 text-xs">
                <dt className="text-[#0052D9]">{DEPARTMENT_ROLE_LABELS[role]}</dt><dd className="break-words text-slate-600">{relationNames(role)}</dd>
              </div>)}</dl>
            </PopoverContent>
          </Popover>}
        </>}
          </div>
          </div>
        </div>
        <div data-case-summary-row="secondary" className="flex h-10 items-center justify-end whitespace-nowrap border-t border-slate-100 bg-slate-50/50 px-[18px] text-[11px] text-slate-500 [&>span]:flex [&>span]:items-center [&>span]:gap-1.5 [&>span]:px-3.5 [&>span+span]:border-l [&>span+span]:border-slate-100 [&>span:last-child]:pr-0">
          <span data-case-total-cycle title="Case 创建至实际结案／当前的完整历时，包含外部验证时间">Case 总 Cycle Time{metricValue(metrics.total)}</span>
          <span data-case-effective-cycle title="Case 总时长扣除全案外部验证独占时段，重合部分保留">Case 有效 Cycle Time{metricValue(metrics.effective)}</span>
          <span data-case-tat title={tat.issue || `创建至最近一次进入验证中；未进入或重新分析算至当前，扣外部独占时间。截止：${formatCaseTime(tat.end === undefined ? undefined : new Date(tat.end).toISOString())}`}>Case TAT{metricValue(tat.value)}</span>
          {departmentInfo && <span data-department-effective-cycle title="本部门及下级全部任务区间合并后，扣除外部独占时段，重合部分保留">部门有效 Cycle Time{metricValue(departmentInfo.cycleTime)}</span>}
        </div>
        </div>
      </div>
    </div>
    {expanded && <section className="min-w-0 border-t border-slate-100 bg-slate-50/60 p-4">
      {scopedTaskIds && <div className="mb-3 flex items-center gap-3"><div className="inline-flex gap-1 rounded-md bg-slate-100 p-1">{[{ all: false, label: "当前部门任务" }, { all: true, label: "全部任务" }].map(option => <button key={option.label} aria-pressed={showAllTasks === option.all} onClick={() => setShowAllTasks(option.all)} className={`h-7 rounded px-3 text-xs ${showAllTasks === option.all ? "bg-white font-medium text-[#0052D9] shadow-sm" : "text-slate-500"}`}>{option.label}</button>)}</div><span className="text-[11px] text-slate-400">{visibleTaskCount} / {tasks.length} 个任务</span></div>}
      <CaseGanttView caseItem={caseItem} tasks={visibleTasks} tasksOnly showVerificationTasks onTaskClick={taskId => onOpenTask(caseItem.id, taskId)} />
    </section>}
  </div>;
}
