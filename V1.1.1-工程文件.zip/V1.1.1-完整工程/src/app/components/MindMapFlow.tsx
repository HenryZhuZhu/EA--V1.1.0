import { useState, useMemo, useEffect, useCallback } from "react";
import {
  ReactFlow,
  Node,
  Edge,
  Background,
  MiniMap,
  useNodesState,
  useEdgesState,
  NodeTypes,
  ReactFlowInstance,
  Handle,
  Position,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import { MindMapZoomPill } from "./MindMapZoomPill";
import {
  Plus,
  Trash2,
  ThumbsUp,
  MessageCircle,
  Pencil,
  User,
  Calendar,
  Maximize2,
  Minimize2,
  Flag,
  AlarmClock,
  Tag,
  MoveHorizontal,
  MoveVertical,
  Building2,
  Eye,
  Copy,
  ClipboardPaste,
  FileText,
  FileSpreadsheet,
  FileImage,
  File as FileIcon,
  ExternalLink,
  Mic,
  Paperclip,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Circle,
  Clock,
  CircleDot,
  CheckCheck,
  Ban,
  Flame,
  UserCheck,
  MessageSquare,
  X,
  Check,
  FlaskConical,
  Radar,
  Bell,
  BellRing,
  Link2,
} from "lucide-react";
import {
  CaseItem,
  TaskNode,
  statusColors,
  statusDot,
  levelColors,
  validityColors,
  urgencyBar,
  currentUser,
  TaskComment,
  ownerToDepartment,
  TASK_TYPES,
  TaskType,
  BALL_TYPES,
  PROBLEM_DOMAINS,
  mockProducts,
  productById,
  EfaAnalysisCard,
  genEfaCode,
  flattenTasks,
  mockCases,
} from "./data";
import { TaskCommentsPanel } from "./TaskCommentsPanel";
import { AddTaskPayload } from "./AddTaskModal";
import { VoiceRecorder, VoicePlayer } from "./VoiceNote";
import { AttachmentInput, Att } from "./AttachmentInput";
import { AttachmentPreview } from "./AttachmentPreview";
import { StatusBadge } from "./StatusBadge";
import { verificationMindMap } from "./verificationMindMap";
import { isExternalVerification } from "./externalVerification";
import { saveValidationThought, manageCaseWaitingTask, updateCaseTask, caseTaskReadOnlyReason, loadCaseTaskTree, useCaseTaskRevision } from "./caseTaskTrees";
import { PersonInput } from "./PersonInput";
import { TaskDialog } from "./TaskDialog";
import { type WaitingTask } from "./waitingTasks";
import { CaseProductPill } from "./CaseProductPill";
import { CompleteCoverageModal, type CoverageCompletionInput } from "./CompleteCoverageModal";
import { useTaskSubscriptions } from "./taskSubscriptions";
import { EfaOrderModal, EfaInlineFields } from "./EfaOrderModal";
import { TaskAssigneeField } from "./TaskAssigneeField";
import { CoverageOwnerFields, CoveragePatternFields } from "./CoveragePatternFields";
import { RelationTask, TaskRelationPicker } from "./TaskRelationPicker";
import { caseCreators } from "./caseWorkbenchModel";
import { MaterialQueryDrawer, MaterialQueryNode, MaterialQueryThoughtNode, materialQueryBranch, useMaterialDataQuery } from "./MaterialDataQuery";
import type { MaterialQueryRecord } from "./materialQueryModel";

type TaskPatch = { likes?: number; likedByMe?: boolean; comments?: TaskComment[] };
type Direction = "LR" | "TB";
type ViewMode = "all" | "incomplete" | "valid";
export type PatternFanoutSelection = { speeds: string[]; testers: string[]; ballTypes: string[]; qgs: string[] };
const PATTERN_FANOUT_OPTIONS = {
  speeds: ["6400", "8000"],
  testers: ["TER", "瑞纳"],
  ballTypes: ["349", "456", "247"],
  qgs: ["QG0", "QG1", "QG2", "QG3"],
} as const;

interface Props {
  caseItem: CaseItem;
  materialQueryResults?: MaterialQueryRecord[];
  allowVerificationActions?: boolean;
  tasks?: TaskNode[];
  caseInRemediation?: boolean;
  focusMine?: boolean;
  showUrgency?: boolean;
  onTaskClick?: (taskId: string) => void;
  onAddChild?: (parentId: string | null, payload: AddTaskPayload) => string | void;
  onEditTask?: (taskId: string, payload: AddTaskPayload) => void;
  onSaveEfa?: (taskId: string, value: EfaAnalysisCard) => void;
  onDelete?: (taskId: string) => void;
  onClone?: (sourceId: string, targetParentId: string | null) => void; // 复制/粘贴子树（R29）
  onCompleteCoverage?: (taskId: string, input: CoverageCompletionInput) => boolean;
  onResubmitRemediation?: (taskId: string) => void;
  onPatternFanout?: (thoughtId: string, selection: PatternFanoutSelection) => void;
  coachGuide?: boolean; // 首次进入的交互式新手引导（仅 case 详情从零搭建时开启）
}

const NODE_TYPES: NodeTypes = {
  caseNode: CaseNodeComponent,
  thoughtNode: ThoughtNodeComponent,
  actionNode: ActionNodeComponent,
  efaAnalysisNode: EfaAnalysisNodeComponent,
  addButtonNode: AddButtonNodeComponent,
  materialQueryNode: MaterialQueryNode,
  materialQueryThoughtNode: MaterialQueryThoughtNode,
};

// ---- tree helpers ----
function walkWithAncestors(
  nodes: TaskNode[],
  ancestors: TaskNode[],
  cb: (node: TaskNode, ancestors: TaskNode[]) => void
) {
  nodes.forEach((n) => {
    cb(n, ancestors);
    if (n.children) walkWithAncestors(n.children, [...ancestors, n], cb);
  });
}
function collectSubtree(node: TaskNode): string[] {
  const out = [node.id];
  (node.children ?? []).forEach((c) => out.push(...collectSubtree(c)));
  return out;
}
function findPath(nodes: TaskNode[], id: string, acc: TaskNode[]): TaskNode[] | null {
  for (const n of nodes) {
    const next = [...acc, n];
    if (n.id === id) return next;
    if (n.children) {
      const r = findPath(n.children, id, next);
      if (r) return r;
    }
  }
  return null;
}
function pruneTree(nodes: TaskNode[], keep: Set<string>): TaskNode[] {
  return nodes
    .filter((n) => keep.has(n.id))
    .map((n) => ({ ...n, children: n.children ? pruneTree(n.children, keep) : n.children }));
}
export function filterMindMapTasks(nodes: TaskNode[], status: string, department: string, creator = "全部"): TaskNode[] {
  if (status === "全部" && department === "全部" && (!creator || creator === "全部")) return nodes;
  const keep = new Set<string>();
  walkWithAncestors(nodes, [], (node, ancestors) => {
    if (node.code && (status === "全部" || node.status === status) &&
      (department === "全部" || node.department === department) &&
      (!creator || creator === "全部" || node.supervisor === creator)) {
      keep.add(node.id);
      ancestors.forEach(ancestor => keep.add(ancestor.id));
    }
  });
  return pruneTree(nodes, keep);
}
function findInTree(id: string, list: TaskNode[]): TaskNode | null {
  for (const t of list) {
    if (t.id === id) return t;
    if (t.children) {
      const r = findInTree(id, t.children);
      if (r) return r;
    }
  }
  return null;
}

function efaDefaults(caseItem: CaseItem): EfaAnalysisCard {
  return {
    stage: caseItem.failStage && caseItem.failStage !== "—" ? caseItem.failStage : "",
    package: caseItem.failPackage && caseItem.failPackage !== "—" ? caseItem.failPackage : "",
    quality: caseItem.ppm && caseItem.ppm !== "—" ? `${caseItem.ppm}${/ppm/i.test(caseItem.ppm) ? "" : " PPM"}` : "",
    failRate: caseItem.failRatio && caseItem.failRatio !== "—" ? caseItem.failRatio : "",
    chipList: [{ fsa: "", map: "", failMode: caseItem.failMode === "—" ? "" : caseItem.failMode, waferNo: "", chipNo: "", markCode: "" }],
  };
}

// ---- R19 folding helpers ----
const ACTIVE_STATUS = new Set(["待接受", "进行中", "等待反馈", "整改中"]);
// 子树内是否还有“在跑”的执行任务（待接受/进行中）
function subtreeHasActive(node: TaskNode): boolean {
  if (node.code && ACTIVE_STATUS.has(node.status)) return true;
  return (node.children ?? []).some(subtreeHasActive);
}
function countDescendants(node: TaskNode): number {
  return (node.children ?? []).reduce((s, c) => s + 1 + countDescendants(c), 0);
}
// 默认折叠：有子节点且整条子树都无在跑任务（已完成/死路）
function defaultCollapsed(roots: TaskNode[]): Set<string> {
  const set = new Set<string>();
  const walk = (nodes: TaskNode[]) => {
    nodes.forEach((n) => {
      const kids = n.children ?? [];
      if (kids.length > 0 && !subtreeHasActive(n)) {
        set.add(n.id); // 折叠在此边界，更深层无需再标（子节点已隐藏）
      } else {
        walk(kids);
      }
    });
  };
  walk(roots);
  return set;
}

// ---- R28 拆分：把"多个怀疑写在一起"的文本拆成多段 ----
function splitSuspicions(text: string): string[] {
  return (text || "")
    .split(/\n+|；|;|（\d+）|\(\d+\)|^\s*\d+[.、)]\s*/m)
    .map((s) => s.trim())
    .filter((s) => s.length > 0);
}

// ---- 思路模板：因为__原理说明__所以__ ----
import { THOUGHT_CATEGORIES } from "./validationThoughts";
const MM_DEPARTMENTS = ["PTE", "CP", "FT", "DA", "PE", "QA", "EFA", "RD", "PM"];
const MM_COACH_KEY = "ea_mm_coach_v1";
function composeThought(parts: [string, string, string]): string {
  const [a, b, c] = parts.map((s) => (s || "").trim());
  if (!a && !b && !c) return "";
  return `因为${a}，原理说明${b}，所以${c}。`;
}
function parseThought(title: string): [string, string, string] {
  if (!title) return ["", "", ""];
  const normalized = title.endsWith("。") ? title.slice(0, -1) : title;
  const m = normalized.match(/^因为([\s\S]*)，原理说明([\s\S]*)，所以([\s\S]*)$/);
  if (m) return [m[1], m[2], m[3]];
  return [title, "", ""];
}


export function MindMapFlow({
  caseItem,
  materialQueryResults = [],
  allowVerificationActions = true,
  tasks,
  caseInRemediation = false,
  focusMine = false,
  onTaskClick,
  onAddChild,
  onEditTask,
  onSaveEfa,
  onDelete,
  onClone,
  onCompleteCoverage,
  onResubmitRemediation,
  onPatternFanout,
  coachGuide = false,
}: Props) {
  const materialQuery = useMaterialDataQuery(
    materialQueryResults.map(record => ({ sourceId: `saved:${record.chipId}`, chipId: record.chipId })),
    caseItem.background,
    useCallback(() => {}, []),
    materialQueryResults,
  );
  const taskRevision = useCaseTaskRevision();
  const rootTasks = useMemo(() => {
    const saved = new Map(flattenTasks(loadCaseTaskTree(caseItem.id, caseItem.tasks)).map(({ task }) => [task.id, task]));
    const merge = (items: TaskNode[]): TaskNode[] => items.map(task => {
      const stored = saved.get(task.id);
      const children = stored?.category === "validation" ? stored.children : task.children;
      return { ...task, ...(stored?.externalVerification ? stored : {}), ...(stored?.category === "validation" ? { category: stored.category, title: stored.title } : {}), waitingTasks: stored?.waitingTasks ?? task.waitingTasks, verificationNode: stored?.verificationNode ?? task.verificationNode, children: children ? merge(children) : children };
    });
    return merge(tasks ?? caseItem.tasks);
  }, [tasks, caseItem, taskRevision]);
  const [addingSpecial, setAddingSpecial] = useState<TaskNode>();
  const [endingSpecial, setEndingSpecial] = useState<{ parent: TaskNode; task: WaitingTask; kind: "complete" | "cancel" }>();
  const [specialResult, setSpecialResult] = useState("");
  const [verificationError, setVerificationError] = useState("");
  const verificationReadOnly = !allowVerificationActions ? "请在 Case 思维导图中管理验证分支。" : caseTaskReadOnlyReason(caseItem.id);
  const editable = !!(onAddChild && onDelete);
  const taskSubscriptions = useTaskSubscriptions();
  const followedTaskKeys = taskSubscriptions.keys.join("|");

  // view controls
  const [direction, setDirection] = useState<Direction>("LR");
  // 复制/粘贴剪贴板（R29）：存被复制节点 id
  const [clipboard, setClipboard] = useState<string | null>(null);
  const [patternSourceId, setPatternSourceId] = useState<string | null>(null);
  const [coverageCompleteTarget, setCoverageCompleteTarget] = useState<TaskNode | null>(null);
  const [resubmitTarget, setResubmitTarget] = useState<TaskNode | null>(null);
  const [resubmitError, setResubmitError] = useState("");
  const [patternSelection, setPatternSelection] = useState<PatternFanoutSelection>({
    speeds: [...PATTERN_FANOUT_OPTIONS.speeds], testers: [...PATTERN_FANOUT_OPTIONS.testers], ballTypes: [...PATTERN_FANOUT_OPTIONS.ballTypes], qgs: [...PATTERN_FANOUT_OPTIONS.qgs],
  });
  const [viewMode, setViewMode] = useState<ViewMode>("all");
  const [onlyMine, setOnlyMine] = useState(false);
  const [statusFilter, setStatusFilter] = useState<string>("全部"); // R16
  const [deptFilter, setDeptFilter] = useState<string>("全部"); // R16
  const [creatorFilter, setCreatorFilter] = useState<string>("全部");
  const [fullscreen, setFullscreen] = useState(false);
  const [flowInstance, setFlowInstance] = useState<ReactFlowInstance | null>(null);

  // interaction state
  const [markedId, setMarkedId] = useState<string | null>(null);
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  // 手动拖拽位置（R18）：覆盖自动布局，会话内保留
  const [manualPos, setManualPos] = useState<Record<string, { x: number; y: number }>>({});
  // 折叠集合（R19）：已完成/死路默认折叠
  const rootTasksForInit = tasks ?? caseItem.tasks;
  const [collapsed, setCollapsed] = useState<Set<string>>(() => defaultCollapsed(rootTasksForInit));
  useEffect(() => {
    setCollapsed((current) => {
      const next = new Set(current);
      let changed = false;
      flattenTasks(rootTasks).forEach(({ task }) => {
        if ((task.children?.length ?? 0) > 24 && !next.has(task.id)) { next.add(task.id); changed = true; }
      });
      return changed ? next : current;
    });
  }, [rootTasks]);
  const toggleCollapse = (id: string) =>
    setCollapsed((prev) => {
      const n = new Set(prev);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });

  // editing state
  const [editingThought, setEditingThought] = useState<string | null>(null);
  const [editingAction, setEditingAction] = useState<string | null>(null);
  const [thoughtText, setThoughtText] = useState("");
  const [thoughtCategory, setThoughtCategory] = useState("Testing");
  const [thoughtSourceTaskIds, setThoughtSourceTaskIds] = useState<string[]>([]);
  const [actionForm, setActionForm] = useState<any>({});
  const relationTasks = useMemo<RelationTask[]>(() => flattenTasks(rootTasks).filter(({ task }) => !!task.code).map(({ task, path }) => ({
    id: task.id, title: task.title, groupTitle: [...path].reverse().find(Boolean) || "Case 根级任务", owner: task.owner, status: task.status, conclusion: task.conclusion, expectation: task.expectation, isPatternFanout: !!task.patternParams || path.some((item) => item.includes("Pattern Fanout")), speed: task.coverageSpeed, tester: task.coverageTester, ballType: task.coverageBallType, qg: task.coverageQG, role: task.patternRole,
  })), [rootTasks]);
  const [openComments, setOpenComments] = useState<string | null>(null);
  const [previewAttachment, setPreviewAttachment] = useState<Att | null>(null);
  const [patches, setPatches] = useState<Record<string, TaskPatch>>({});

  // ---- 交互式新手引导 coach（首次进入自动，随实操推进，可跳过；localStorage 记忆）----
  const [coach, setCoach] = useState<{ active: boolean; step: "thought" | "task" | "done" }>(() => {
    try {
      return { active: coachGuide && editable && !localStorage.getItem(MM_COACH_KEY), step: "thought" };
    } catch {
      return { active: false, step: "thought" };
    }
  });
  const closeCoach = () => {
    try { localStorage.setItem(MM_COACH_KEY, "1"); } catch {}
    setCoach((c) => ({ ...c, active: false }));
  };

  const merged = (t: TaskNode): TaskNode => {
    const p = patches[t.id];
    if (!p) return t;
    return {
      ...t,
      likes: p.likes ?? t.likes ?? 0,
      likedByMe: p.likedByMe ?? t.likedByMe ?? false,
      comments: p.comments ?? t.comments ?? [],
    };
  };

  const toggleLike = (id: string) => {
    setPatches((prev) => {
      const cur = prev[id] ?? {};
      const liked = !(cur.likedByMe ?? false);
      const base = cur.likes ?? 0;
      return { ...prev, [id]: { ...cur, likedByMe: liked, likes: base + (liked ? 1 : -1) } };
    });
  };
  const addComment = (id: string, content: string) => {
    setPatches((prev) => {
      const cur = prev[id] ?? {};
      const list = cur.comments ?? [];
      const nc: TaskComment = { id: `c${Date.now()}`, user: currentUser.name, time: "刚刚", content };
      return { ...prev, [id]: { ...cur, comments: [...list, nc] } };
    });
  };
  const replyComment = (taskId: string, commentId: string, content: string) => {
    setPatches((prev) => {
      const cur = prev[taskId] ?? {};
      const list = cur.comments ?? [];
      const nl = list.map((c) =>
        c.id === commentId
          ? { ...c, replies: [...(c.replies ?? []), { id: `r${Date.now()}`, user: currentUser.name, time: "刚刚", content }] }
          : c
      );
      return { ...prev, [taskId]: { ...cur, comments: nl } };
    });
  };

  const toggleMark = (id: string) => setMarkedId((cur) => (cur === id ? null : id));

  // 1) 「只看我的」：高亮而非裁剪——计算我相关节点集合（命中我的任务 + 其路径祖先）
  const showMine = focusMine || onlyMine;
  const mineSet = useMemo(() => {
    if (!showMine) return null;
    const s = new Set<string>();
    walkWithAncestors(rootTasks, [], (node, ancestors) => {
      if (node.owner === currentUser.name) {
        s.add(node.id);
        ancestors.forEach((a) => s.add(a.id));
      }
    });
    return s;
  }, [showMine, rootTasks]);

  // 2) 「只看未完成 / 有效路径」：同样高亮而非裁剪
  const viewSet = useMemo(() => {
    if (viewMode === "all") return null;
    const s = new Set<string>();
    if (viewMode === "incomplete") {
      walkWithAncestors(rootTasks, [], (node, ancestors) => {
        if (node.code && node.status !== "已完成") {
          s.add(node.id);
          ancestors.forEach((a) => s.add(a.id));
        }
      });
    } else {
      walkWithAncestors(rootTasks, [], (node, ancestors) => {
        if (node.validity === "有效") {
          s.add(node.id);
          ancestors.forEach((a) => s.add(a.id));
          collectSubtree(node).forEach((id) => s.add(id));
        }
      });
    }
    return s;
  }, [viewMode, rootTasks]);

  // 高亮集合 = 各启用命名筛选（我的 / 未完成 / 有效路径）的交集；null 表示不启用高亮
  const highlightSet = useMemo(() => {
    const sets = [mineSet, viewSet].filter(Boolean) as Set<string>[];
    if (sets.length === 0) return null;
    return sets.reduce((acc, s) => new Set([...acc].filter((id) => s.has(id))));
  }, [mineSet, viewSet]);

  // 下拉条件按同一执行任务 AND 裁剪，保留祖先路径；命名高亮逻辑不变。
  const filtered = useMemo(() => filterMindMapTasks(rootTasks, statusFilter, deptFilter, creatorFilter), [rootTasks, statusFilter, deptFilter, creatorFilter]);
  const creatorOpts = useMemo(() => ["全部", ...caseCreators({ tasks: rootTasks })], [rootTasks]);

  // R16：部门选项（取自本 Case 的执行任务）
  const deptOpts = useMemo(() => {
    const s = new Set<string>();
    walkWithAncestors(rootTasks, [], (n) => { if (n.code && n.department) s.add(n.department); });
    return ["全部", ...Array.from(s)];
  }, [rootTasks]);
  const STATUS_OPTS = ["全部", "待接受", "进行中", "整改中", "已完成", "已中止", "已拒绝"];

  // marked lineage (item 9): the whole line of the marked node
  const markedLineage = useMemo(() => {
    if (!markedId) return new Set<string>();
    const path = findPath(rootTasks, markedId, []);
    if (!path) return new Set<string>();
    const set = new Set<string>(path.map((n) => n.id));
    collectSubtree(path[path.length - 1]).forEach((id) => set.add(id));
    return set;
  }, [markedId, rootTasks]);

  // ---- build nodes & edges ----
  const { nodes, edges } = useMemo(() => {
    const nodes: Node[] = [];
    const edges: Edge[] = [];
    const withDraft = (items: TaskNode[]): TaskNode[] => items.map(task => ({
      ...task, children: task.children ? withDraft(task.children) : undefined,
      waitingTasks: task.id === addingSpecial?.id ? [...(task.waitingTasks ?? []), {
        id: "verification-draft", parentTaskId: task.id, title: "新增验证任务", reason: "验证",
        description: "", owner: currentUser.name, assignedBy: currentUser.name, createdAt: "", status: "待开始",
      }] : task.waitingTasks,
    }));
    const { tasks: graphTasks, displayNodes } = verificationMindMap(withDraft(filtered));
    // Tidy tree layout: leaves get evenly spaced cross slots, parents center on
    // their children — guarantees subtrees never overlap.
    const DEPTH_GAP = direction === "LR" ? 390 : 280;
    const LEAF_GAP = direction === "LR" ? 190 : 370;
    const CASE_DEPTH = 0;

    const place = (depthPos: number, crossPos: number) =>
      direction === "LR" ? { x: depthPos, y: crossPos } : { x: crossPos, y: depthPos };

    // Pass 1: assign positions
    const positions: Record<string, { x: number; y: number }> = {};
    let leafCursor = 0;
    const assign = (task: TaskNode, level: number): number => {
      const depthPos = level * DEPTH_GAP;
      const kids = collapsed.has(task.id) ? [] : (task.children ?? []);
      const childLevel = level + 1;
      let cross: number;
      if (kids.length === 0) {
        cross = leafCursor * LEAF_GAP;
        leafCursor += 1;
      } else {
        const cs = kids.map((k) => assign(k, childLevel));
        cross = (cs[0] + cs[cs.length - 1]) / 2;
      }
      positions[task.id] = place(depthPos, cross);
      return cross;
    };
    graphTasks.forEach((r) => assign(r, 1));
    flattenTasks(filtered).forEach(({ task }) => {
      if (!task.sourceTaskIds?.length || manualPos[task.id]) return;
      const sources = task.sourceTaskIds.map((id) => positions[id]).filter(Boolean);
      if (!sources.length) return;
      positions[task.id] = direction === "LR"
        ? { x: Math.max(...sources.map((point) => point.x)) + DEPTH_GAP, y: sources.reduce((sum, point) => sum + point.y, 0) / sources.length }
        : { x: sources.reduce((sum, point) => sum + point.x, 0) / sources.length, y: Math.max(...sources.map((point) => point.y)) + DEPTH_GAP };
    });
    const caseCross = leafCursor > 0 ? ((leafCursor - 1) * LEAF_GAP) / 2 : 0;

    // 卡片悬停或进入编辑态后会向下变高：把其下方节点整体推开，避免覆盖和连线挤成一团。
    // 编辑态优先于 hover；手动拖拽位置也参与推开计算。
    const expandedId = editingAction || editingThought || hoveredId;
    const expandedPos = expandedId
      ? (manualPos[expandedId] ?? positions[expandedId])
      : undefined;
    const expandedTask = expandedId ? findInTree(expandedId, filtered) : null;
    const expandedPath = expandedId ? findPath(filtered, expandedId, []) : null;
    const frozenIds = new Set<string>(["case"]);
    expandedPath?.slice(0, -1).forEach((n) => frozenIds.add(n.id));
    const PUSH = editingAction
      ? 430
      : editingThought
      ? 230
      : expandedPos
      ? (expandedTask?.code ? 240 : 120)
      : 0;
    const pushDown = (id: string, p: { x: number; y: number }) =>
      expandedPos && id !== expandedId && p.y > expandedPos.y
        ? { x: p.x, y: p.y + PUSH }
        : p;
    const placeNode = (id: string, p: { x: number; y: number }) =>
      frozenIds.has(id) ? p : pushDown(id, p);

    nodes.push({
      id: "case",
      type: "caseNode",
      position: place(CASE_DEPTH, caseCross), // 根节点始终不随 hover 推移
      data: { caseItem, direction },
    });

    // Pass 2: build nodes + edges
    const build = (list: TaskNode[], parentId: string) => {
      list.forEach((task) => {
        const nodeId = task.id;
        const special = displayNodes.get(nodeId);
        if (special) {
          const canCreate = !verificationReadOnly && ["进行中", "整改中"].includes(special.parent.status) && special.parent.owner === currentUser.name;
          if (special.kind === "verification") {
            const data = {
              task, direction, editable: canCreate, isValidation: true,
              thoughtCategory: "validation", thoughtText, setThoughtText,
              isEditing: editingThought === nodeId,
              onEdit: () => { setThoughtText(task.title); setThoughtCategory("validation"); setEditingThought(nodeId); },
              onSave: () => {
                try { saveValidationThought(caseItem.id, special.parent.id, nodeId, thoughtText); setEditingThought(null); setVerificationError(""); }
                catch (error) { setVerificationError(error instanceof Error ? error.message : "保存失败"); }
              },
              onCancel: () => setEditingThought(null),
              onAddChild: () => {
                setAddingSpecial(special.parent);
                setActionForm({ title: "", expectation: "", type: "验证", assignee: currentUser.name, department: special.parent.department, urgency: special.parent.urgency, dueDate: "", attachments: [] });
                setVerificationError("");
              },
            };
            nodes.push({ id: nodeId, type: "thoughtNode", deletable: false, position: placeNode(nodeId, manualPos[nodeId] ?? positions[nodeId]), data });
          } else {
            const canManage = !verificationReadOnly && ["进行中", "整改中"].includes(special.parent.status)
                && special.specialTask.status === "进行中" && [special.parent.owner, special.specialTask.owner].includes(currentUser.name),
            data = {
              direction, task: { ...task, type: special.specialTask.id === "verification-draft" || isExternalVerification(special.specialTask) ? "验证" : "历史记录（不扣时）", title: special.specialTask.title, expectation: special.specialTask.description,
                conclusion: special.specialTask.status === "已完成" ? special.specialTask.result : undefined,
                terminateReason: special.specialTask.status === "已中止" ? special.specialTask.result : undefined,
                dueDate: special.specialTask.dueDate, createdAt: special.specialTask.createdAt },
              isVerificationTask: true, canManage,
              isEditing: special.specialTask.id === "verification-draft",
              actionForm, setActionForm,
              onSave: () => {
                try {
                  if (!ownerToDepartment[actionForm.assignee]) throw new Error("请从候选中选择任务负责人。");
                  manageCaseWaitingTask(caseItem.id, special.parent.id, { kind: "create", input: {
                    reason: "验证", title: actionForm.title, description: actionForm.expectation, owner: actionForm.assignee,
                    dueDate: actionForm.dueDate || undefined, urgency: actionForm.urgency, department: actionForm.department,
                    attachments: actionForm.attachments, voiceNote: actionForm.voiceNote,
                  } });
                  setAddingSpecial(undefined); setVerificationError("");
                } catch (error) { setVerificationError(error instanceof Error ? error.message : "验证任务保存失败"); }
              },
              onComplete: () => { setEndingSpecial({ parent: special.parent, task: special.specialTask, kind: "complete" }); setSpecialResult(""); setVerificationError(""); },
              onCancel: () => {
                if (special.specialTask.id === "verification-draft") { setAddingSpecial(undefined); return; }
                setEndingSpecial({ parent: special.parent, task: special.specialTask, kind: "cancel" }); setSpecialResult(""); setVerificationError("");
              },
            };
            nodes.push({ id: nodeId, type: "actionNode", zIndex: data.isEditing ? 1000 : 1, deletable: false, position: placeNode(nodeId, manualPos[nodeId] ?? positions[nodeId]), data });
          }
          edges.push({ id: `${parentId}-${nodeId}`, source: parentId, target: nodeId, deletable: false, type: "smoothstep", style: { stroke: "#a78bfa", strokeWidth: 2 }, pathOptions: { borderRadius: 10, offset: 28 } });
          if (special.kind === "verification" && task.children?.length) build(task.children, nodeId);
          return;
        }
        const isThought = !task.code;
        const nodeEditable = editable || Boolean(task.code && task.status === "整改中" && [task.owner, task.supervisor].includes(currentUser.name));

        const onLine = markedLineage.has(nodeId);
        // 标记整条线时弱化其余；命名筛选（我的/未完成/有效路径）启用时，弱化未命中节点——树结构保留
        const dimmed = (!!markedId && !onLine) || (!!highlightSet && !highlightSet.has(nodeId));

        nodes.push({
          id: nodeId,
          type: isThought ? "thoughtNode" : "actionNode",
          position: placeNode(nodeId, manualPos[nodeId] ?? positions[nodeId]),
          zIndex: expandedId === nodeId ? 1000 : onLine ? 6 : 1,
          data: {
            task: merged(task),
            validationReason: verificationReadOnly || (!findInTree(parentId, rootTasks)?.code
              ? "validation 必须添加在普通任务之后，不能直接添加在 Case 下。"
              : findInTree(parentId, rootTasks)?.owner !== currentUser.name
                ? "仅原任务负责人可以设置 validation 思路。"
                : !["进行中", "整改中"].includes(findInTree(parentId, rootTasks)?.status ?? "")
                  ? "原任务开始后可新增验证分支；新建 Case 时可预编排。"
                  : task.children?.length || task.sourceTaskIds?.length
                    ? "已有普通子节点或来源关联的思路不能切换为 validation，请新建空思路。" : ""),
            caseTasks: caseItem.tasks,
            caseInRemediation,
            followed: taskSubscriptions.isFollowed(caseItem.id, task.id),
            onToggleFollow: () => taskSubscriptions.toggle(caseItem.id, task.id),
            direction,
            editable: nodeEditable,
            onTaskClick,
            onCompleteCoverage: (taskId: string) => {
              const target = flattenTasks(rootTasks).find(({ task: candidate }) => candidate.id === taskId)?.task;
              if (target) setCoverageCompleteTarget(target);
            },
            onResubmitRemediation: task.status === "整改中" && task.owner === currentUser.name && onResubmitRemediation
              ? () => { setResubmitTarget(task); setResubmitError(""); }
              : undefined,
            onPatternFanout: () => setPatternSourceId(task.id),
            onDelete,
            onToggleLike: toggleLike,
            onOpenComments: setOpenComments,
            onPreviewAttachment: setPreviewAttachment,
            onToggleMark: toggleMark,
            onHover: setHoveredId,
            marked: onLine,
            isMarkRoot: markedId === nodeId,
            dimmed,
            isEditing: isThought ? editingThought === nodeId : editingAction === nodeId,
            onEdit: isThought
              ? () => {
                  setThoughtText(task.title);
                  setThoughtCategory(task.category || "Testing");
                  setThoughtSourceTaskIds(task.sourceTaskIds || []);
                  setEditingThought(nodeId);
                }
              : () => {
                  setActionForm({
                    title: task.title,
                    expectation: task.expectation || "",
                    urgency: task.urgency,
                    department: task.department,
                    assignee: task.owner === "待指派" ? "" : task.owner,
                    assigneeType: task.assigneeType,
                    skillId: task.skillId,
                    skillRun: task.skillRun,
                    dueDate: task.dueDate || "",
                    voiceNote: task.voiceNote,
                    attachments: task.attachments || [],
                    type: task.type || (task.efaAnalysis ? "EFA分析" : ""),
                    coverageProgramVersion: task.coverageProgramVersion || "",
                    coverageTestName: task.coverageTestName || "",
                    coverageTestTime: task.coverageTestTime || "",
                    coverageActionStage: task.coverageActionStage || "",
                    coverageBallType: task.coverageBallType || "",
                    coveragePackage: task.coveragePackage || "",
                    coverageSpeed: task.coverageSpeed || "",
                    coverageTester: task.coverageTester || "",
                    coverageQG: task.coverageQG || "",
                    coverageStatus: task.coverageStatus || "",
                    coverageReleaseType: task.coverageReleaseType || "",
                    coverageTeOwner: task.coverageTeOwner || "",
                    coveragePeOwner: task.coveragePeOwner || "",
                    efaAnalysis: task.efaAnalysis || efaDefaults(caseItem),
                  });
                  setEditingAction(nodeId);
                },
            onSave: isThought
              ? () => {
                  if (thoughtCategory === "validation") {
                    try {
                      if (verificationReadOnly) throw new Error(verificationReadOnly);
                      saveValidationThought(caseItem.id, parentId, nodeId, thoughtText);
                      setEditingThought(null); setVerificationError("");
                    } catch (error) { setVerificationError(error instanceof Error ? error.message : "保存失败"); }
                    return;
                  }
                  onEditTask?.(nodeId, {
                    kind: "怀疑目标",
                    title: thoughtText,
                    category: thoughtCategory,
                    sourceTaskIds: thoughtSourceTaskIds,
                    department: "PTE",
                    urgency: "一般",
                    assignee: "",
                    dueDate: "",
                    type: undefined,
                    note: "",
                    supervisor: "",
                    site: undefined,
                  });
                  setEditingThought(null);
                  if (thoughtText.trim()) {
                    setCoach((c) => (c.active && c.step === "thought" ? { ...c, step: "task" } : c));
                  }
                }
              : () => {
                  if (task.externalVerification) {
                    try {
                      if (!actionForm.title?.trim() || !actionForm.expectation?.trim() || !ownerToDepartment[actionForm.assignee]) throw new Error("请填写任务名称、预期，并选择内部对接负责人。");
                      updateCaseTask(caseItem.id, task.id, {
                        title: actionForm.title, expectation: actionForm.expectation, owner: actionForm.assignee,
                        department: ownerToDepartment[actionForm.assignee], urgency: actionForm.urgency,
                        dueDate: actionForm.dueDate || undefined, attachments: actionForm.attachments, voiceNote: actionForm.voiceNote,
                      });
                      setEditingAction(null); setVerificationError("");
                    } catch (error) { setVerificationError(error instanceof Error ? error.message : "外部验证任务保存失败"); }
                    return;
                  }
                  onEditTask?.(nodeId, {
                    kind: "执行任务",
                    title: actionForm.title,
                    expectation: actionForm.expectation,
                    department: actionForm.department,
                    urgency: actionForm.urgency,
                    assignee: actionForm.assignee,
                    assigneeType: actionForm.assigneeType,
                    skillId: actionForm.skillId,
                    skillRun: actionForm.skillRun,
                    dueDate: actionForm.dueDate,
                    type: actionForm.type || undefined,
                    coverageProgramVersion: actionForm.type === "Coverage分析上线" ? actionForm.coverageProgramVersion?.trim() : undefined,
                    coverageTestName: actionForm.type === "Coverage分析上线" ? actionForm.coverageTestName?.trim() : undefined,
                    coverageTestTime: actionForm.type === "Coverage分析上线" ? actionForm.coverageTestTime?.trim() : undefined,
                    coverageActionStage: actionForm.type === "Coverage分析上线" ? actionForm.coverageActionStage : undefined,
                    coverageBallType: actionForm.type === "Coverage分析上线" ? actionForm.coverageBallType : undefined,
                    coveragePackage: actionForm.type === "Coverage分析上线" ? actionForm.coveragePackage : undefined,
                    coverageSpeed: actionForm.type === "Coverage分析上线" ? actionForm.coverageSpeed : undefined,
                    coverageTester: actionForm.type === "Coverage分析上线" ? actionForm.coverageTester : undefined,
                    coverageQG: actionForm.type === "Coverage分析上线" ? actionForm.coverageQG : undefined,
                    coverageStatus: actionForm.type === "Coverage分析上线" ? actionForm.coverageStatus : undefined,
                    coverageReleaseType: actionForm.type === "Coverage分析上线" ? actionForm.coverageReleaseType : undefined,
                    coverageTeOwner: actionForm.type === "Coverage分析上线" ? actionForm.coverageTeOwner : undefined,
                    coveragePeOwner: actionForm.type === "Coverage分析上线" ? actionForm.coveragePeOwner : undefined,
                    voiceNote: actionForm.voiceNote,
                    attachments: actionForm.attachments,
                    efaAnalysis: actionForm.type === "EFA分析"
                      ? { ...(actionForm.efaAnalysis || efaDefaults(caseItem)), submitted: true, code: actionForm.efaAnalysis?.code || genEfaCode(), submittedAt: actionForm.efaAnalysis?.submittedAt || new Date().toISOString().slice(0, 16).replace("T", " ") }
                      : null,
                    supervisor: "",
                    site: undefined,
                  });
                  setEditingAction(null);
                  if (actionForm.title?.trim()) {
                    setCoach((c) => (c.active && c.step === "task" ? { ...c, step: "done" } : c));
                  }
                },
            onCancel: isThought ? () => { setEditingThought(null); setThoughtSourceTaskIds([]); } : () => setEditingAction(null),
            thoughtText: isThought ? thoughtText : undefined,
            setThoughtText: isThought ? setThoughtText : undefined,
            thoughtCategory: isThought ? thoughtCategory : undefined,
            setThoughtCategory: isThought ? setThoughtCategory : undefined,
            thoughtSourceTaskIds: isThought ? thoughtSourceTaskIds : undefined,
            setThoughtSourceTaskIds: isThought ? setThoughtSourceTaskIds : undefined,
            relationTasks: isThought ? relationTasks.filter((candidate) => candidate.id !== nodeId) : undefined,
            actionForm: !isThought ? actionForm : undefined,
            setActionForm: !isThought ? setActionForm : undefined,
            onAddChild: isThought
              ? () =>
                  onAddChild?.(nodeId, {
                    kind: "执行任务", title: "执行任务", department: "PTE", urgency: "一般",
                    assignee: "", dueDate: "", type: undefined, note: "", supervisor: "", site: undefined,
                  })
              : () => {
                  // 新建子思路后直接进入编辑态（免再点一次「编辑」）
                  const newId = onAddChild?.(nodeId, {
                    kind: "怀疑目标", title: "新的思路/怀疑方向", category: "Testing", department: "PTE", urgency: "一般",
                    assignee: "", dueDate: "", type: undefined, note: "", supervisor: "", site: undefined,
                  });
                  if (newId) {
                    setThoughtText("");
                    setThoughtCategory("Testing");
                    setThoughtSourceTaskIds([]);
                    setEditingThought(newId);
                  }
                },
            // 折叠（R19）
            hasChildren: !!(task.children && task.children.length),
            collapsed: collapsed.has(nodeId),
            collapsedCount: countDescendants(task),
            onToggleCollapse: () => toggleCollapse(nodeId),
            // 复制/粘贴（R29）
            isCopied: clipboard === nodeId,
            onCopy: onClone ? () => setClipboard(nodeId) : undefined,
            onPaste: onClone && clipboard ? () => { onClone(clipboard, nodeId); setClipboard(null); } : undefined,
            // 拆分多个怀疑方向（R28）
            onSplit: isThought
              ? (segments: string[]) => {
                  if (!segments.length) return;
                  onEditTask?.(nodeId, {
                    kind: "怀疑目标", title: segments[0], category: thoughtCategory,
                    department: "PTE", urgency: "一般", assignee: "", dueDate: "",
                    type: undefined, note: "", supervisor: "", site: undefined,
                  });
                  segments.slice(1).forEach((s) =>
                    onAddChild?.(parentId === "case" ? null : parentId, {
                      kind: "怀疑目标", title: s, department: "PTE", urgency: "一般",
                      assignee: "", dueDate: "", type: undefined, note: "", supervisor: "", site: undefined,
                    })
                  );
                  setEditingThought(null);
                }
              : undefined,
          },
        });

        // 关联任务后，来源任务成为该思路的实际输入；隐藏原父节点入边，避免两套关系线同时出现。
        if (!task.sourceTaskIds?.length) {
          const edgeOnLine = markedLineage.has(parentId) && onLine;
          edges.push({
            id: `${parentId}-${nodeId}`,
            source: parentId,
            target: nodeId,
            type: "smoothstep",
            animated: edgeOnLine,
            zIndex: edgeOnLine ? 5 : 0,
            pathOptions: {
              borderRadius: 10,
              // 同一父节点共用一条主干，再向各子节点分叉，避免平行线重叠成线束
              offset: 28,
            },
            style: {
              stroke: edgeOnLine ? "#7c3aed" : markedId ? "#e2e8f0" : "#cbd5e1",
              strokeWidth: edgeOnLine ? 2.5 : 2,
            },
          });
        }

        if (task.children && task.children.length > 0 && !collapsed.has(nodeId)) {
          build(task.children, nodeId);
        }
      });
    };

    build(graphTasks, "case");
    flattenTasks(filtered).forEach(({ task }) => {
      if (!task.sourceTaskIds?.length) return;
      task.sourceTaskIds.forEach((sourceId) => {
        if (!nodes.some((node) => node.id === sourceId) || !nodes.some((node) => node.id === task.id)) return;
        edges.push({ id: `relation-${sourceId}-${task.id}`, source: sourceId, target: task.id, sourceHandle: "relation-source", targetHandle: "relation-target", type: "bezier", animated: true, zIndex: 8, style: { stroke: "#0052D9", strokeWidth: 2.5, strokeDasharray: "6 4" }, label: "任务关联", labelStyle: { fill: "#0052D9", fontSize: 9, fontWeight: 600 }, labelBgStyle: { fill: "#eff6ff", fillOpacity: 0.95 }, labelBgPadding: [5, 3], labelBgBorderRadius: 4 });
      });
    });

    if (editable) {
      const addCross = leafCursor * LEAF_GAP;
      nodes.push({
        id: "add-thought-btn",
        type: "addButtonNode",
        position: pushDown("add-thought-btn", place(DEPTH_GAP, addCross)),
        data: {
          direction,
          guideHighlight: coach.active && coach.step === "thought",
          onClick: () => {
            // 新建根思路后直接进入编辑态（免再点一次「编辑」）
            const newId = onAddChild?.(null, {
              kind: "怀疑目标", title: "新的思路/怀疑方向", category: "Testing", department: "PTE", urgency: "一般",
              assignee: "", dueDate: "", type: undefined, note: "", supervisor: "", site: undefined,
            });
            if (newId) {
              setThoughtText("");
              setThoughtCategory("Testing");
              setThoughtSourceTaskIds([]);
              setEditingThought(newId);
            }
          },
        },
      });
    }

    const queryCount = materialQuery.records.length;
    if (queryCount) {
      const minY = Math.min(...nodes.map(node => node.position.y));
      const minX = Math.min(...nodes.map(node => node.position.x));
      const origin = direction === "LR"
        ? { x: DEPTH_GAP, y: minY - 240 - (queryCount - 1) * 220 }
        : { x: minX - 340 * queryCount, y: DEPTH_GAP };
      const branch = materialQueryBranch(materialQuery, direction, origin);
      nodes.push(...branch.nodes);
      edges.push(...branch.edges);
    }
    return { nodes, edges };
  }, [
    filtered, highlightSet, caseItem, editable, direction, markedId, markedLineage, hoveredId, manualPos, collapsed, clipboard,
    editingThought, editingAction, thoughtText, thoughtCategory, thoughtSourceTaskIds, actionForm, patches,
    coach, onSaveEfa, followedTaskKeys, relationTasks, caseInRemediation, verificationReadOnly, addingSpecial,
    materialQuery.records, materialQuery.selected, materialQuery.open,
  ]);

  const [flowNodes, setNodes, onNodesChange] = useNodesState(nodes);
  const [flowEdges, setEdges] = useEdgesState(edges);
  useEffect(() => {
    if (!addingSpecial || !flowInstance) return;
    const timer = window.setTimeout(() => {
      flowInstance.fitView({ nodes: [{ id: `special-view:${addingSpecial.id}:verification-draft` }], padding: 0.3, maxZoom: 0.95, duration: 200 });
    }, 400);
    return () => window.clearTimeout(timer);
  }, [addingSpecial, flowInstance]);
  useEffect(() => {
    setNodes(nodes);
    setEdges(edges);
  }, [nodes, edges, setNodes, setEdges]);
  useEffect(() => {
    if (!flowInstance || flowNodes.length === 0 || addingSpecial) return;
    const frame = requestAnimationFrame(async () => {
      const referenceNodes = flowNodes.filter(node => node.type === "materialQueryThoughtNode" || node.type === "materialQueryNode");
      await flowInstance.fitView({ ...(referenceNodes.length ? { nodes: referenceNodes } : {}), padding: 0.18, maxZoom: 0.95, duration: 180 });
      const viewport = flowInstance.getViewport();
      await flowInstance.setViewport({ ...viewport, y: viewport.y + 64 }, { duration: 120 });
    });
    return () => cancelAnimationFrame(frame);
  }, [flowInstance, flowNodes.length, addingSpecial]);
  useEffect(() => {
    if (!flowInstance || !materialQuery.focus.revision) return;
    const timer = window.setTimeout(() => {
      flowInstance.fitView({ nodes: [{ id: "material-query-thought" }, { id: `material-query:${materialQuery.focus.chipId}` }], padding: .25, maxZoom: .95, duration: 260 });
    }, 180);
    return () => window.clearTimeout(timer);
  }, [flowInstance, materialQuery.focus.revision, materialQuery.focus.chipId]);
  useEffect(() => {
    const linkedThoughts = flattenTasks(rootTasks).map(({ task }) => task).filter((task) => task.sourceTaskIds?.length && !manualPos[task.id]);
    if (!linkedThoughts.length) return;
    setNodes((current) => {
      const byId = new Map(current.map((node) => [node.id, node]));
      let changed = false;
      const next = current.map((node) => {
        const thought = linkedThoughts.find((item) => item.id === node.id);
        if (!thought) return node;
        const targetSize = node.measured;
        const sources = thought.sourceTaskIds!.map((id) => byId.get(id)).filter((item): item is Node => !!item?.measured);
        if (!targetSize?.width || !targetSize.height || !sources.length) return node;
        const desired = direction === "LR"
          ? {
              x: Math.max(...sources.map((source) => source.position.x + (source.measured?.width || 0))) + 130,
              y: sources.reduce((sum, source) => sum + source.position.y + (source.measured?.height || 0) / 2, 0) / sources.length - targetSize.height / 2,
            }
          : {
              x: sources.reduce((sum, source) => sum + source.position.x + (source.measured?.width || 0) / 2, 0) / sources.length - targetSize.width / 2,
              y: Math.max(...sources.map((source) => source.position.y + (source.measured?.height || 0))) + 130,
            };
        if (Math.abs(node.position.x - desired.x) < 1 && Math.abs(node.position.y - desired.y) < 1) return node;
        changed = true;
        return { ...node, position: desired };
      });
      return changed ? next : current;
    });
  }, [flowNodes, rootTasks, direction, manualPos, setNodes]);

  const commentTarget = openComments ? findInTree(openComments, filtered) : null;
  const commentTargetMerged = commentTarget ? merged(commentTarget) : null;

  return (
    <div
      data-case-mindmap-window
      className={
        fullscreen
          ? "fixed inset-0 z-50 bg-gradient-to-br from-slate-50 to-white"
          : "relative bg-gradient-to-br from-slate-50 to-white border border-slate-200 rounded-lg overflow-hidden"
      }
    >
      {/* 交互式新手引导 coach：随实操推进（填思路 → 挂任务 → 完成） */}
      {coach.active && (
        <div className="fixed bottom-6 right-6 z-[60] w-[288px] max-w-[calc(100vw-2rem)] max-h-[80vh] overflow-y-auto rounded-2xl bg-white shadow-2xl border border-slate-100">
          <div className="overflow-hidden rounded-2xl">
          <div
            className={`px-4 pt-3.5 pb-3 text-white bg-gradient-to-br ${
              coach.step === "thought"
                ? "from-amber-500 to-orange-500"
                : coach.step === "task"
                ? "from-[#0052D9] to-[#00A4FF]"
                : "from-emerald-500 to-teal-500"
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="text-[11px] font-medium tracking-wide opacity-90">
                {coach.step === "done" ? "🎉 已完成" : `第 ${coach.step === "thought" ? 1 : 2} / 2 步`}
              </div>
              {coach.step !== "done" && (
                <button onClick={closeCoach} title="跳过引导" className="w-6 h-6 rounded-md bg-white/15 hover:bg-white/25 flex items-center justify-center">
                  <X size={13} />
                </button>
              )}
            </div>
            <div className="mt-1 text-[15px] font-bold leading-snug">
              {coach.step === "thought" && "写下你的第一个怀疑方向"}
              {coach.step === "task" && "给思路挂一个执行任务"}
              {coach.step === "done" && "第一条排查线已建好！"}
            </div>
          </div>
          <div className="px-4 py-3">
            <p className="text-[12.5px] text-slate-600 leading-relaxed">
              {coach.step === "thought" &&
                "点画布上高亮的「＋ 新建思路」，用「因为 / 原理说明 / 所以」写下一个怀疑方向，然后点确认。"}
              {coach.step === "task" &&
                "把鼠标移到刚建好的思路卡上，点右上角蓝色 ＋，添加并填写一个执行任务（名称 / 任务负责人 / 部门 / 时间）。"}
              {coach.step === "done" &&
                "你已经建好「思路 → 执行任务」。之后用同样的方式：hover 卡片点 ＋，继续扩展怀疑树，把根因一层层查清。"}
            </p>
            {coach.step === "done" ? (
              <button
                onClick={closeCoach}
                className="mt-3 w-full h-8 rounded-lg bg-gradient-to-r from-emerald-500 to-teal-500 text-white text-[12.5px] font-medium inline-flex items-center justify-center gap-1.5 hover:shadow-md"
              >
                <Check size={14} /> 完成
              </button>
            ) : (
              <div className="mt-3 flex items-center justify-between">
                <span className="text-[11px] text-slate-400">👆 请按提示操作，自动进入下一步</span>
                <button onClick={closeCoach} className="text-[11px] text-slate-400 hover:text-slate-600">跳过</button>
              </div>
            )}
          </div>
          </div>
        </div>
      )}

      {/* Toolbar */}
      <div className="relative z-10 min-h-12 px-3 pt-3 flex items-start gap-2 flex-wrap bg-white/88 border-b border-slate-200/70 backdrop-blur-sm">
        {/* View filter (item 11) */}
        <div className="inline-flex items-center bg-white/95 border border-slate-200 rounded-lg p-0.5 shadow-sm">
          {([
            { k: "all", label: "全局视图", icon: Eye },
            { k: "incomplete", label: "只看未完成", icon: AlarmClock },
            { k: "valid", label: "只看有效路径", icon: Flag },
          ] as { k: ViewMode; label: string; icon: any }[]).map(({ k, label, icon: Icon }) => (
            <button
              key={k}
              onClick={() => setViewMode(k)}
              className={`h-7 px-2.5 rounded-md text-xs inline-flex items-center gap-1 transition-all ${
                viewMode === k ? "bg-[#0052D9] text-white shadow-sm" : "text-slate-600 hover:bg-slate-100"
              }`}
            >
              <Icon size={12} /> {label}
            </button>
          ))}
          {/* 只看我的：并入同一档位组（与视图档位独立，可叠加） */}
          <span className="w-px h-4 bg-slate-200 mx-0.5" />
          <button
            onClick={() => setOnlyMine((v) => !v)}
            title="只看我负责的任务（可与视图档位叠加）"
            className={`h-7 px-2.5 rounded-md text-xs inline-flex items-center gap-1 transition-all ${
              onlyMine ? "bg-[#0052D9] text-white shadow-sm" : "text-slate-600 hover:bg-slate-100"
            }`}
          >
            <User size={12} /> 只看我的
          </button>
        </div>
        {/* 按状态 / 部门 / 实际任务分派人筛选 */}
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          title="按任务状态筛选"
          className={`h-8 px-2 rounded-lg border shadow-sm text-xs outline-none cursor-pointer ${
            statusFilter === "全部" ? "bg-white/95 border-slate-200 text-slate-600" : "bg-[#0052D9] text-white border-[#0052D9]"
          }`}
        >
          {STATUS_OPTS.map((s) => <option key={s} value={s} className="text-slate-700">{s === "全部" ? "状态：全部" : s}</option>)}
        </select>
        <select
          value={deptFilter}
          onChange={(e) => setDeptFilter(e.target.value)}
          title="按部门筛选"
          className={`h-8 px-2 rounded-lg border shadow-sm text-xs outline-none cursor-pointer ${
            deptFilter === "全部" ? "bg-white/95 border-slate-200 text-slate-600" : "bg-[#0052D9] text-white border-[#0052D9]"
          }`}
        >
          {deptOpts.map((d) => <option key={d} value={d} className="text-slate-700">{d === "全部" ? "部门：全部" : d}</option>)}
        </select>
        <select
          value={creatorFilter}
          onChange={(event) => setCreatorFilter(event.target.value)}
          aria-label="任务树 创建人 / 任务分派人"
          title="创建人 / 任务分派人"
          className={`h-8 max-w-[180px] px-2 rounded-lg border shadow-sm text-xs outline-none cursor-pointer ${
            creatorFilter === "全部" ? "bg-white/95 border-slate-200 text-slate-600" : "bg-[#0052D9] text-white border-[#0052D9]"
          }`}
        >
          {!creatorOpts.includes(creatorFilter) && <option value={creatorFilter} className="text-slate-700">{creatorFilter}（当前无可选项）</option>}
          {creatorOpts.map(name => <option key={name} value={name} className="text-slate-700">{name === "全部" ? "创建人 / 任务分派人：全部" : name}</option>)}
        </select>
        {/* Layout direction (item 8) */}
        <button
          onClick={() => setDirection((d) => (d === "LR" ? "TB" : "LR"))}
          title={direction === "LR" ? "切换为竖向布局" : "切换为横向布局"}
          className="h-8 px-2.5 rounded-lg bg-white/95 border border-slate-200 shadow-sm text-xs text-slate-600 hover:text-[#0052D9] inline-flex items-center gap-1"
        >
          {direction === "LR" ? <MoveVertical size={13} /> : <MoveHorizontal size={13} />}
          {direction === "LR" ? "竖向" : "横向"}
        </button>
        {/* 折叠/展开已完成·死路（R19） */}
        <button
          onClick={() => setCollapsed((prev) => (prev.size ? new Set() : defaultCollapsed(filtered)))}
          title="折叠已完成/死路 或 全部展开"
          className="h-8 px-2.5 rounded-lg bg-white/95 border border-slate-200 shadow-sm text-xs text-slate-600 hover:text-[#0052D9] inline-flex items-center gap-1"
        >
          {collapsed.size ? "展开全部" : "折叠已完成"}
        </button>
        {/* 重新布局：清除手动拖拽位置（R18） */}
        {Object.keys(manualPos).length > 0 && (
          <button
            onClick={() => setManualPos({})}
            title="清除手动拖拽，恢复自动布局"
            className="h-8 px-2.5 rounded-lg bg-white/95 border border-slate-200 shadow-sm text-xs text-slate-600 hover:text-[#0052D9] inline-flex items-center gap-1"
          >
            <Eye size={13} /> 重新布局
          </button>
        )}
      </div>

      <button
        onClick={() => setFullscreen((v) => !v)}
        title={fullscreen ? "退出全屏" : "全屏"}
        className="absolute top-3 right-3 z-20 w-8 h-8 rounded-md bg-white/90 border border-slate-200 shadow-sm hover:bg-white flex items-center justify-center text-slate-600 hover:text-[#0052D9]"
      >
        {fullscreen ? <Minimize2 size={14} /> : <Maximize2 size={14} />}
      </button>

      <div className={fullscreen ? "h-[calc(100%-48px)] w-full" : "h-[600px] w-full"}>
        <ReactFlow
          onInit={setFlowInstance}
          nodes={flowNodes}
          edges={flowEdges}
          nodeTypes={NODE_TYPES}
          onNodesChange={onNodesChange}
          onNodeDragStop={(_, node) =>
            setManualPos((p) => ({ ...p, [node.id]: { x: node.position.x, y: node.position.y } }))
          }
          fitView
          minZoom={0.4}
          maxZoom={1.5}
          defaultViewport={{ x: 0, y: 0, zoom: 0.8 }}
          proOptions={{ hideAttribution: true }}
        >
          <Background />
          <MindMapZoomPill />
          <MiniMap
            zoomable
            pannable
            nodeColor={(node) => {
              if (node.type === "caseNode") return "#334155";
              if (node.type === "thoughtNode") return "#F59E0B";
              if (node.type === "actionNode") return "#0052D9";
              if (node.type === "verificationNode") return "#8b5cf6";
              if (node.type === "specialTaskNode") return "#f59e0b";
              return "#CBD5E1";
            }}
          />
        </ReactFlow>
      </div>
      <MaterialQueryDrawer query={materialQuery} />

      {commentTargetMerged && (
        <TaskCommentsPanel
          taskTitle={commentTargetMerged.title}
          comments={commentTargetMerged.comments ?? []}
          likes={commentTargetMerged.likes ?? 0}
          likedByMe={commentTargetMerged.likedByMe ?? false}
          onAddComment={(c) => addComment(commentTargetMerged.id, c)}
          onReply={(cid, c) => replyComment(commentTargetMerged.id, cid, c)}
          onToggleLike={() => toggleLike(commentTargetMerged.id)}
          onClose={() => setOpenComments(null)}
        />
      )}
      {previewAttachment && <AttachmentPreview attachment={previewAttachment} onClose={() => setPreviewAttachment(null)} />}
      {verificationError && !endingSpecial && <p role="alert" className="border-t border-red-200 bg-red-50 p-3 text-xs text-red-600">{verificationError}</p>}
      {endingSpecial && <TaskDialog title={endingSpecial.kind === "complete" ? "完成历史验证记录" : "取消历史验证记录"} description="仅更新此历史记录，不影响其他任务的状态或计时。" onClose={() => setEndingSpecial(undefined)} footer={<>
        <button onClick={() => setEndingSpecial(undefined)} className="h-9 rounded border border-slate-200 px-4 text-xs">返回</button>
        <button onClick={() => {
          try {
            manageCaseWaitingTask(caseItem.id, endingSpecial.parent.id, { kind: endingSpecial.kind, id: endingSpecial.task.id, result: specialResult });
            setEndingSpecial(undefined); setVerificationError("");
          } catch (error) { setVerificationError(error instanceof Error ? error.message : "特殊任务保存失败，请重试。"); }
        }} className="h-9 rounded bg-[#0052D9] px-4 text-xs text-white">确认</button>
      </>}><div className="mb-3 text-sm">{endingSpecial.task.title}</div><label className="text-xs text-slate-600">{endingSpecial.kind === "complete" ? "完成结果" : "取消原因"}<textarea aria-label="特殊任务结果或取消原因" value={specialResult} onChange={event => setSpecialResult(event.target.value)} maxLength={2000} className="mt-2 min-h-24 w-full rounded border border-slate-200 p-3" /></label>{verificationError && <p role="alert" className="mt-2 text-xs text-red-600">{verificationError}</p>}</TaskDialog>}
      {coverageCompleteTarget && <CompleteCoverageModal task={coverageCompleteTarget} onClose={() => setCoverageCompleteTarget(null)} onConfirm={(input) => {
        if (!onCompleteCoverage?.(coverageCompleteTarget.id, input)) return false;
        setPatternSourceId(coverageCompleteTarget.id);
        return true;
      }} />}
      {patternSourceId && (
        <div className="fixed inset-0 z-[140] bg-slate-900/45 flex items-center justify-center" onClick={() => setPatternSourceId(null)}>
          <div className="w-[680px] rounded-xl border border-slate-200 bg-white shadow-2xl p-5" onClick={(event) => event.stopPropagation()}>
            <div className="text-sm font-semibold text-slate-900">Pattern Fanout · 参数组合</div>
            <div className="mt-1 text-xs text-slate-500">选择要扩展验证的参数，系统按笛卡尔积自动创建 Coverage 上线任务。</div>
            <div className="mt-4 grid grid-cols-2 gap-3">
              {(Object.entries(PATTERN_FANOUT_OPTIONS) as [keyof PatternFanoutSelection, readonly string[]][]).map(([key, options]) => (
                <div key={key} className="rounded-lg border border-slate-200 p-3">
                  <div className="text-xs font-medium text-slate-700">{key === "speeds" ? "Speed" : key === "testers" ? "Tester" : key === "ballTypes" ? "Ball type" : "Quality Grade"}</div>
                  <div className="mt-2 flex flex-wrap gap-1.5">{options.map((option) => { const selected = patternSelection[key].includes(option); return <button key={option} onClick={() => setPatternSelection((current) => ({ ...current, [key]: selected ? current[key].filter((value) => value !== option) : [...current[key], option] }))} className={`h-7 px-2.5 rounded border text-xs ${selected ? "bg-cyan-600 border-cyan-600 text-white" : "bg-white border-slate-200 text-slate-600"}`}>{option}</button>; })}</div>
                </div>
              ))}
            </div>
            {(() => { const combinations = patternSelection.speeds.length * patternSelection.testers.length * patternSelection.ballTypes.length * patternSelection.qgs.length; return <div className="mt-4 rounded-lg bg-cyan-50 border border-cyan-200 px-3 py-2 text-xs text-cyan-800">将生成 {combinations} 组参数，TE / PE 各 1 个 Coverage 上线任务，共 {combinations * 2} 个任务。</div>; })()}
            <div className="mt-4 flex justify-end gap-2"><button onClick={() => setPatternSourceId(null)} className="h-8 px-3 rounded border border-slate-200 text-xs text-slate-600">取消</button><button disabled={Object.values(patternSelection).some((values) => values.length === 0)} onClick={() => { onPatternFanout?.(patternSourceId, patternSelection); setPatternSourceId(null); }} className="h-8 px-3 rounded bg-cyan-600 text-white text-xs disabled:opacity-40">创建 Coverage 上线任务</button></div>
          </div>
        </div>
      )}
      {resubmitTarget && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center bg-slate-900/45" onClick={() => setResubmitTarget(null)}>
          <section role="dialog" aria-modal="true" aria-label="确认重新提交整改任务" className="w-[420px] rounded-xl border border-slate-200 bg-white p-5 shadow-2xl" onClick={event => event.stopPropagation()}>
            <div className="flex items-start gap-3">
              <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-orange-50 text-orange-600"><CheckCheck size={18} /></div>
              <div className="min-w-0">
                <h3 className="text-sm font-semibold text-slate-900">确认重新提交整改任务？</h3>
                <p className="mt-1 text-xs leading-5 text-slate-500">任务“{resubmitTarget.title}”提交后将变为“已完成”，本次整改记录会保留。</p>
              </div>
            </div>
            {resubmitError && <p role="alert" className="mt-3 rounded-md bg-red-50 px-3 py-2 text-xs text-red-600">{resubmitError}</p>}
            <div className="mt-5 flex justify-end gap-2">
              <button type="button" onClick={() => setResubmitTarget(null)} className="h-8 rounded-md border border-slate-200 bg-white px-3 text-xs text-slate-600 hover:bg-slate-50">取消</button>
              <button type="button" onClick={() => { try { onResubmitRemediation?.(resubmitTarget.id); setResubmitTarget(null); setResubmitError(""); } catch (reason) { setResubmitError(reason instanceof Error ? reason.message : "重新提交失败，请重试。"); } }} className="h-8 rounded-md bg-orange-600 px-3 text-xs font-medium text-white hover:bg-orange-700">确认重新提交</button>
            </div>
          </section>
        </div>
      )}

      {/* legend —— 精简：仅紧急度色条对照 */}
      <div className="absolute bottom-3.5 left-[230px] px-3 py-1.5 text-[11px] text-slate-500 bg-white/95 border border-slate-200 rounded-lg shadow-sm flex items-center gap-2.5">
        {showMine && <span className="text-[#0052D9] font-medium">已聚焦我的</span>}
        <span className="text-slate-400">紧急度</span>
        <span className="inline-flex items-center gap-1"><span className="inline-block w-0.5 h-3 bg-red-400" />非常紧急</span>
        <span className="inline-flex items-center gap-1"><span className="inline-block w-0.5 h-3 bg-orange-400" />紧急</span>
        <span className="inline-flex items-center gap-1"><span className="inline-block w-0.5 h-3 bg-sky-400" />一般</span>
        <span className="inline-flex items-center gap-1"><span className="inline-block w-0.5 h-3 bg-slate-300" />不紧急</span>
      </div>
    </div>
  );
}

// ---- Case Node ----
function CaseNodeComponent({ data }: { data: any }) {
  const { caseItem, direction } = data;
  return (
    <div className="group/case relative bg-white border-2 border-slate-200 rounded-xl p-4 shadow-lg w-[280px] transition-shadow hover:shadow-xl">
      <Handle type="source" position={direction === "LR" ? Position.Right : Position.Bottom} />
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-1">
          <div className={`px-2 py-0.5 rounded text-xs border ${levelColors[caseItem.level]}`}>{caseItem.level}</div>
          <CaseProductPill caseItem={caseItem} compact />
        </div>
        <div className="text-xs text-slate-400 font-mono">{caseItem.code}</div>
      </div>
      <h4 className="text-sm font-medium text-slate-900 leading-snug mb-2 line-clamp-2">{caseItem.name}</h4>
      <div className="space-y-1.5 text-xs text-slate-500">
        <div className="flex items-center gap-1.5"><User size={12} /><span>Owner: {caseItem.owner}</span></div>
        <div className="flex items-center gap-1.5"><Building2 size={12} /><span>{caseItem.departments?.length || 0} 部门</span></div>
      </div>

      {/* Hover 查看 Case 背景 / 影响（#3） */}
      <div className="max-h-0 opacity-0 group-hover/case:max-h-[260px] group-hover/case:opacity-100 overflow-hidden transition-all duration-200">
        <div className="mt-3 pt-3 border-t border-slate-100 space-y-2">
          <div>
            <div className="text-[10px] text-slate-400 mb-0.5">背景（What &amp; Why）</div>
            <div className="text-[11px] text-slate-600 leading-relaxed line-clamp-4">{caseItem.background || "—"}</div>
          </div>
          {caseItem.impact && (
            <div>
              <div className="text-[10px] text-slate-400 mb-0.5">影响</div>
              <div className="text-[11px] text-slate-600 leading-relaxed line-clamp-3">{caseItem.impact}</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ---- small reusable card toolbar button ----
function MiniBtn({
  onClick, title, active, activeClass, children,
}: { onClick: (e: any) => void; title: string; active?: boolean; activeClass?: string; children: any }) {
  return (
    <button
      onClick={onClick}
      title={title}
      className={`w-6 h-6 rounded-full flex items-center justify-center transition-all ${
        active ? activeClass : "text-slate-500 hover:bg-slate-900/[0.06] hover:text-[#0052D9]"
      }`}
    >
      {children}
    </button>
  );
}

// 任务数据/附件的类型小图标
function AttIcon({ kind }: { kind: "pdf" | "image" | "sheet" | "file" }) {
  if (kind === "pdf") return <FileText size={12} className="text-rose-500" />;
  if (kind === "image") return <FileImage size={12} className="text-sky-500" />;
  if (kind === "sheet") return <FileSpreadsheet size={12} className="text-emerald-500" />;
  return <FileIcon size={12} className="text-slate-400" />;
}

// 结论有效性图标
function ValidityIcon({ v }: { v: string }) {
  if (v === "有效") return <CheckCircle2 size={12} className="text-emerald-600" />;
  if (v === "部分有效") return <AlertTriangle size={12} className="text-amber-600" />;
  return <XCircle size={12} className="text-slate-400" />; // 无效：中性灰，不用红（避让紧急度）
}

// 任务状态图标 —— 方案 B：实心圆形徽章（同色柔底 + 同色图标）
const STATUS_BADGE: Record<string, string> = {
  待接受: "bg-amber-100 text-amber-600",
  进行中: "bg-blue-100 text-blue-600",
  已完成: "bg-emerald-100 text-emerald-600",
  已中止: "bg-slate-100 text-slate-500",
  已拒绝: "bg-rose-100 text-rose-600",
};
function StatusIcon({ s }: { s: string }) {
  const Icon =
    s === "待接受" ? Clock :
    s === "进行中" ? CircleDot :
    s === "已完成" ? CheckCheck :
    s === "已中止" ? Ban :
    s === "已拒绝" ? XCircle : Circle;
  return (
    <span className={`inline-flex items-center justify-center w-[18px] h-[18px] rounded-full ${STATUS_BADGE[s] || "bg-slate-100 text-slate-500"}`}>
      <Icon size={11} strokeWidth={2.4} />
    </span>
  );
}

// ---- Thought Node (思路/怀疑方向) ----
function ThoughtNodeComponent({ data }: { data: any }) {
  const {
    task, caseTasks, direction, editable, onEdit, onSave, onCancel, onDelete, isEditing,
    thoughtText, setThoughtText, thoughtCategory, setThoughtCategory,
    onToggleLike, onOpenComments, onAddChild, onToggleMark,
    marked, isMarkRoot, dimmed, onHover,
    hasChildren, collapsed, collapsedCount, onToggleCollapse, onSplit,
    isCopied, onCopy, onPaste, onPatternFanout,
    thoughtSourceTaskIds, setThoughtSourceTaskIds, relationTasks, isValidation, validationReason,
  } = data;
  const isThoughtEmpty = !task.title?.trim() || task.title === "新的思路/怀疑方向";
  const isOtherCategory = thoughtCategory === "Other" || thoughtCategory === "其他" || thoughtCategory === "validation";
  const thoughtParts = isEditing ? parseThought(thoughtText) : ["", "", ""];
  const thoughtSaveable = !(thoughtCategory === "validation" && validationReason) && (isOtherCategory
    ? !!thoughtText.trim()
    : !!(thoughtParts[0].trim() && thoughtParts[2].trim()));
  const linkedTasks = (relationTasks || []).filter((candidate: RelationTask) => task.sourceTaskIds?.includes(candidate.id));
  const setThoughtPart = (idx: number, v: string) => {
    const next = [...thoughtParts] as [string, string, string];
    next[idx] = v;
    setThoughtText?.(composeThought(next));
  };

  const ring = isMarkRoot
    ? "!border-violet-500 border-2 ring-2 ring-violet-300/50"
    : marked
    ? "!border-violet-300 border-2"
    : "border border-amber-300";

  return (
    <div
      className={`relative w-[320px] transition-all ${dimmed ? "opacity-40" : ""}`}
      onMouseEnter={() => onHover?.(task.id)}
      onMouseLeave={() => onHover?.(null)}
    >
      <Handle type="target" position={direction === "LR" ? Position.Left : Position.Top} />
      <Handle type="source" position={direction === "LR" ? Position.Right : Position.Bottom} />
      <Handle type="target" id="relation-target" position={direction === "LR" ? Position.Left : Position.Top} style={{ opacity: 0, pointerEvents: "none" }} />

      {/* 折叠/展开按钮放卡片右侧外部（修改点 1） */}
      {!isEditing && hasChildren && (
        <button
          onClick={(e) => { e.stopPropagation(); onToggleCollapse?.(); }}
          title={collapsed ? `展开 ${collapsedCount} 个子节点` : "折叠子节点"}
          className="absolute top-1/2 -right-3 -translate-y-1/2 z-30 h-6 min-w-6 px-1.5 rounded-full bg-white border border-slate-200 shadow-sm flex items-center justify-center text-[10px] tabular-nums text-slate-500 hover:text-[#0052D9] hover:border-[#0052D9]/40 transition-colors"
        >
          {collapsed ? `+${collapsedCount}` : "－"}
        </button>
      )}

      <div className={`relative bg-amber-50/60 rounded-xl p-3.5 group/thought transition-all duration-200 hover:scale-[1.03] hover:shadow-md ${ring}`}>
        {!isEditing ? (
          <>
            {editable && (
              <div className="absolute top-2 right-2 z-20 flex items-center gap-0.5 opacity-0 group-hover/thought:opacity-100 transition-opacity">
                <MiniBtn onClick={onEdit} title="编辑"><Pencil size={12} /></MiniBtn>
                {!isValidation && <MiniBtn onClick={(e) => { e.stopPropagation(); onToggleMark?.(task.id); }} title="标记整条线" active={isMarkRoot} activeClass="bg-violet-500 text-white"><Flag size={12} /></MiniBtn>}
                {onCopy && <MiniBtn onClick={(e) => { e.stopPropagation(); onCopy(); }} title="复制此节点及子树" active={isCopied} activeClass="bg-[#0052D9] text-white"><Copy size={12} /></MiniBtn>}
                {onPaste && <MiniBtn onClick={(e) => { e.stopPropagation(); onPaste(); }} title="粘贴为子节点"><ClipboardPaste size={12} /></MiniBtn>}
                {!isValidation && <MiniBtn onClick={() => { if (confirm(`删除思路「${task.title}」及其所有执行任务？`)) onDelete?.(task.id); }} title="删除"><Trash2 size={12} /></MiniBtn>}
                <button
                  onClick={(e) => { e.stopPropagation(); onAddChild?.(); }}
                  title={isValidation ? "新增验证任务" : "添加执行任务"}
                  className="w-6 h-6 rounded-full bg-[#0052D9] text-white shadow-sm flex items-center justify-center hover:bg-[#003FA8]"
                >
                  <Plus size={13} />
                </button>
              </div>
            )}
            <div className="flex items-center gap-1.5 mb-2">
              <span className="text-[11px] text-amber-700 font-medium tracking-wide shrink-0">思路 / 怀疑方向</span>
              {task.category && (
                <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[10px] bg-amber-100 text-amber-700 border border-amber-200 shrink-0 whitespace-nowrap">
                  <Tag size={9} /> {task.category}
                </span>
              )}
            </div>

            {/* R24：未填写时显示撰写引导，填写后隐藏 */}
            {isThoughtEmpty ? (
              <button
                onClick={onEdit}
                className="text-left w-full text-[12px] text-amber-600/70 italic leading-relaxed hover:text-amber-700"
              >
                点此填写：怀疑什么 + 为什么怀疑（一个方向写一个节点）
              </button>
            ) : (
              <p className="text-[13px] text-slate-800 leading-relaxed font-medium">{task.title}</p>
            )}
            {task.sourceTaskIds?.length > 0 && (
              <button onClick={(event) => { event.stopPropagation(); onEdit?.(); }} className="mt-2 w-full rounded-md border border-blue-100 bg-blue-50/70 p-2 text-left hover:border-[#0052D9]/30">
                <span className="flex items-center gap-1 text-[10px] font-semibold text-[#0052D9]"><Link2 size={10} />关联结果 · {task.sourceTaskIds.length}</span>
                <span className="mt-1 block space-y-1">{linkedTasks.slice(0, 2).map((linked: RelationTask) => <span key={linked.id} className="block"><span className="block truncate text-[10.5px] font-medium text-slate-700">{linked.title}</span><span className="block truncate text-[9.5px] text-slate-500">{linked.conclusion ? `结论：${linked.conclusion}` : `预期：${linked.expectation || "暂无"}`}</span></span>)}</span>
                {task.sourceTaskIds.length > 2 && <span className="mt-1 block text-[9.5px] text-[#0052D9]">另有 {task.sourceTaskIds.length - 2} 个任务 · 点击管理</span>}
              </button>
            )}
            {task.patternFanoutTaskIds?.length ? <div className="mt-2 text-[10px] text-cyan-700">已生成 {Math.ceil(task.patternFanoutTaskIds.length / 2)} 组参数 · {task.patternFanoutTaskIds.length} 个任务</div> : null}

            {/* full info on hover */}
            {!isValidation && <div className="max-h-0 opacity-0 group-hover/thought:max-h-[160px] group-hover/thought:opacity-100 overflow-hidden transition-all duration-200">
              <div className="pt-2 mt-2 border-t border-amber-200/60 flex items-center gap-1.5">
                <button
                  onClick={(e) => { e.stopPropagation(); onToggleLike?.(task.id); }}
                  className={`h-5 px-1.5 text-[10px] rounded inline-flex items-center gap-0.5 ${
                    task.likedByMe ? "bg-amber-100 text-amber-700" : "text-slate-500 hover:bg-amber-50"
                  }`}
                >
                  <ThumbsUp size={10} /> {task.likes || 0}
                </button>
                <button
                  onClick={(e) => { e.stopPropagation(); onOpenComments?.(task.id); }}
                  className="h-5 px-1.5 text-[10px] rounded inline-flex items-center gap-0.5 text-slate-500 hover:bg-amber-50"
                >
                  <MessageCircle size={10} /> {(task.comments || []).length}
                </button>
              </div>
            </div>}
          </>
        ) : (
          <>
            <div className="flex items-center justify-between mb-2.5">
              <div className="text-xs text-amber-700 font-medium">编辑思路 / 怀疑方向</div>
              <select
                aria-label="思路标签"
                disabled={isValidation}
                value={thoughtCategory || "Testing"}
                onChange={(e) => setThoughtCategory?.(e.target.value)}
                className="h-6 rounded-full border px-2 text-[11px] outline-none border-amber-300 text-amber-700 bg-amber-50"
              >
                {THOUGHT_CATEGORIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
            {thoughtCategory === "validation" && validationReason && <p role="status" className="mb-2 text-[11px] text-amber-700">{validationReason}</p>}
            {isOtherCategory ? (
              <div>
                <div className="text-[11px] font-semibold text-slate-600 mb-1">工作思路 <span className="text-red-500">*</span></div>
                <textarea
                  value={thoughtText}
                  onChange={(e) => setThoughtText?.(e.target.value)}
                  placeholder="请填写工作思路"
                  autoFocus
                  className="w-full min-h-[88px] p-2 rounded border border-slate-200 bg-white text-[12.5px] leading-relaxed outline-none focus:border-amber-500 resize-y"
                />
              </div>
            ) : (
              <>
                <div className="space-y-2">
                  <div>
                    <div className="text-[11px] font-semibold text-slate-600 mb-1">
                      因为 <span className="text-red-500">*</span>
                    </div>
                    <input
                      value={thoughtParts[0]}
                      onChange={(e) => setThoughtPart(0, e.target.value)}
                      placeholder="看到什么失效现象，关联以往什么 case"
                      autoFocus
                      className="w-full h-8 px-2 rounded border border-slate-200 bg-white text-[12.5px] outline-none focus:border-amber-500"
                    />
                  </div>
                  <div>
                    <div className="text-[11px] font-semibold text-slate-600 mb-1 inline-flex items-center gap-1.5">
                      原理说明 <span className="text-[10px] font-normal text-slate-400 border border-slate-200 rounded-full px-1.5 leading-4">选填</span>
                    </div>
                    <input
                      value={thoughtParts[1]}
                      onChange={(e) => setThoughtPart(1, e.target.value)}
                      placeholder="补充原理内容，可增加Case评分"
                      className="w-full h-8 px-2 rounded border border-dashed border-slate-300 bg-slate-50 text-[12.5px] outline-none focus:border-slate-400 focus:bg-white"
                    />
                  </div>
                  <div>
                    <div className="text-[11px] font-semibold text-slate-600 mb-1">
                      所以 <span className="text-red-500">*</span>
                    </div>
                    <input
                      value={thoughtParts[2]}
                      onChange={(e) => setThoughtPart(2, e.target.value)}
                      placeholder="怀疑和什么有关"
                      className="w-full h-8 px-2 rounded border border-slate-200 bg-white text-[12.5px] outline-none focus:border-amber-500"
                    />
                  </div>
                </div>
                <div className="mt-1.5 text-[10px] text-amber-600/80">「因为」和「所以」必填，原理说明选填</div>
              </>
            )}
            {thoughtCategory !== "validation" && <div className="mt-2.5 pt-2.5 border-t border-amber-200/70">
              <div className="flex items-center justify-between"><span className="text-[10.5px] text-slate-500">来源任务 <span className="text-slate-400">（选填）</span></span><TaskRelationPicker tasks={relationTasks || []} value={thoughtSourceTaskIds || []} onChange={setThoughtSourceTaskIds} /></div>
              {(thoughtSourceTaskIds?.length || 0) > 0 && <div className="mt-1.5 text-[10px] text-[#0052D9]">已关联 {thoughtSourceTaskIds.length} 个任务，创建后自动展示关系连线</div>}
            </div>}
            <div className="flex gap-2 mt-2.5">
              <button
                onClick={onSave}
                disabled={!thoughtSaveable}
                className={`flex-1 h-7 rounded text-white text-xs ${thoughtSaveable ? "bg-[#0052D9] hover:bg-[#003FA8]" : "bg-slate-300 cursor-not-allowed"}`}
              >
                确认
              </button>
              <button onClick={onCancel} className="flex-1 h-7 rounded border border-slate-200 text-slate-600 text-xs hover:bg-slate-50">取消</button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ---- Action Node (执行任务) — small by default, expands on hover ----
function ActionNodeComponent({ data }: { data: any }) {
  const {
    task, direction, editable, onEdit, onSave, onCancel, onDelete, isEditing,
    actionForm, setActionForm, onTaskClick, onToggleLike, onOpenComments, onAddChild,
    marked, isMarkRoot, dimmed,
    onToggleMark, onHover,
    hasChildren, collapsed, collapsedCount, onToggleCollapse,
    isCopied, onCopy, onPaste,
    followed, onToggleFollow, onCompleteCoverage, onPreviewAttachment, onResubmitRemediation,
    caseInRemediation, onAddVerification, isVerificationTask, canManage, onComplete,
  } = data;

  const [efaModalOpen, setEfaModalOpen] = useState(false);
  const [reuseOpen, setReuseOpen] = useState(false);
  const [reuseTaskId, setReuseTaskId] = useState("");
  const [reuseError, setReuseError] = useState("");
  const [reusedTaskCode, setReusedTaskCode] = useState("");
  const reuseTask = (rawTaskId = reuseTaskId) => {
    const query = rawTaskId.trim().toLowerCase();
    const candidates = [
      ...flattenTasks(caseTasks || []).map(({ task: item }) => item),
      ...mockCases.flatMap((item) => flattenTasks(item.tasks).map(({ task: candidate }) => candidate)),
    ];
    const sourceTask = candidates.find((item) => item.id.toLowerCase() === query || item.code?.toLowerCase() === query);
    if (!sourceTask) {
      setReuseError("未找到该任务 ID，请检查后重试。");
      return;
    }
    setActionForm?.({
      ...actionForm,
      title: sourceTask.title,
      expectation: sourceTask.expectation || "",
      urgency: sourceTask.urgency,
      department: sourceTask.department,
      assignee: sourceTask.owner === "待指派" ? "" : sourceTask.owner,
      assigneeType: sourceTask.assigneeType,
      skillId: sourceTask.skillId,
      skillRun: undefined,
      dueDate: sourceTask.dueDate || "",
      voiceNote: sourceTask.voiceNote,
      attachments: sourceTask.attachments?.map((attachment) => ({ ...attachment })) || [],
      type: sourceTask.type || (sourceTask.efaAnalysis ? "EFA分析" : ""),
      coverageProgramVersion: sourceTask.coverageProgramVersion || "",
      coverageTestName: sourceTask.coverageTestName || "",
      coverageTestTime: sourceTask.coverageTestTime || "",
      coverageActionStage: sourceTask.coverageActionStage || "",
      coverageBallType: sourceTask.coverageBallType || "",
      coveragePackage: sourceTask.coveragePackage || "",
      coverageSpeed: sourceTask.coverageSpeed || "",
      coverageTester: sourceTask.coverageTester || "",
      coverageQG: sourceTask.coverageQG || "",
      coverageStatus: sourceTask.coverageStatus || "",
      coverageReleaseType: sourceTask.coverageReleaseType || "",
      coverageTeOwner: sourceTask.coverageTeOwner || "",
      coveragePeOwner: sourceTask.coveragePeOwner || "",
      efaAnalysis: sourceTask.efaAnalysis ? structuredClone(sourceTask.efaAnalysis) : undefined,
    });
    setReusedTaskCode(sourceTask.code || sourceTask.id);
    setReuseError("");
    setReuseOpen(false);
  };

  const remediationStyle = task.status === "整改中" || caseInRemediation;
  const baseBg = remediationStyle ? "bg-orange-50/70" : "bg-white";
  const ring = isMarkRoot
    ? "!border-violet-500 border-2 ring-2 ring-violet-300/50"
    : marked
    ? "!border-violet-300 border-2"
    : remediationStyle
    ? "border-2 border-orange-300 ring-2 ring-orange-100"
    : "border border-slate-200";

  if (isEditing) {
    return (
      <div className={`relative ${actionForm?.type === "EFA分析" ? "w-[560px]" : "w-[280px]"} z-50`}>
        <Handle type="target" position={direction === "LR" ? Position.Left : Position.Top} />
        {!isVerificationTask && !task.externalVerification && <Handle type="source" position={direction === "LR" ? Position.Right : Position.Bottom} />}
        <div className={`nowheel bg-white border-2 border-[#0052D9] rounded-xl p-3.5 shadow-xl space-y-2.5 overflow-y-auto overscroll-contain ${actionForm?.type === "EFA分析" ? "max-h-[55vh]" : "max-h-[78vh]"}`}>
          <div className="sticky top-[-14px] z-20 -mx-3.5 -mt-3.5 px-3.5 pt-3.5 pb-2 flex items-center justify-between border-b border-slate-100 bg-white/95 backdrop-blur">
            <div className="text-xs text-[#0052D9] font-medium">编辑执行任务</div>
            <div className="flex items-center gap-1.5">
              {!isVerificationTask && <button type="button" onClick={() => { setReuseOpen((open) => !open); setReuseError(""); }} className="h-6 rounded-full border border-[#0052D9]/25 px-2 text-[11px] text-[#0052D9] hover:bg-[#0052D9]/5 inline-flex items-center gap-1"><Copy size={11} />复用</button>}
              <select
                aria-label="任务标签"
                disabled={isVerificationTask || Boolean(task.externalVerification)}
                value={actionForm?.type || "通用"}
                onChange={(e) => {
                  const type = e.target.value as TaskType;
                  setActionForm?.({ ...actionForm, type, efaAnalysis: type === "EFA分析" ? (actionForm?.efaAnalysis || efaDefaults(caseItem)) : undefined });
                }}
                className="h-6 rounded-full border px-2 text-[11px] text-center outline-none border-[#0052D9]/30 text-[#0052D9] bg-[#0052D9]/5"
              >
                {(isVerificationTask || task.externalVerification ? ["验证"] : TASK_TYPES).map((t) => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </div>
            {(isVerificationTask || task.externalVerification) && <p className="text-[11px] leading-relaxed text-slate-500">外部验证是独立普通任务，归属内部对接负责人所在部门，不暂停或扣减其他任务。</p>}
          </div>
          {reuseOpen && (
            <div className="rounded-lg border border-[#0052D9]/20 bg-[#0052D9]/[0.04] p-2.5">
              <label className="text-[11px] text-slate-600">任务 ID<input autoFocus value={reuseTaskId} onChange={(event) => { setReuseTaskId(event.target.value); setReuseError(""); }} onKeyDown={(event) => { if (event.key === "Enter") { event.preventDefault(); event.stopPropagation(); reuseTask(event.currentTarget.value); } }} placeholder="输入任务 ID 或任务编号后回车" className="mt-1 h-8 w-full rounded border border-slate-200 bg-white px-2 text-xs outline-none focus:border-[#0052D9]" /></label>
              {reuseError && <div className="mt-1.5 text-[10px] text-red-500">{reuseError}</div>}
            </div>
          )}
          {reusedTaskCode && <div className="rounded border border-emerald-200 bg-emerald-50 px-2 py-1 text-[10px] text-emerald-700">已复用 {reusedTaskCode} 的任务字段，当前任务 ID 与状态保持不变。</div>}
          <div>
            <label className="text-xs text-slate-500 block mb-1">任务名称</label>
            <input
              aria-label={isVerificationTask ? "验证任务名称" : undefined}
              value={actionForm?.title || ""}
              onChange={(e) => setActionForm?.({ ...actionForm, title: e.target.value })}
              placeholder="符合预期怎么做 + 不符合怎么做"
              className="w-full h-8 px-2 text-sm border border-slate-200 rounded outline-none focus:border-[#0052D9]"
            />
            <div className="mt-1 text-[10px] text-slate-400">建议：执行任务名称 = 符合预期怎么做 + 不符合怎么做</div>
          </div>
          <div>
            <label className="text-xs text-slate-500 block mb-1">预期</label>
            <input
              aria-label={isVerificationTask ? "验证任务预期" : undefined}
              maxLength={isVerificationTask ? 500 : undefined}
              value={actionForm?.expectation || ""}
              onChange={(e) => setActionForm?.({ ...actionForm, expectation: e.target.value })}
              placeholder="预期"
              className="w-full h-8 px-2 text-sm border border-slate-200 rounded outline-none focus:border-[#0052D9]"
            />
          </div>
          <div className="flex gap-2">
            <div className="flex-1">
              <label className="text-xs text-slate-500 block mb-1">紧急程度</label>
              <select
                value={actionForm?.urgency || "一般"}
                onChange={(e) => setActionForm?.({ ...actionForm, urgency: e.target.value })}
                className="w-full h-8 px-2 text-sm border border-slate-200 rounded outline-none focus:border-[#0052D9]"
              >
                <option value="非常紧急">非常紧急</option>
                <option value="紧急">紧急</option>
                <option value="一般">一般</option>
                <option value="不紧急">不紧急</option>
              </select>
            </div>
            <div className="flex-1">
              <label className="text-xs text-slate-500 block mb-1">期望完成时间{isVerificationTask || task.externalVerification ? "（选填）" : ""}</label>
              <input
                type="date"
                value={actionForm?.dueDate || ""}
                onChange={(e) => setActionForm?.({ ...actionForm, dueDate: e.target.value })}
                className="w-full h-8 px-2 text-sm border border-slate-200 rounded outline-none focus:border-[#0052D9]"
              />
            </div>
          </div>
          <div className="flex gap-2">
            <div className="flex-1 min-w-0">
              <label className="text-xs text-slate-500 block mb-1">任务负责人</label>
              {isVerificationTask ? <PersonInput value={actionForm?.assignee || ""} onChange={assignee => setActionForm?.({ ...actionForm, assignee })} /> : <TaskAssigneeField compact value={{ assignee: actionForm?.assignee || "", department: actionForm?.department || "PTE", assigneeType: actionForm?.assigneeType, skillId: actionForm?.skillId, skillRun: actionForm?.skillRun }} onChange={(next) => setActionForm?.({ ...actionForm, ...next })} />}
            </div>
            <div className="flex-1">
              <label className="text-xs text-slate-500 block mb-1">分派部门</label>
              <select
                value={actionForm?.department || "PTE"}
                onChange={(e) => setActionForm?.({ ...actionForm, department: e.target.value })}
                className="w-full h-8 px-2 text-sm border border-slate-200 rounded outline-none focus:border-[#0052D9]"
              >
                {MM_DEPARTMENTS.map((d) => (
                  <option key={d} value={d}>{d}</option>
                ))}
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="min-w-0">
              <label className="text-xs text-slate-500 block mb-1">附件</label>
              <AttachmentInput
                value={actionForm?.attachments || []}
                onChange={(next) => setActionForm?.({ ...actionForm, attachments: next })}
                compact
              />
            </div>
            <div className="min-w-0">
              <label className="text-xs text-slate-500 block mb-1">语音备注</label>
              <VoiceRecorder
                value={actionForm?.voiceNote}
                onChange={(v) => setActionForm?.({ ...actionForm, voiceNote: v })}
                compact
              />
            </div>
          </div>
          {actionForm?.type === "Coverage分析上线" && (
            <div className="rounded-lg border border-cyan-200 bg-cyan-50/60 p-2.5 space-y-2.5">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-cyan-800">
                <Radar size={13} /> Coverage 上线信息
              </div>
              <CoveragePatternFields compact value={actionForm || {}} onChange={(next) => setActionForm?.({ ...actionForm, ...next })} />
              <div>
                <label className="text-[11px] text-slate-500 block mb-1">程式版本 <span className="text-red-500">*</span></label>
                <input
                  value={actionForm?.coverageProgramVersion || ""}
                  onChange={(e) => setActionForm?.({ ...actionForm, coverageProgramVersion: e.target.value })}
                  placeholder="请输入程式版本"
                  className="w-full h-8 px-2 text-xs bg-white border border-slate-200 rounded outline-none focus:border-cyan-500"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-500 block mb-1">测试项名称 <span className="text-red-500">*</span></label>
                <input
                  value={actionForm?.coverageTestName || ""}
                  onChange={(e) => setActionForm?.({ ...actionForm, coverageTestName: e.target.value })}
                  placeholder="请输入测试项名称"
                  className="w-full h-8 px-2 text-xs bg-white border border-slate-200 rounded outline-none focus:border-cyan-500"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-500 block mb-1">测试时长 <span className="text-red-500">*</span></label>
                <input
                  value={actionForm?.coverageTestTime || ""}
                  onChange={(e) => setActionForm?.({ ...actionForm, coverageTestTime: e.target.value })}
                  placeholder="请输入测试时长"
                  className="w-full h-8 px-2 text-xs bg-white border border-slate-200 rounded outline-none focus:border-cyan-500"
                />
              </div>
              <CoverageOwnerFields compact value={actionForm || {}} onChange={(next) => setActionForm?.({ ...actionForm, ...next })} />
            </div>
          )}
          {actionForm?.type === "EFA分析" && (
            <div className="rounded-lg border border-violet-300 bg-violet-50/70">
              <div className="flex items-center gap-2 p-2.5"><FlaskConical size={14} className="text-violet-600 shrink-0" /><span className="text-xs font-medium text-slate-700">EFA 分析信息</span>{actionForm?.efaAnalysis?.code && <span className="ml-auto font-mono text-[10px] text-violet-600 shrink-0">{actionForm.efaAnalysis.code}</span>}</div>
              <div className="px-2.5 pb-2.5 pt-2 border-t border-violet-100 nodrag nopan nowheel">
                <EfaInlineFields value={actionForm.efaAnalysis || efaDefaults(caseItem)} onChange={(v) => setActionForm?.({ ...actionForm, efaAnalysis: v })} />
              </div>
            </div>
          )}
          <div className="sticky bottom-[-14px] z-20 -mx-3.5 -mb-3.5 px-3.5 pt-2 pb-3.5 flex gap-2 border-t border-slate-100 bg-white/95 backdrop-blur">
            <button onClick={onSave} className="flex-1 h-7 rounded bg-[#0052D9] text-white text-xs hover:bg-[#003FA8]">确认</button>
            <button onClick={onCancel} className="flex-1 h-7 rounded border border-slate-200 text-slate-600 text-xs hover:bg-slate-50">取消</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      className={`relative w-[256px] transition-opacity ${dimmed ? "opacity-40" : ""}`}
      onMouseEnter={() => onHover?.(task.id)}
      onMouseLeave={() => onHover?.(null)}
    >
      <Handle type="target" position={direction === "LR" ? Position.Left : Position.Top} />
      {!isVerificationTask && !task.externalVerification && <Handle type="source" position={direction === "LR" ? Position.Right : Position.Bottom} />}
      {!isVerificationTask && !task.externalVerification && <Handle type="source" id="relation-source" position={direction === "LR" ? Position.Right : Position.Bottom} style={{ opacity: 0, pointerEvents: "none" }} />}

      {/* 折叠/展开按钮放卡片右侧外部（修改点 1） */}
      {hasChildren && (
        <button
          onClick={(e) => { e.stopPropagation(); onToggleCollapse?.(); }}
          title={collapsed ? `展开 ${collapsedCount} 个子节点` : "折叠子节点"}
          className="absolute top-1/2 -right-3 -translate-y-1/2 z-30 h-6 min-w-6 px-1.5 rounded-full bg-white border border-slate-200 shadow-sm flex items-center justify-center text-[10px] tabular-nums text-slate-500 hover:text-[#0052D9] hover:border-[#0052D9]/40 transition-colors"
        >
          {collapsed ? `+${collapsedCount}` : "－"}
        </button>
      )}

      <div className={`relative ${baseBg} ${ring} rounded-xl overflow-hidden shadow-sm group/action transition-all duration-200 hover:scale-[1.03] hover:shadow-xl`}>
        {/* 左侧紧急度细色条：未结束（待接受/进行中）显示；终态不显示 */}
        {ACTIVE_STATUS.has(task.status) && (
          <div className={`absolute left-0 top-0 bottom-0 w-1 ${urgencyBar[task.urgency] || "bg-slate-300"}`} title={`紧急度：${task.urgency}`} />
        )}

        <div className="relative pl-4 pr-3 py-3">
          {/* 卡片头：默认展示类型与关注；hover 时原位切换完整工具条，避免绝对定位互相覆盖 */}
          <div className="flex items-center gap-1.5 min-h-6 mb-1.5" title={task.status}>
            <StatusBadge status={task.status} size={18} />
            <div className={`ml-auto min-w-0 items-center gap-1 ${editable ? "flex group-hover/action:hidden" : "flex"}`}>
              {task.type && (
                <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[10px] border whitespace-nowrap bg-slate-100 text-slate-600 border-slate-200">
                  <Tag size={9} /> {task.type}
                </span>
              )}
              <button
                type="button"
                hidden={isVerificationTask}
                onClick={(e) => { e.stopPropagation(); onToggleFollow?.(); }}
                title={followed ? "取消关注任务" : "关注后每天通过 HEMS 接收任务更新"}
                className={`nodrag h-5 px-1.5 rounded border inline-flex items-center gap-1 text-[9.5px] font-medium whitespace-nowrap transition-colors ${followed ? "border-[#0052D9]/30 bg-[#0052D9]/[0.07] text-[#0052D9]" : "border-slate-200 bg-white text-slate-400 hover:border-[#0052D9]/30 hover:text-[#0052D9]"}`}
              >
                {followed ? <BellRing size={10} /> : <Bell size={10} />}
                {followed ? "已关注" : "关注"}
              </button>
            </div>
            {editable && (
              <div className="ml-auto hidden items-center gap-0.5 group-hover/action:flex">
                <MiniBtn
                  onClick={(e) => { e.stopPropagation(); onToggleFollow?.(); }}
                  title={followed ? "取消关注任务" : "关注任务"}
                  active={followed}
                  activeClass="bg-[#0052D9] text-white"
                >
                  {followed ? <BellRing size={12} /> : <Bell size={12} />}
                </MiniBtn>
                <MiniBtn onClick={onEdit} title="编辑"><Pencil size={12} /></MiniBtn>
                <MiniBtn onClick={(e) => { e.stopPropagation(); onToggleMark?.(task.id); }} title="标记整条线" active={isMarkRoot} activeClass="bg-violet-500 text-white"><Flag size={12} /></MiniBtn>
                {onCopy && <MiniBtn onClick={(e) => { e.stopPropagation(); onCopy(); }} title="复制此节点及子树" active={isCopied} activeClass="bg-[#0052D9] text-white"><Copy size={12} /></MiniBtn>}
                {onPaste && <MiniBtn onClick={(e) => { e.stopPropagation(); onPaste(); }} title="粘贴为子节点"><ClipboardPaste size={12} /></MiniBtn>}
                <MiniBtn onClick={() => { if (confirm(`删除执行任务「${task.title}」及其所有子任务？`)) onDelete?.(task.id); }} title="删除"><Trash2 size={12} /></MiniBtn>
                <button
                  onClick={(e) => { e.stopPropagation(); onAddChild?.(); }}
                  title="基于此动作添加思路"
                  hidden={Boolean(task.externalVerification)}
                  className="w-6 h-6 rounded-full bg-[#0052D9] text-white shadow-sm flex items-center justify-center hover:bg-[#003FA8]"
                >
                  <Plus size={13} />
                </button>
              </div>
            )}
          </div>

          {/* ① 任务名称（动作） */}
          <button
            disabled={isVerificationTask}
            onClick={() => onTaskClick?.(task.id)}
            className="text-[13px] font-semibold text-slate-900 leading-snug hover:text-[#0052D9] text-left w-full"
          >
            {task.title}
          </button>
          {isVerificationTask && <div className="mt-2 space-y-1 text-[10px] text-slate-500">
            <div>任务负责人：{task.owner}</div>
            <div>预期完成：{task.dueDate || "未设置（选填）"}</div>
            {canManage && <div className="flex gap-2 pt-1"><button onClick={onComplete} className="nodrag rounded bg-[#0052D9] px-2 py-1 text-white">完成</button><button onClick={onCancel} className="nodrag rounded border border-slate-200 bg-white px-2 py-1">取消</button></div>}
          </div>}
          {task.externalVerification && <div className="mt-2 text-[10px] text-slate-500">外部验证 · 独立计时</div>}
          {onAddVerification && <button type="button" aria-label="添加验证节点" onClick={onAddVerification} className="nodrag mt-2 inline-flex h-6 items-center gap-1 rounded border border-violet-200 bg-violet-50 px-2 text-[10px] text-violet-700"><Plus size={11} />验证</button>}
          {task.status === "整改中" && (
            <div className="mt-2 rounded-md border border-orange-200 bg-orange-50 px-2 py-1.5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[10.5px] font-medium text-orange-700">所属 Case 已退回整改</span>
                {onResubmitRemediation && <button type="button" onClick={event => { event.stopPropagation(); onResubmitRemediation(); }} className="h-6 shrink-0 rounded-md bg-orange-600 px-2 text-[10px] font-medium text-white hover:bg-orange-700">重新提交</button>}
              </div>
              <p className="mt-0.5 text-[9.5px] text-orange-600/80">请完成修改并保存后重新提交</p>
            </div>
          )}


        {/* 状态驱动的内容（R27）：进行中=预期 / 已完成=结论+有效性 / 已中止=中止理由 / 已拒绝=拒绝理由 / 待接受=仅名称和预期 */}
        {(task.status === "待接受" || task.status === "进行中") && task.expectation && (
          <div className="mt-2 flex items-start gap-1.5">
            <span className="shrink-0 text-[10px] text-slate-400 mt-px w-7">预期</span>
            <p className="flex-1 text-[11px] text-slate-600 leading-snug line-clamp-2">{task.expectation}</p>
          </div>
        )}
        {task.status === "已完成" && (task.conclusion || task.validity) && (
          <div className="mt-1.5 flex items-start gap-1.5">
            <span className="shrink-0 text-[10px] text-slate-400 mt-px w-7">结论</span>
            <div className="flex-1 min-w-0">
              {task.conclusion && (
                <p className="text-[11px] text-slate-600 leading-snug line-clamp-2">{task.conclusion}</p>
              )}
              {task.validity && (
                <button
                  onClick={(e) => { e.stopPropagation(); onTaskClick?.(task.id); }}
                  title="查看 Workspace 笔记"
                  className={`mt-1 inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] border cursor-pointer transition-[filter] hover:brightness-95 ${validityColors[task.validity]}`}
                >
                  <ValidityIcon v={task.validity} /> 结论{task.validity} <ExternalLink size={10} />
                </button>
              )}
            </div>
          </div>
        )}
        {task.status === "已中止" && task.terminateReason && (
          <div className="mt-2 flex items-start gap-1.5">
            <span className="shrink-0 text-[10px] text-slate-400 mt-px w-7">中止</span>
            <p className="flex-1 text-[11px] text-slate-500 leading-snug line-clamp-2">{task.terminateReason}</p>
          </div>
        )}
        {task.status === "已拒绝" && task.rejectReason && (
          <div className="mt-2 flex items-start gap-1.5">
            <span className="shrink-0 text-[10px] text-rose-400 mt-px w-7">拒绝</span>
            <p className="flex-1 text-[11px] text-rose-600/90 leading-snug line-clamp-2">{task.rejectReason}</p>
          </div>
        )}

        {/* EFA 分析单：作为任务属性展示（不再是独立节点） */}
        {task.efaAnalysis && (
          <button
            onClick={(e) => { e.stopPropagation(); onTaskClick?.(task.id); }}
            title="查看 EFA 分析单详情"
            className="mt-2 w-full flex items-center gap-1.5 px-2 py-1 rounded-md border border-violet-200 bg-violet-50/70 text-[10.5px] text-violet-700 hover:bg-violet-100 transition-colors"
          >
            <FlaskConical size={11} className="shrink-0" />
            <span className="font-medium shrink-0">EFA 分析单</span>
            {task.efaAnalysis.code && <span className="font-mono truncate">{task.efaAnalysis.code}</span>}
            <span className="ml-auto shrink-0 inline-flex items-center gap-0.5">{task.efaAnalysis.submitted ? "已提交" : "待提交"} <ExternalLink size={9} /></span>
          </button>
        )}

        {/* hover 展开：任务负责人(悬停看部门) / 预期完成 / 录音 / 数据 / 点赞评论 */}
        <div className="max-h-0 opacity-0 group-hover/action:max-h-[360px] group-hover/action:opacity-100 overflow-hidden transition-all duration-200">
          <div className="mt-2 pt-2 border-t border-slate-200/70 space-y-1.5 text-[11px] text-slate-500">
            <div className="flex items-center gap-1.5">
              <User size={11} /> 任务负责人：
              <span className="relative group/own text-slate-700 underline decoration-dotted decoration-slate-300 cursor-help">
                {task.owner}
                <span className="pointer-events-none absolute left-0 top-full mt-1 z-30 whitespace-nowrap rounded bg-slate-800 px-1.5 py-0.5 text-[10px] text-white opacity-0 group-hover/own:opacity-100 transition-opacity">
                  部门：{task.department}
                </span>
              </span>
            </div>
            {task.dueDate && <div className="flex items-center gap-1.5"><Calendar size={11} /> 预期完成：{task.dueDate}</div>}
            {task.type === "Coverage分析上线" && (task.coverageTestName || task.coverageTestTime || task.coverageActionStage || task.coverageSpeed || task.coverageTester || task.coverageBallType || task.coverageQG || task.coverageStatus) && (
              <div className="rounded-md border border-cyan-100 bg-cyan-50/70 px-2 py-1.5 space-y-1 text-[10px] text-cyan-800">
                <div className="flex items-center gap-1 font-medium"><Radar size={10} /> Coverage 上线</div>
                <div className="grid grid-cols-2 gap-x-2 gap-y-0.5">
                  {task.coverageTestName && <span>test：{task.coverageTestName}</span>}
                  {task.coverageTestTime && <span>time：{task.coverageTestTime}</span>}
                  {task.coverageActionStage && <span>stage：{task.coverageActionStage}</span>}
                  {task.coverageSpeed && <span>Speed：{task.coverageSpeed}</span>}
                  {task.coverageTester && <span>Tester：{task.coverageTester}</span>}
                  {task.coverageBallType && <span>Ball：{task.coverageBallType}</span>}
                  {task.coverageQG && <span>QG：{task.coverageQG}</span>}
                  {task.coverageStatus && <span>Coverage 状态：{task.coverageStatus}</span>}
                </div>
              </div>
            )}
            {(task.attachments?.length || task.voiceNote) && (
              <div className="flex items-center gap-1.5 flex-wrap">
                {task.attachments && task.attachments.length > 0 && (
                  <>
                    <span className="text-slate-400 shrink-0">附件：</span>
                <span className="flex flex-wrap items-center gap-1">
                  {task.attachments.map((a, i) => (
                    <button
                      key={i}
                      title={a.name}
                      onClick={(event) => { event.stopPropagation(); if (a.kind === "image" || /\.(ppt|pptx)$/i.test(a.name)) onPreviewAttachment?.(a); else if (a.url) { const link = document.createElement("a"); link.href = a.url; link.download = a.name; link.click(); } }}
                      className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-white/70 border border-slate-200 text-[10px] text-slate-600 hover:border-[#0052D9] hover:text-[#0052D9] cursor-pointer transition-colors"
                    >
                      {a.kind === "image" && a.url ? <img src={a.url} alt="" className="w-8 h-8 rounded object-cover" /> : <AttIcon kind={a.kind} />} {a.name}
                    </button>
                  ))}
                </span>
                  </>
                )}
                {task.voiceNote && <VoicePlayer src={task.voiceNote} />}
              </div>
            )}
            {!isVerificationTask && <div className="pt-1 flex items-center gap-1.5">
              <button
                onClick={(e) => { e.stopPropagation(); onToggleLike?.(task.id); }}
                className={`h-5 px-1.5 text-[10px] rounded inline-flex items-center gap-0.5 ${
                  task.likedByMe ? "bg-[#0052D9]/10 text-[#0052D9]" : "text-slate-500 hover:bg-slate-100"
                }`}
              >
                <ThumbsUp size={10} /> {task.likes || 0}
              </button>
              <button
                onClick={(e) => { e.stopPropagation(); onOpenComments?.(task.id); }}
                className="h-5 px-1.5 text-[10px] rounded inline-flex items-center gap-0.5 text-slate-500 hover:bg-slate-100"
              >
                <MessageCircle size={10} /> {(task.comments || []).length}
              </button>
            </div>}
          </div>
        </div>
        </div>
      </div>
    </div>
  );
}

// ---- Linked EFA Analysis Node ----
function EfaAnalysisNodeComponent({ data }: { data: any }) {
  const { task, value, direction, editable, onSave } = data as {
    task: TaskNode;
    value: EfaAnalysisCard;
    direction: Direction;
    editable: boolean;
    onSave?: (value: EfaAnalysisCard) => void;
  };
  const cloneValue = (v: EfaAnalysisCard): EfaAnalysisCard => ({
    ...v,
    chipList: (v.chipList?.length ? v.chipList : [{ fsa: "", map: "", failMode: "", waferNo: "", chipNo: "", markCode: "" }]).map((x) => ({ ...x })),
  });
  const [draft, setDraft] = useState<EfaAnalysisCard>(() => cloneValue(value));
  const [editing, setEditing] = useState(() => !value?.submitted);
  useEffect(() => {
    setDraft(cloneValue(value));
    setEditing(!value?.submitted);
  }, [value]);

  const setField = (key: keyof EfaAnalysisCard, next: any) => {
    setDraft((prev) => ({ ...prev, [key]: next }));
  };
  const updateChip = (index: number, key: string, next: string) => {
    setDraft((prev) => ({
      ...prev,
      chipList: (prev.chipList ?? []).map((chip, i) => i === index ? { ...chip, [key]: next } : chip),
    }));
  };
  const inputClass = "nodrag nowheel w-full h-7 px-2 text-[11px] bg-white border border-slate-200 rounded outline-none focus:border-violet-500 disabled:bg-slate-50 disabled:text-slate-500";
  const fields = draft.chipList ?? [];
  const submitted = !!draft.submitted && !editing;
  const canEdit = editable && !submitted;

  if (submitted) {
    const modeLabel = draft.mode === "component" ? "Component" : draft.mode === "wafer" ? "Wafer" : "未分类";
    const summary = draft.mode === "component"
      ? [draft.standard, draft.stage, draft.package, fields.length ? `${fields.length} 颗 chip` : ""].filter(Boolean).join(" · ")
      : [draft.stage, draft.bin && `Bin ${draft.bin}`, draft.chipNo && `Chip ${draft.chipNo}`].filter(Boolean).join(" · ");
    return (
      <div className="relative w-[256px]">
        <Handle type="target" position={direction === "LR" ? Position.Left : Position.Top} />
        <Handle type="source" position={direction === "LR" ? Position.Right : Position.Bottom} />
        <div className="rounded-xl border border-slate-200 bg-white shadow-sm overflow-hidden">
          <div className="px-3 py-2.5 flex items-center gap-2.5">
            <span className="w-7 h-7 rounded-lg bg-violet-50 text-violet-600 grid place-items-center shrink-0">
              <FlaskConical size={14} />
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <span className="text-[12px] font-semibold text-slate-800">EFA 分析单</span>
                <span className="inline-flex items-center gap-1 text-[9px] text-emerald-700">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> 已提交
                </span>
              </div>
              <div className="mt-0.5 text-[9.5px] text-slate-500 truncate" title={summary || modeLabel}>
                {modeLabel}{summary ? ` · ${summary}` : ""}
              </div>
            </div>
            {editable && (
              <button
                type="button"
                onClick={() => setEditing(true)}
                title="展开并编辑 EFA 单"
                className="nodrag w-7 h-7 rounded-md border border-slate-200 text-slate-400 hover:border-violet-300 hover:text-violet-600 grid place-items-center shrink-0"
              >
                <Pencil size={11} />
              </button>
            )}
          </div>
          <div className="px-3 py-1.5 border-t border-slate-100 bg-slate-50/70 text-[9.5px] text-slate-400 truncate" title={task.title}>
            来源：{task.title}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-[360px]">
      <Handle type="target" position={direction === "LR" ? Position.Left : Position.Top} />
      <Handle type="source" position={direction === "LR" ? Position.Right : Position.Bottom} />
      <div className={`rounded-xl border-2 bg-white shadow-lg overflow-hidden transition-colors ${submitted ? "border-emerald-300" : "border-violet-300"}`}>
        <div className={`px-3.5 py-3 border-b transition-colors ${submitted ? "bg-gradient-to-r from-emerald-50 to-teal-50 border-emerald-100" : "bg-gradient-to-r from-violet-50 to-fuchsia-50 border-violet-100"}`}>
          <div className="flex items-center gap-2">
            <span className={`w-7 h-7 rounded-lg text-white grid place-items-center ${submitted ? "bg-emerald-600" : "bg-violet-600"}`}>{submitted ? <CheckCircle2 size={14} /> : <FlaskConical size={14} />}</span>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <div className="text-[13px] font-bold text-slate-800">新增EFA分析单</div>
                {submitted && <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-700 border border-emerald-200">已提交</span>}
              </div>
              <div className="text-[10px] text-slate-500 truncate">来源：{task.title}</div>
            </div>
          </div>
        </div>
        <div className="p-3 space-y-3">
          <div>
            <div className="text-[10px] text-slate-500 mb-1.5">分析对象</div>
            <div className="grid grid-cols-2 gap-2 nodrag">
              {(["component", "wafer"] as const).map((mode) => (
                <button
                  key={mode}
                  type="button"
                  disabled={!canEdit}
                  onClick={() => setField("mode", mode)}
                  className={`h-8 rounded-lg border text-[11px] font-semibold transition-colors disabled:cursor-default ${draft.mode === mode ? submitted ? "border-emerald-500 bg-emerald-600 text-white" : "border-violet-500 bg-violet-600 text-white" : "border-slate-200 bg-white text-slate-600 hover:border-violet-300"}`}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>

          {!draft.mode && (
            <div className="rounded-lg border border-dashed border-violet-200 bg-violet-50/50 px-3 py-4 text-center text-[11px] text-violet-700">
              请先选择 component 或 wafer
            </div>
          )}

          {draft.mode === "component" && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                {([
                  ["standard", "standard"],
                  ["stage", "stage"],
                  ["package", "package"],
                  ["quality", "quality"],
                  ["failRate", "fail rate"],
                ] as [keyof EfaAnalysisCard, string][]).map(([key, label]) => (
                  <label key={String(key)} className="text-[10px] text-slate-500">
                    {label}
                    <input
                      disabled={!canEdit}
                      value={String(draft[key] ?? "")}
                      onChange={(e) => setField(key, e.target.value)}
                      placeholder={`请输入 ${label}`}
                      className={`mt-1 ${inputClass}`}
                    />
                  </label>
                ))}
              </div>
              <div className="pt-2 border-t border-slate-100">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-semibold text-slate-600">chiplist</span>
                  {canEdit && (
                    <button
                      type="button"
                      onClick={() => setField("chipList", [...fields, { fsa: "", map: "", failMode: "", waferNo: "", chipNo: "", markCode: "" }])}
                      className="nodrag text-[10px] text-violet-600 hover:text-violet-800 inline-flex items-center gap-0.5"
                    >
                      <Plus size={10} /> 添加颗粒
                    </button>
                  )}
                </div>
                <div className="space-y-2">
                  {fields.map((chip, index) => (
                    <div key={index} className="rounded-lg bg-slate-50 border border-slate-100 p-2">
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-[9px] text-slate-400">#{index + 1}</span>
                        {canEdit && fields.length > 1 && (
                          <button type="button" onClick={() => setField("chipList", fields.filter((_, i) => i !== index))} className="nodrag text-slate-300 hover:text-red-500"><X size={11} /></button>
                        )}
                      </div>
                      <div className="grid grid-cols-3 gap-1.5">
                        {([
                          ["fsa", "fsa"], ["map", "map"], ["failMode", "fail mode"],
                          ["waferNo", "waferno"], ["chipNo", "chipno"], ["markCode", "markcode"],
                        ] as const).map(([key, label]) => (
                          <label key={key} className="text-[9px] text-slate-400">
                            {label}
                            <input disabled={!canEdit} value={chip[key] || ""} onChange={(e) => updateChip(index, key, e.target.value)} className={`mt-0.5 ${inputClass}`} />
                          </label>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {draft.mode === "wafer" && (
            <div className="grid grid-cols-2 gap-2">
              {([
                ["stage", "stage"], ["bin", "bin"], ["fsa", "fsa"], ["map", "map"], ["chipNo", "chipno"],
              ] as [keyof EfaAnalysisCard, string][]).map(([key, label]) => (
                <label key={String(key)} className="text-[10px] text-slate-500">
                  {label}
                  <input disabled={!canEdit} value={String(draft[key] ?? "")} onChange={(e) => setField(key, e.target.value)} className={`mt-1 ${inputClass}`} />
                </label>
              ))}
            </div>
          )}

          {canEdit && draft.mode && (
            <button
              type="button"
              onClick={() => {
                const submittedValue = { ...draft, submitted: true };
                setDraft(submittedValue);
                setEditing(false);
                onSave?.(submittedValue);
              }}
              className="nodrag w-full h-8 rounded-lg bg-violet-600 text-white text-[11px] font-semibold hover:bg-violet-700 inline-flex items-center justify-center gap-1.5"
            >
              <Check size={12} /> 提交 EFA 单
            </button>
          )}
          {submitted && (
            <div className="rounded-lg border border-emerald-200 bg-emerald-50 px-2.5 py-2 flex items-center gap-2">
              <CheckCircle2 size={14} className="text-emerald-600 shrink-0" />
              <div className="min-w-0 flex-1"><div className="text-[10.5px] font-semibold text-emerald-700">EFA 单已提交</div><div className="text-[9.5px] text-emerald-600/80">字段已保存并锁定</div></div>
              {editable && <button type="button" onClick={() => setEditing(true)} className="nodrag h-7 px-2 rounded-md bg-white border border-emerald-200 text-[10px] text-emerald-700 hover:bg-emerald-100 inline-flex items-center gap-1"><Pencil size={10} /> 编辑</button>}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ---- Add Button Node ----
function AddButtonNodeComponent({ data }: { data: any }) {
  const { onClick, direction, guideHighlight } = data;
  return (
    <div className="relative">
      <Handle type="target" position={direction === "LR" ? Position.Left : Position.Top} />
      {guideHighlight && (
        <>
          <span className="pointer-events-none absolute -inset-2 rounded-full ring-4 ring-amber-400/70 animate-ping" />
          <span className="pointer-events-none absolute -inset-2 rounded-full ring-2 ring-amber-400" />
          <div className="pointer-events-none absolute left-1/2 -translate-x-1/2 -top-11 whitespace-nowrap rounded-lg bg-amber-500 text-white text-[11px] font-medium px-2.5 py-1 shadow-lg">
            ① 点这里新建第一个思路
          </div>
        </>
      )}
      <button
        onClick={onClick}
        className={`w-12 h-12 rounded-full border-2 border-dashed flex items-center justify-center transition-all shadow-sm bg-white ${
          guideHighlight
            ? "border-amber-400 text-amber-500 bg-amber-50"
            : "border-slate-300 hover:border-[#0052D9] hover:bg-[#0052D9]/5 text-slate-400 hover:text-[#0052D9]"
        }`}
        title="添加新思路"
      >
        <Plus size={20} />
      </button>
    </div>
  );
}
