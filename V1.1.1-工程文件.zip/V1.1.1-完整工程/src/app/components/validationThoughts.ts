import { PROBLEM_DOMAINS, currentUser, ownerToDepartment, type TaskNode } from "./data";
import type { ThoughtGroup } from "./CreateCase";
import type { WaitingTask } from "./waitingTasks";
import { materializeExternalVerificationTasks } from "./externalVerificationTasks";

export const THOUGHT_CATEGORIES = [...PROBLEM_DOMAINS, "Other", "validation"];
export const isFreeTextThought = (category?: string) => ["Other", "其他", "validation"].includes(category ?? "");

export function draftValidationReason(groups: ThoughtGroup[], id: string, parentGroups?: ThoughtGroup[]): string {
  for (const group of groups) {
    if (group.id === id) {
      if (!parentGroups) return "validation 必须添加在普通任务之后，不能直接添加在 Case 下。";
      if (parentGroups.some(sibling => sibling.id !== id && sibling.category === "validation")) return "该任务已有 validation 思路，请在原思路下添加验证任务。";
      if (group.sourceTaskIds?.length || (group.category !== "validation" && group.actions.length)) return "已有普通任务或来源关联的思路不能切换为 validation，请新建空思路。";
      return "";
    }
    for (const action of group.actions) {
      if (action.childGroups?.length) {
        const found = findDraftGroup(action.childGroups, id);
        if (found) return draftValidationReason(action.childGroups, id, action.childGroups);
      }
    }
  }
  return "思路不存在，请重新打开。";
}

export function findDraftGroup(groups: ThoughtGroup[], id: string): ThoughtGroup | undefined {
  for (const group of groups) {
    if (group.id === id) return group;
    for (const action of group.actions) {
      const found = findDraftGroup(action.childGroups ?? [], id);
      if (found) return found;
    }
  }
}

// 提交后外部验证转为独立待接受任务，不跟随原任务状态流转。
export function materializeDraftValidation(tasks: TaskNode[], groups: ThoughtGroup[], now = new Date().toISOString()): TaskNode[] {
  const attach = (nodes: TaskNode[]): TaskNode[] => nodes.map(node => {
    const children = node.children ? attach(node.children) : undefined;
    if (!node.code) return { ...node, children };
    const validation = children?.find(child => child.category === "validation");
    if (!validation) return { ...node, children };
    const group = findDraftGroup(groups, validation.id);
    if (!group) throw new Error("验证思路未找到，请重新检查任务编排。");
    const reason = draftValidationReason(groups, group.id);
    if (reason) throw new Error(reason);
    const waitingTasks: WaitingTask[] = group.actions.map(action => {
      if (action.type !== "验证" || action.childGroups?.length) throw new Error("validation 思路下只能添加无子节点的验证任务。");
      if (!action.title.trim() || !action.expectation?.trim() || !action.assignee.trim()) throw new Error("请填写验证任务名称、预期和任务负责人。");
      if (!ownerToDepartment[action.assignee.trim()]) throw new Error("请为验证任务选择有效的人员负责人。");
      if (action.expectation.trim().length > 500) throw new Error("验证任务预期不能超过 500 个字符。");
      if (action.dueDate && !Number.isFinite(Date.parse(action.dueDate))) throw new Error("验证任务预计完成日期无效。");
      return {
        id: action.id, parentTaskId: node.id, title: action.title.trim(), reason: "验证", verificationKind: "external",
        description: action.expectation.trim(), owner: action.assignee.trim(), assignedBy: currentUser.name,
        createdAt: now, dueDate: action.dueDate || undefined, status: "待开始",
        department: action.department, urgency: action.urgency, attachments: action.attachments,
        voiceNote: action.voiceNote, note: action.note,
      };
    });
    if (node.status === "已完成" && waitingTasks.length) throw new Error("已完成的任务不能预编排等待开始的验证任务。");
    return { ...node, children, waitingTasks, verificationNode: { id: `verification-${node.id}`, thoughtId: group.id, title: group.thought, createdAt: now } };
  });
  for (const group of groups) {
    if (group.category === "validation") throw new Error("validation 必须添加在普通任务之后。");
  }
  return materializeExternalVerificationTasks(attach(tasks), ownerToDepartment);
}
