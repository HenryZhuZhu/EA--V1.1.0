import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Handle, Position, type Node, type Edge } from "@xyflow/react";
import { Hash, LoaderCircle, Tag, User, X } from "lucide-react";
import { Content as DialogContent } from "@radix-ui/react-dialog";
import { Sheet, SheetClose, SheetHeader, SheetTitle } from "./ui/sheet";
import { MaterialQuerySession, materialQueryGroups, materialQueryInputError, queryDemoMaterial, type MaterialData, type MaterialQueryInput, type MaterialQueryRecord } from "./materialQueryModel";

export function useMaterialDataQuery(inputs: MaterialQueryInput[], background: string, showDiagram: () => void, initialRecords: MaterialQueryRecord[] = []) {
  const [revision, update] = useState(0);
  const [session] = useState(() => new MaterialQuerySession(queryDemoMaterial, () => update(value => value + 1), initialRecords));
  const [errors, setErrors] = useState<string[]>([]);
  const [selectedChip, setSelectedChip] = useState<string>();
  const [focus, setFocus] = useState({ chipId: "", revision: 0 });
  const diagramRef = useRef<HTMLElement>(null);
  const groups = materialQueryGroups(inputs);
  const key = JSON.stringify(groups);
  const lastBatch = useRef<string[]>([]);
  const [notice, setNotice] = useState(false);
  const locateTimer = useRef<ReturnType<typeof setTimeout>>();
  const records = useMemo(() => {
    const groupMap = new Map(groups.map(group => [group.chipId, group.fingerprint]));
    return session.list().filter(record => groupMap.get(record.chipId) === record.fingerprint);
  }, [session, key, revision]);
  useLayoutEffect(() => {
    session.sync(inputs); setErrors([]);
    if (selectedChip && !session.list().some(record => record.chipId === selectedChip)) setSelectedChip(undefined);
    if (!session.list().length) setNotice(false);
  }, [session, key, selectedChip]);
  useEffect(() => () => { session.dispose(); clearTimeout(locateTimer.current); }, [session]);
  const locate = useCallback((chipId?: string) => {
    showDiagram();
    setFocus(previous => ({ chipId: chipId ?? session.list()[0]?.chipId ?? "", revision: previous.revision + 1 }));
    setNotice(false); clearTimeout(locateTimer.current);
    locateTimer.current = setTimeout(() => diagramRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 80);
  }, [showDiagram, session]);
  const query = (refresh = false, chipId?: string) => {
    const requested = chipId !== undefined ? groups.filter(group => group.chipId === chipId) : groups;
    const validation = [
      ...(!background.trim() ? ["请先填写问题背景。"] : []),
      ...(!requested.length ? ["请先填写至少一个 Chip ID。"] : []),
      ...requested.filter(group => materialQueryInputError(group.chipId)).map(group => `${group.chipId}：${materialQueryInputError(group.chipId)}`),
    ];
    setErrors(validation);
    if (!background.trim() || !requested.length) return validation;
    session.sync(inputs);
    const started = session.run(requested.filter(group => !materialQueryInputError(group.chipId)), refresh);
    if (started.length) { lastBatch.current = started; locate(started[0]); }
    else if (!validation.length) locate(chipId);
    return validation;
  };
  const loading = records.filter(record => record.status === "loading").length;
  useEffect(() => {
    if (!lastBatch.current.length || loading) return;
    const complete = records.some(record => lastBatch.current.includes(record.chipId) && record.status !== "loading");
    lastBatch.current = [];
    const element = diagramRef.current;
    const rect = element?.getBoundingClientRect();
    if (complete && element?.getClientRects().length && (!rect || rect.bottom < 0 || rect.top > window.innerHeight)) setNotice(true);
  }, [loading, key, records]);
  const clear = () => { session.clear(); setErrors([]); setSelectedChip(undefined); lastBatch.current = []; setNotice(false); };
  return {
    records, groups, errors, loading, query, clear, locate, focus, diagramRef, notice,
    dismissNotice: () => setNotice(false), selectedChip,
    selected: records.find(record => record.chipId === selectedChip),
    open: useCallback((chipId: string) => setSelectedChip(chipId), []),
    close: () => setSelectedChip(undefined),
  };
}
export type MaterialQueryController = ReturnType<typeof useMaterialDataQuery>;

export function materialQueryBranch(query: MaterialQueryController, direction: "LR" | "TB", origin: { x: number; y: number }, highlighted = ""): { nodes: Node[]; edges: Edge[] } {
  if (!query.records.length) return { nodes: [], edges: [] };
  const nodes: Node[] = [{
    id: "material-query-thought", type: "materialQueryThoughtNode", draggable: false, deletable: false,
    position: origin, data: { direction },
  }];
  const edges: Edge[] = [{
    id: "case-material-query-thought", source: "case", target: "material-query-thought",
    sourceHandle: direction === "LR" ? "right" : "bottom",
    type: "smoothstep", deletable: false, style: { stroke: "#cbd5e1", strokeWidth: 2 },
  }];
  query.records.forEach((record, index) => {
    const id = `material-query:${record.chipId}`;
    nodes.push({
      id, type: "materialQueryNode", draggable: false, deletable: false,
      position: direction === "LR" ? { x: origin.x + 460, y: origin.y + index * 220 }
        : { x: origin.x + index * 340, y: origin.y + 360 },
      data: { record, direction, selected: query.selected?.chipId === record.chipId, highlighted: highlighted === record.chipId, onOpen: query.open },
    });
    edges.push({ id: `thought-${id}`, source: "material-query-thought", target: id, type: "smoothstep", deletable: false, style: { stroke: "#94a3b8", strokeWidth: 2 } });
  });
  return { nodes, edges };
}

export function CpIndexQueryButton({ query, chipId }: { query: MaterialQueryController; chipId: string }) {
  const [errors, setErrors] = useState<string[]>([]);
  useEffect(() => setErrors([]), [chipId]);
  const loading = query.records.some(record => record.chipId === chipId.trim() && record.status === "loading");
  return <div className="min-w-0">
    <button type="button" aria-label={`CP INDEX ${chipId.trim() || "未填写 Chip ID"}`} title="查询当前物料并定位到思维导图（模拟数据）"
      onClick={() => setErrors(query.query(false, chipId.trim()))}
      className="inline-flex h-6 items-center gap-1 whitespace-nowrap rounded border border-slate-200 bg-white px-2 text-[10.5px] text-slate-600 transition-colors hover:border-[#0052D9]/50 hover:bg-[#0052D9]/5 hover:text-[#0052D9]">
      {loading ? <LoaderCircle size={12} className="animate-spin" /> : <Hash size={12} />}CP INDEX
    </button>
    {errors.length > 0 && <p role="alert" className="mt-1 max-w-[220px] whitespace-normal break-words text-[10px] text-red-600">{errors.join(" ")}</p>}
  </div>;
}
export interface MaterialQueryNodeData extends Record<string, unknown> {
  record: MaterialQueryRecord;
  direction: "LR" | "TB";
  selected: boolean;
  highlighted: boolean;
  onOpen: (chipId: string) => void;
}
export function MaterialQueryThoughtNode({ data }: { data: { direction: "LR" | "TB" } }) {
  return <div data-material-agent-thought className="relative w-[320px] rounded-xl border border-amber-300 bg-amber-50/60 p-3.5">
    <Handle type="target" position={data.direction === "LR" ? Position.Left : Position.Top} />
    <Handle type="source" position={data.direction === "LR" ? Position.Right : Position.Bottom} />
    <div className="mb-2 flex items-center gap-1.5">
      <span className="shrink-0 text-[11px] font-medium tracking-wide text-amber-700">思路 / 怀疑方向</span>
      <span className="inline-flex shrink-0 items-center gap-0.5 whitespace-nowrap rounded border border-amber-200 bg-amber-100 px-1.5 py-0.5 text-[10px] text-amber-700"><Tag size={9} />Agent</span>
    </div>
    <p className="text-[13px] font-medium leading-relaxed text-slate-800">查询物料cp index结果，辅助后续分析</p>
  </div>;
}
export function MaterialQueryNode({ data }: { data: MaterialQueryNodeData }) {
  const { record } = data;
  const title = `${record.chipId} cp index分析`;
  return <div data-material-chip={record.chipId} className={`w-[300px] rounded-xl border bg-white p-3.5 shadow-sm ${data.selected || data.highlighted ? "border-[#0052D9] ring-2 ring-blue-100" : "border-slate-200"}`}>
    <Handle type="target" position={data.direction === "LR" ? Position.Left : Position.Top} />
    <div className="mb-2 flex items-center justify-between"><span className="text-[11px] text-slate-500">Agent 任务</span><span data-agent-task-type className="inline-flex items-center gap-0.5 rounded border border-slate-200 bg-slate-100 px-1.5 py-0.5 text-[10px] text-slate-500"><Tag size={9} />agent分析</span></div>
    <div data-agent-task-name className="truncate text-[13px] font-semibold text-slate-900" title={title}>{title}</div>
    <div className="mt-2 space-y-1 text-[11px] text-slate-500">
      <div className="flex items-center gap-1.5"><User size={11} />任务负责人：<span data-agent-task-owner className="text-slate-700">DS agent</span></div>
      <div>部门：<span data-agent-task-department className="text-slate-700">PTE</span></div>
    </div>
    <p className="mt-2 text-[11px] text-slate-500">{record.status === "loading" ? "正在查询关联数据…" : record.status === "ready" ? `${record.data?.tests.length} 条测试记录 · ${record.data?.imageId ? "1 张 Wafer 图" : "暂无 Wafer 图片"}` : record.status === "empty" ? "暂无记录，不代表无异常" : "查询失败，可在结果抽屉重试"}</p>
    <div className="mt-3 flex justify-end border-t border-slate-100 pt-2">
      <button type="button" disabled={record.status === "loading"} onClick={() => data.onOpen(record.chipId)} className="nodrag nopan h-7 rounded bg-[#0052D9] px-2.5 text-[11px] text-white disabled:opacity-40">查看查询结果</button>
    </div>
  </div>;
}

function WaferPreview({ data, zoom }: { data: MaterialData; zoom: number }) {
  const cells = [];
  for (let y = -5; y <= 5; y++) for (let x = -5; x <= 5; x++) {
    if (x * x + y * y > 27) continue;
    cells.push(<rect key={`${x}/${y}`} x={142 + x * 21} y={142 + y * 21} width={19} height={19} rx={1} fill={((x + 5) * 3 + (y + 5) * 5 + (data.imageVariant ?? 0)) % 13 === 0 ? "#f59e0b" : "#73b9df"} />);
  }
  return <svg role="img" aria-label={`${data.wafer} 合成 Wafer Map`} viewBox="0 0 304 320" style={{ width: 360 * zoom, maxWidth: "none" }} className="mx-auto shrink-0"><rect width="304" height="320" fill="#f8fafc" /><circle cx="152" cy="152" r="127" fill="white" stroke="#bccbdc" strokeWidth="2" />{cells}<path d="M142 275 L152 265 L162 275" fill="#f8fafc" stroke="#bccbdc" /><text x="152" y="309" textAnchor="middle" fill="#7e8da3" fontSize="10">{data.wafer} · 合成示意图／非真实图</text></svg>;
}
export function MaterialQueryDrawer({ query }: { query: MaterialQueryController }) {
  const [tab, setTab] = useState<"form" | "image">("form");
  const [zoom, setZoom] = useState(1);
  const record = query.selected;
  useEffect(() => { setTab("form"); setZoom(1); }, [record?.chipId, record?.requestId]);
  return <>
    <Sheet modal={false} open={Boolean(record)} onOpenChange={open => { if (!open) query.close(); }}>
      <DialogContent aria-describedby={undefined} onInteractOutside={event => event.preventDefault()} className="absolute inset-y-0 right-0 z-30 flex w-[520px] max-w-full flex-col overflow-hidden border-l border-slate-200 bg-white shadow-xl outline-none data-[state=open]:animate-in data-[state=open]:slide-in-from-right data-[state=open]:duration-200">
        <SheetHeader className="min-w-0 border-b border-slate-100 pr-12"><SheetTitle className="truncate" title={`${record?.chipId ?? ""} CP Index分析结果`}>{record?.chipId} CP Index分析结果</SheetTitle></SheetHeader>
        <SheetClose aria-label="关闭查询结果" className="absolute right-4 top-4 rounded p-1 text-slate-500 hover:bg-slate-100 hover:text-slate-800"><X size={16} /></SheetClose>
        {record && <div className="min-h-0 flex-1 overflow-y-auto p-5">
          <div className="mt-1 text-[10px] text-slate-400">查询时间：{record.queriedAt ? new Date(record.queriedAt).toLocaleString("zh-CN") : "—"}</div>
          {record.status === "loading" ? <p role="status" className="mt-5 text-xs text-slate-500">正在查询…</p> : record.status === "error" ? <p role="alert" className="mt-5 text-xs text-red-600">{record.error}</p> : record.status === "empty" ? <p className="mt-5 rounded border border-dashed border-slate-200 p-5 text-xs text-slate-500">该物料暂无记录，不代表无异常。请核对 Chip ID。</p> : record.data && <>
            <div className="my-4 flex gap-2">{(["form", "image"] as const).map(value => <button key={value} type="button" aria-pressed={tab === value} onClick={() => setTab(value)} className={`h-8 rounded border px-3 text-xs ${tab === value ? "border-blue-200 bg-blue-50 text-[#0052D9]" : "border-slate-200 text-slate-500"}`}>{value === "form" ? "表单" : "Wafer 图片"}</button>)}</div>
            <dl className="grid grid-cols-2 gap-3 rounded bg-slate-50 p-3 text-xs text-slate-600">{[["Lot", record.data.lot], ["Wafer", record.data.wafer], ["Die 坐标", record.data.die], ["记录时间", record.data.recordedAt]].map(([label, value]) => <div key={label}><dt className="text-[10px] text-slate-400">{label}</dt><dd>{value}</dd></div>)}</dl>
            {tab === "form" ? <><table aria-label="物料测试记录" className="mt-4 w-full text-left text-xs"><thead className="bg-slate-50 text-slate-500"><tr>{["站点", "温度", "电压", "结果", "Bin"].map(label => <th key={label} className="p-2 font-medium">{label}</th>)}</tr></thead><tbody>{record.data.tests.map((test, index) => <tr key={index} className="border-b border-slate-100">{[test.stage, test.temperature, test.voltage, test.result, test.bin].map((value, i) => <td key={i} className="p-2">{value}</td>)}</tr>)}</tbody></table><p className="mt-3 text-[10px] text-slate-400">来源：{record.data.source}</p></> : record.data.imageId ? <>
              <div className="my-3 flex items-center gap-2 text-xs"><button aria-label="缩小 Wafer 图片" type="button" onClick={() => setZoom(value => Math.max(.5, value - .25))}>−</button><span>{Math.round(zoom * 100)}%</span><button aria-label="放大 Wafer 图片" type="button" onClick={() => setZoom(value => Math.min(3, value + .25))}>＋</button><button type="button" onClick={() => setZoom(1)}>适配</button></div>
              <div className="max-h-[460px] overflow-auto rounded border border-slate-200 bg-slate-50"><WaferPreview data={record.data} zoom={zoom} /></div><p className="mt-2 text-[10px] text-slate-400">蓝色 BIN 1／橙色 BIN 7（示意） · 图片标识 {record.data.imageId} · 来源：Wafer 图库（模拟）</p>
            </> : <p className="mt-4 rounded border border-dashed border-slate-200 p-5 text-xs text-slate-500">未查询到 Wafer 图片，表单仍可查看，不代表无异常。</p>}
          </>}
          <button type="button" disabled={record.status === "loading"} onClick={() => query.query(true, record.chipId)} className="mt-5 h-8 rounded border border-slate-200 px-3 text-xs text-[#0052D9] disabled:opacity-40">{record.status === "error" ? "重试该物料" : "刷新该物料"}</button>
        </div>}
      </DialogContent>
    </Sheet>
  </>;
}

export function MaterialQueryNotice({ query }: { query: MaterialQueryController }) {
  return query.notice && <div role="status" className="fixed bottom-6 left-1/2 z-[140] flex -translate-x-1/2 items-center gap-4 rounded-lg border border-slate-200 bg-white px-4 py-3 text-xs shadow-lg"><span>物料数据查询已结束</span><button type="button" onClick={() => query.locate()} className="text-[#0052D9]">查看结果</button><button type="button" onClick={query.dismissNotice} className="text-slate-400" aria-label="关闭查询提醒">关闭</button></div>;
}
