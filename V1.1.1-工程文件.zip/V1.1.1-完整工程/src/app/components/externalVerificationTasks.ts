import type { TaskNode } from "./data";
import type { WaitingTask } from "./waitingTasks";
import { isExternalVerification } from "./externalVerification";

export function executionTasks(nodes: TaskNode[]): TaskNode[] {
  return nodes.flatMap(node => [...(node.code ? [node] : []), ...executionTasks(node.children ?? [])]);
}

export function externalVerificationTask(parent: TaskNode, wait: WaitingTask, directory: Record<string, string>): TaskNode {
  const status = wait.status === "待开始" ? "待接受" : wait.status;
  return {
    id: `external-task:${parent.id}:${wait.id}`,
    code: `${parent.code}.V-${wait.id}`,
    title: wait.title, expectation: wait.description, type: "验证",
    externalVerification: { sourceId: wait.id, parentTaskId: parent.id },
    owner: wait.owner, supervisor: wait.assignedBy,
    department: directory[wait.owner] || wait.department || "未记录部门",
    urgency: wait.urgency ?? parent.urgency, status, progress: status === "已完成" ? 100 : 0,
    createdAt: wait.createdAt, dueDate: wait.dueDate, attachments: wait.attachments,
    voiceNote: wait.voiceNote, note: wait.note,
    conclusion: status === "已完成" ? wait.result : undefined,
    terminateReason: status === "已中止" ? wait.result : undefined,
    statusHistory: [
      { status: "待接受", at: wait.createdAt, by: wait.assignedBy },
      ...(!wait.cancelledBeforeStart && wait.status !== "待开始"
        ? [{ status: "进行中" as const, at: wait.startedAt ?? wait.createdAt, by: wait.owner }] : []),
      ...(wait.endedAt ? [{ status, at: wait.endedAt, by: wait.endedBy ?? wait.owner }] : []),
    ],
  };
}

// 旧记录原样留档；稳定 ID 防止刷新重复导入，已导入任务的独立修改优先。
export function materializeExternalVerificationTasks(nodes: TaskNode[], directory: Record<string, string>): TaskNode[] {
  return nodes.map(parent => {
    let children = parent.children ? materializeExternalVerificationTasks(parent.children, directory) : undefined;
    const stored = parent.waitingTasks ?? [];
    const legacy: WaitingTask[] = (parent.waitingFeedbackPeriods ?? [])
      .filter(period => isExternalVerification(period) && !(period.id && stored.some(wait => wait.legacyPeriodId === period.id)))
      .map((period, index) => ({
        id: `legacy-period:${period.id ?? index}`, parentTaskId: parent.id, title: period.description || "外部客户验证",
        reason: "外部验证", verificationKind: "external", description: period.description || "历史外部验证记录",
        owner: parent.owner, assignedBy: period.startedBy, createdAt: period.startedAt, endedAt: period.endedAt,
        endedBy: period.endedBy, status: period.endedAt ? "已完成" : "进行中",
      }));
    const waits = parent.code ? [...stored.filter(isExternalVerification), ...legacy] : [];
    if (waits.length) {
      const thoughtId = parent.verificationNode?.thoughtId ?? `external-thought:${parent.id}`;
      const thought = children?.find(child => child.id === thoughtId);
      const existing = new Set((thought?.children ?? []).map(child => child.externalVerification?.sourceId));
      const added = waits.filter(wait => !existing.has(wait.id)).map(wait => externalVerificationTask(parent, wait, directory));
      const branch: TaskNode = {
        ...(thought ?? { id: thoughtId, title: parent.verificationNode?.title || "外部验证", owner: parent.owner, department: parent.department, urgency: parent.urgency, status: "待接受", progress: 0 }),
        category: "validation", children: [...(thought?.children ?? []), ...added],
      };
      children = [...(children ?? []).filter(child => child.id !== thoughtId), branch];
      return { ...parent, children, verificationNode: { id: parent.verificationNode?.id ?? thoughtId, createdAt: parent.verificationNode?.createdAt ?? waits[0].createdAt, thoughtId, title: branch.title } };
    }
    return { ...parent, ...(parent.externalVerification ? { department: directory[parent.owner] || parent.department || "未记录部门" } : {}), children };
  });
}
