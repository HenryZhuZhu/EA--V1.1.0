import { useRef, useState } from "react";
import { currentUser, ownerToDepartment } from "./data";
import { PersonInput } from "./PersonInput";
import { TaskDialog } from "./TaskDialog";
import { type WaitingTaskInput } from "./waitingTasks";

export function WaitFeedbackModal({ title, onClose, onConfirm }: {
  title: string; onClose: () => void; onConfirm: (input: WaitingTaskInput) => void;
}) {
  const [taskTitle, setTaskTitle] = useState("");
  const [description, setDescription] = useState("");
  const [owner, setOwner] = useState(currentUser.name);
  const [dueDate, setDueDate] = useState("");
  const [error, setError] = useState("");
  const submitting = useRef(false);
  const confirm = () => {
    if (submitting.current) return;
    if (!taskTitle.trim() || !description.trim() || !ownerToDepartment[owner]) { setError("请填写任务名称和预期，并从人员候选中选择任务负责人。"); return; }
    submitting.current = true;
    try { onConfirm({ reason: "验证", title: taskTitle, description, owner, dueDate: dueDate || undefined }); onClose(); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "等待任务保存失败，请重试。"); }
    finally { submitting.current = false; }
  };
  return <TaskDialog title="新增验证任务" description="外部验证为独立普通任务，日期选填，计入对接负责人所在部门，不暂停其他任务。" onClose={onClose} footer={<>
    <button onClick={onClose} className="h-9 rounded-md border border-slate-200 px-4 text-xs">取消</button>
    <button onClick={confirm} className="h-9 rounded-md bg-[#0052D9] px-4 text-xs text-white">创建验证任务</button>
  </>}>
    <div className="mb-4 rounded-lg bg-slate-50 p-3 text-sm">原任务：{title}</div>
    <div className="text-xs text-slate-600">任务类型 <span className="ml-2 rounded border border-slate-200 bg-slate-100 px-2 py-1">验证</span></div>
    <label className="mt-4 block text-xs text-slate-600">任务名称<input aria-label="验证任务名称" value={taskTitle} onChange={event => setTaskTitle(event.target.value)} maxLength={120} className="mt-2 h-9 w-full rounded border border-slate-200 px-3" /></label>
    <div className="mt-4"><label htmlFor="waiting-task-owner" className="mb-2 block text-xs text-slate-600">任务负责人</label><PersonInput id="waiting-task-owner" value={owner} onChange={setOwner} placeholder="搜索姓名或部门" /></div>
    <label className="mt-4 block text-xs text-slate-600">预计完成日期（可选）<input type="date" value={dueDate} onChange={event => setDueDate(event.target.value)} className="mt-2 h-9 w-full rounded-md border border-slate-200 px-3" /></label>
    <label className="mt-4 block text-xs text-slate-600">预期<textarea aria-label="验证任务预期" value={description} onChange={event => setDescription(event.target.value)} maxLength={500} className="mt-2 min-h-24 w-full rounded-md border border-slate-200 p-3" /></label>
    {error && <p role="alert" className="mt-3 text-xs text-red-600">{error}</p>}
  </TaskDialog>;
}
