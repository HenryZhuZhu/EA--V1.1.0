import { readFileSync, writeFileSync, readdirSync, cpSync, rmSync } from 'node:fs';
import { relative, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { zipSync, unzipSync } from 'fflate';

const root = fileURLToPath(new URL('../', import.meta.url));
const archive = 'V1.1.1-工程文件.zip';
// web is exclusively generated from dist; remove stale hashed assets before publishing.
rmSync(join(root, 'web'), { recursive: true, force: true });
cpSync(join(root, 'dist'), join(root, 'web'), { recursive: true });
const skip = new Set(['node_modules', 'dist', 'test-results', 'playwright-report', '.git', '.DS_Store', '.claude', 'V1.0.9.html', 'V1.1.0.html', 'EA系统-离线版.html']);
const entries = {};
function collect(directory) {
  for (const item of readdirSync(directory, { withFileTypes: true })) {
    if (skip.has(item.name) || item.name === '.env' || item.name.startsWith('.env.') || /\.(zip|sha256|log|tsbuildinfo)$/.test(item.name)) continue;
    const full = join(directory, item.name);
    if (item.isDirectory()) collect(full);
    else if (item.isSymbolicLink()) throw new Error(`Unexpected symlink in package: ${full}`);
    else if (item.isFile()) entries[`V1.1.1-完整工程/${relative(root, full).split('\\').join('/')}`] = new Uint8Array(readFileSync(full));
  }
}
collect(root);
const bytes = zipSync(entries, { level: 6 });
const restored = unzipSync(bytes);
for (const [name, data] of Object.entries(entries)) if (!Buffer.from(data).equals(Buffer.from(restored[name]))) throw new Error(`ZIP mismatch: ${name}`);
writeFileSync(join(root, archive), bytes);
const hash = createHash('sha256').update(bytes).digest('hex');
writeFileSync(join(root, `${archive}.sha256`), `${hash}  ${archive}\n`);
console.log(`${archive}: ${Object.keys(entries).length} files, ${(bytes.length / 1048576).toFixed(2)} MiB; restored contents verified.`);
console.log(`SHA-256: ${hash}`);