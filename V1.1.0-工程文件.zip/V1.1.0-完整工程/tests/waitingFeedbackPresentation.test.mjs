import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import test from "node:test";

const source = (name) => readFileSync(fileURLToPath(new URL(`../src/app/components/${name}`, import.meta.url)), "utf8");

test("waiting feedback uses a required reason and description modal in both task flows", () => {
  const data = source("data.ts");
  const modal = source("WaitFeedbackModal.tsx");
  const caseDetail = source("TaskDetail.tsx");
  const standaloneResult = source("StandaloneTaskResult.tsx");

  for (const reason of ["等待外部反馈", "等待内部验证", "等待借机"]) assert.ok(data.includes(`"${reason}"`));
  assert.match(modal, /WAITING_FEEDBACK_REASONS\.map/);
  assert.match(modal, /等待描述/);
  assert.match(modal, /maxLength=\{500\}/);
  assert.match(modal, /disabled=\{!reason \|\| !description\.trim\(\)\}/);
  assert.match(caseDetail, /onWait=\{\(\) => setWaitingForFeedback\(true\)\}/);
  assert.match(caseDetail, /updateCaseTask\(caseId, selected\.id, patch, waitingFeedback\)/);
  assert.match(standaloneResult, /updateStandaloneTaskStatus\(task\.id, "等待反馈", undefined, input\)/);
  assert.doesNotMatch(standaloneResult, /onWait=\{\(\) => updateStandaloneTaskStatus/);
});