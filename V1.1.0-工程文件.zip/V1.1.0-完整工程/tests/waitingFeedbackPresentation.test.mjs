import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

const source = name => readFileSync(new URL(`../src/app/components/${name}`, import.meta.url), "utf8");
test("special tasks are created in verification mind-map nodes, not task detail panels", () => {
  const modal = source("WaitFeedbackModal.tsx");
  assert.match(modal, /title="新增特殊任务"/);
  assert.match(modal, /WAIT_TASK_REASONS\.map/);
  assert.match(modal, /等待说明/);
  assert.match(modal, /maxLength=\{500\}/);
  assert.match(modal, /!description\.trim\(\) \|\| !ownerToDepartment\[owner\]/);
  for (const file of ["TaskDetail.tsx", "StandaloneTaskResult.tsx"]) {
    assert.doesNotMatch(source(file), /<WaitFeedbackModal|<WaitingTaskPanel|setWaitingForFeedback/);
  }
  assert.doesNotMatch(source("TaskDetailActions.tsx"), /新建等待任务/);
  assert.match(source("MindMapFlow.tsx"), /verificationMindMap\(filtered\)/);
  assert.match(source("MindMapFlow.tsx"), /createCaseVerificationNode/);
  assert.match(source("MindMapFlow.tsx"), /<WaitFeedbackModal/);
});
