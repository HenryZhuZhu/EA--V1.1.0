import test from "node:test";
import assert from "node:assert/strict";
import vm from "node:vm";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";
const { outputFiles } = await build({
  entryPoints: [fileURLToPath(new URL("../src/app/components/verificationMindMap.ts", import.meta.url))],
  bundle: true, write: false, platform: "node", format: "cjs",
});
const context = { module: { exports: {} } };
vm.runInNewContext(outputFiles[0].text, context);
const { verificationMindMap } = context.module.exports;
const parent = {
  id: "p", code: "EA-001.001", title: "原任务", owner: "张伟", department: "PTE",
  status: "进行中", urgency: "一般", progress: 0,
};
test("empty verification branch appears as an explicit child without blocking or changing ordinary tasks", () => {
  const source = [{ ...parent, verificationNode: { id: "v", createdAt: "2026-10-25" } }];
  const before = JSON.stringify(source);
  const projected = verificationMindMap(source);
  assert.equal(projected.tasks[0].children.length, 1);
  assert.equal(projected.tasks[0].children[0].title, "验证");
  assert.equal(projected.tasks[0].children[0].children.length, 0);
  assert.equal(projected.displayNodes.get(projected.tasks[0].children[0].id).kind, "verification");
  assert.equal(source[0].waitingTasks, undefined);
  assert.equal(JSON.stringify(source), before);
});
test("legacy waiting records project into verification branch, special tasks are leaves with no ordinary child nodes", () => {
  const source = [{ ...parent, children: [{ id: "thought", title: "普通思路", children: [] }], waitingTasks: [
    { id: "a", title: "等待外部反馈", owner: "李娜", status: "进行中" },
    { id: "b", title: "等待借机", owner: "张伟", status: "已完成" },
  ] }];
  const graph = verificationMindMap(source);
  assert.equal(graph.tasks[0].children[0].id, "thought");
  const verification = graph.tasks[0].children[1];
  assert.equal(verification.children.length, 2);
  for (const leaf of verification.children) {
    assert.equal(leaf.children, undefined);
    assert.equal(graph.displayNodes.get(leaf.id).kind, "specialTask");
    assert.equal(graph.displayNodes.get(leaf.id).parent.id, "p");
  }
  assert.equal(source[0].children.length, 1);
});
