import assert from "node:assert/strict";
import { chromium, expect } from "@playwright/test";
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1600, height: 1100 } });
const errors = [];
page.on("pageerror", error => errors.push(error.message));
try {
  await page.addInitScript(() => {
    if (sessionStorage.getItem("bounds-seeded")) return;
    localStorage.setItem("ea_case_task_trees_v1", JSON.stringify({ c001: [{
      id: "t1b", code: "EA-260511000001.002", title: "旧日期用户编辑",
      owner: "张伟", department: "PTE", urgency: "一般", status: "进行中",
      createdAt: "2026-04-22T09:00:00+08:00",
    }] }));
    sessionStorage.setItem("bounds-seeded", "1");
  });
  await page.goto(new URL("../V1.1.0.html", import.meta.url).href);
  for (let i = 0; i < 16; i++) {
    const next = page.getByRole("button", { name: /^(下一步|下一页|开始使用|开始体验|进入系统|知道了)$/ }).last();
    if (!await next.isVisible()) break;
    await next.click(); await page.waitForTimeout(100);
  }
  await page.getByText("万能看板", { exact: true }).first().click();
  await page.getByRole("complementary", { name: "部门组织树" }).getByRole("button", { name: "PTE", exact: true }).click();
  const expand = page.getByRole("button", { name: "展开 EA-260511000001", exact: true });
  const card = expand.locator("xpath=ancestor::div[contains(@class,'shadow-')][1]");
  const value = async label => {
    const text = await card.getByText(new RegExp(`^${label} ·`)).innerText();
    const match = text.match(/([\d.]+) (天|小时)/);
    return Number(match[1]) * (match[2] === "天" ? 24 : 1);
  };
  assert.ok(await value("本部门总 Cycle Time") <= await value("Case 总 Cycle Time"));
  await expand.click();
  const row = card.locator('[data-gantt-row="t1b"]');
  await expect(row.getByText("时间记录需核对", { exact: true })).toBeVisible();
  const bar = row.locator("[data-gantt-bar]");
  const start = await bar.getAttribute("data-start");
  assert.equal(start, "2026-09-15T00:00:00.000Z");
  const stored = await page.evaluate(() => JSON.parse(localStorage.getItem("ea_case_task_trees_v1")).c001[0]);
  assert.equal(stored.createdAt, "2026-04-22T09:00:00+08:00");
  assert.equal(stored.title, "旧日期用户编辑");
  assert.deepEqual(errors, []);
  console.log("PASS old c001 cache cannot inflate department time; original events retained, bounded Gantt and warning shown");
} finally { await browser.close(); }
