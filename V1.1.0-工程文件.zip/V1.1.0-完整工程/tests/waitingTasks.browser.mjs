import assert from "node:assert/strict";
import { chromium, expect } from "@playwright/test";

const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({ viewport: { width: 1800, height: 1100 } });
const errors = [];
page.on("pageerror", error => errors.push(error.message));
const parent = async () => page.evaluate(() => JSON.parse(localStorage.getItem("ea_case_task_trees_v1")).c001.find(task => task.id === "t1b"));
async function dismissGuides() {
  for (let i = 0; i < 16; i++) {
    const next = page.getByRole("button", { name: /^(下一步|下一页|开始使用|开始体验|进入系统|知道了)$/ }).last();
    if (!await next.isVisible()) break;
    await next.click();
    await page.waitForTimeout(100);
  }
}
async function openTask() {
  await dismissGuides();
  await page.getByText("万能看板", { exact: true }).first().click();
  await page.getByRole("button", { name: "展开 EA-260511000001", exact: true }).click();
  await page.locator('[data-gantt-row="t1b"] button').first().click();
}
try {
  await page.addInitScript(() => {
    if (sessionStorage.getItem("waiting-test-seed")) return;
    const base = { owner: "张伟", supervisor: "刘洋", department: "PTE", urgency: "紧急", createdAt: "2026-09-22T09:00:00+08:00", dueDate: "2026-10-30", conclusion: "验证结论" };
    localStorage.setItem("ea_case_task_trees_v1", JSON.stringify({ c001: [
      { ...base, id: "t1b", code: "EA-260511000001.002", title: "验证分支流程测试", status: "进行中" },
      { ...base, id: "t2", code: "EA-260511000001.004", title: "旧等待迁移验证", status: "等待反馈", waitingFeedbackPeriods: [
        { id: "legacy-open", reason: "等待内部验证", description: "旧记录保留", startedBy: "张伟", startedAt: "2026-10-24T10:00:00+08:00" },
      ] },
    ] }));
    sessionStorage.setItem("waiting-test-seed", "1");
  });
  await page.goto(process.env.EA_PREVIEW_URL || new URL("../V1.1.0.html", import.meta.url).href);
  await openTask();
  await expect(page.getByRole("region", { name: "等待任务", exact: true })).toHaveCount(0);
  await expect(page.getByRole("button", { name: "新建等待任务", exact: true })).toHaveCount(0);
  await page.getByRole("button", { name: "查看 Case 全貌 →", exact: true }).click();
  await dismissGuides();
  const original = page.locator('.react-flow__node[data-id="t1b"]');
  await original.getByRole("button", { name: "添加验证节点", exact: true }).click();
  const verification = page.locator('.react-flow__node[data-id="verification-view:t1b"]');
  await expect(verification).toBeVisible();
  assert.ok((await parent()).verificationNode);
  assert.equal((await parent()).waitingTasks?.length ?? 0, 0);
  for (const reason of ["等待外部反馈", "等待借机"]) {
    await verification.getByRole("button", { name: "新增特殊任务", exact: true }).click();
    const dialog = page.getByRole("dialog");
    await expect(dialog.getByRole("button", { name: "其他等待事项", exact: true })).toHaveCount(0);
    await dialog.getByRole("button", { name: reason, exact: true }).click();
    await dialog.getByLabel("等待说明").fill(`${reason}测试说明`);
    await dialog.getByRole("button", { name: "创建特殊任务", exact: true }).click();
  }
  await expect(original.getByText("计时暂停 · 2 个特殊任务未结束", { exact: true })).toBeVisible();
  const saved = await parent();
  assert.equal(saved.status, "进行中");
  assert.equal(saved.waitingTasks.length, 2);
  for (const task of saved.waitingTasks) {
    const node = page.locator(`.react-flow__node[data-id="special-view:t1b:${task.id}"]`);
    await expect(node).toBeVisible();
    await expect(node.locator(".react-flow__handle.source")).toHaveCount(0);
    await expect(node.getByRole("button", { name: /新增|思路|验证/ })).toHaveCount(0);
    const edgeId = `verification-view:t1b-special-view:t1b:${task.id}`;
    await expect(page.locator(`.react-flow__edge[data-id="${edgeId}"]`)).toHaveCount(1);
  }
  if (process.env.EA_SCREENSHOT) {
    await page.mouse.move(240, 50);
    await page.waitForTimeout(1000);
    await page.screenshot({ path: process.env.EA_SCREENSHOT, fullPage: true });
  }
  assert.equal(await page.evaluate(() => JSON.parse(localStorage.getItem("ea_case_task_trees_v1")).c001.length), 2);
  const first = page.locator(`.react-flow__node[data-id="special-view:t1b:${saved.waitingTasks[0].id}"]`);
  await first.getByRole("button", { name: "完成", exact: true }).click();
  await page.getByRole("dialog").getByLabel("特殊任务结果或取消原因").fill("反馈已确认");
  await page.getByRole("dialog").getByRole("button", { name: "确认", exact: true }).click();
  await expect(original.getByText("计时暂停 · 1 个特殊任务未结束", { exact: true })).toBeVisible();
  const second = page.locator(`.react-flow__node[data-id="special-view:t1b:${saved.waitingTasks[1].id}"]`);
  await second.getByRole("button", { name: "取消", exact: true }).click();
  await page.getByRole("dialog").getByLabel("特殊任务结果或取消原因").fill("改用备用机台");
  await page.getByRole("dialog").getByRole("button", { name: "确认", exact: true }).click();
  await expect(original.getByText(/计时暂停/)).toHaveCount(0);
  assert.deepEqual((await parent()).waitingTasks.map(task => task.status), ["已完成", "已中止"]);
  await page.reload();
  await openTask();
  await page.getByRole("button", { name: "查看 Case 全貌 →", exact: true }).click();
  await dismissGuides();
  await expect(verification).toBeVisible();
  assert.equal((await parent()).waitingTasks.length, 2);
  assert.deepEqual(errors, []);
  console.log("PASS task → verification → special task graph, three allowed types, leaf constraints, no detail controls, complete/cancel and persistence");
} catch (error) {
  console.error("Runtime errors:", errors);
  console.error("Mind map nodes:", await page.locator(".react-flow__node").allTextContents());
  console.error("Page tail:", (await page.locator("body").innerText()).slice(-2200));
  throw error;
} finally { await browser.close(); }
