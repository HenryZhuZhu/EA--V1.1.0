import assert from "node:assert/strict";
import test from "node:test";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import { build } from "esbuild";

const require = createRequire(import.meta.url);
const { outputFiles } = await build({
  entryPoints: [fileURLToPath(new URL("../src/app/components/data.ts", import.meta.url))],
  bundle: true, write: false, platform: "node", format: "cjs", packages: "external",
});
const module = { exports: {} };
new Function("module", "exports", "require", outputFiles[0].text)(module, module.exports, require);
const { mockCases, flattenTasks } = module.exports;

test("all demo Cases and executable tasks have September 2026 creation dates in chronological order", () => {
  const september = (value, id) => {
    assert.ok(value, `${id}: missing creation date`);
    const date = new Date(value);
    assert.equal(date.getFullYear(), 2026, id);
    assert.equal(date.getMonth(), 8, id);
    return date.getTime();
  };
  assert.ok(mockCases.length > 0);
  for (const item of mockCases) {
    const created = september(item.createdAt, item.id);
    assert.ok(Date.parse(item.updatedAt) >= created, `${item.id}: update before creation`);
    for (const { task } of flattenTasks(item.tasks).filter(({ task }) => task.code)) {
      assert.ok(september(task.createdAt, task.id) >= created, `${task.id}: task before Case`);
    }
  }
});
