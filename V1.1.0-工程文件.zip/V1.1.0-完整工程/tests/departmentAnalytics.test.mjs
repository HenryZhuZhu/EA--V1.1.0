import assert from "node:assert/strict";
import test from "node:test";
import vm from "node:vm";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";

const { outputFiles } = await build({
  entryPoints: [fileURLToPath(new URL("../src/app/components/departmentAnalytics.ts", import.meta.url))],
  bundle: true, write: false, platform: "node", format: "cjs",
});
const box = { module: { exports: {} } };
vm.runInNewContext(outputFiles[0].text, box);
const { departmentTreeFor, departmentScope, departmentPath, summarizeDepartment, departmentCaseRecord, taskDepartmentId } = box.module.exports;
const plain = value => JSON.parse(JSON.stringify(value));
const tree = departmentTreeFor(["PTE", "新部门"]);

test("recursive department scope, breadcrumb and unknown department support", () => {
  assert.deepEqual([...departmentScope(tree, "PTE", false)], ["PTE"]);
  assert.deepEqual([...departmentScope(tree, "PTE", true)], ["PTE", "pte-product", "pte-ddr", "pte-lpddr", "pte-dev"]);
  assert.deepEqual(plain(departmentPath(tree, "pte-ddr").map(node => node.name)), ["测试中心", "PTE", "产品测试组", "DDR 测试小组"]);
  assert.ok(departmentScope(tree, "__other", true).has("新部门"));
  assert.equal(taskDepartmentId("c001", { id: "t1", department: "PTE" }), "pte-ddr");
  assert.equal(taskDepartmentId("c001", { id: "t1", department: "QA" }), "QA");
  assert.equal(taskDepartmentId("new", { id: "t1", department: "PTE" }), "PTE");
});

test("parent merges overlapping child intervals per Case and never averages child aggregates", () => {
  const records = [
    { caseItem: { id: "a" }, tasks: [
      { departmentId: "pte-ddr", intervals: [{ start: 0, end: 10 }] },
      { departmentId: "pte-dev", intervals: [{ start: 5, end: 15 }] },
    ] },
    { caseItem: { id: "b" }, tasks: [{ departmentId: "pte-ddr", intervals: [{ start: 0, end: 5 }] }] },
    { caseItem: { id: "c" }, tasks: [{ departmentId: "PTE", intervals: [{ start: 0, end: 40 }] }] },
  ];
  const parent = summarizeDepartment([...records, records[0]], departmentScope(tree, "PTE", true));
  assert.equal(parent.count, 3);
  assert.equal(parent.average, 20);
  assert.equal(parent.median, 15);
  const direct = summarizeDepartment(records, departmentScope(tree, "PTE", false));
  assert.equal(direct.count, 1);
  assert.equal(direct.average, 40);
});

test("unknown timing counts the Case but is not a zero-duration statistical sample", () => {
  const result = summarizeDepartment([{ caseItem: { id: "unknown" }, tasks: [{ departmentId: "PTE", intervals: null }] }], new Set(["PTE"]));
  assert.equal(result.count, 1);
  assert.equal(result.sampleCount, 0);
  assert.equal(result.average, null);
  assert.equal(result.median, null);
});

test("task-specific external waits cannot subtract another department's active work", () => {
  const start = "2026-09-01T00:00:00Z", end = "2026-09-01T10:00:00Z";
  const base = { createdAt: start, status: "已完成", statusHistory: [{ status: "已完成", at: end }] };
  const record = departmentCaseRecord({ id: "new" }, [
    { ...base, id: "a", code: "a", department: "PTE", waitingFeedbackPeriods: [{ reason: "等待外部反馈", startedAt: start, endedAt: end }] },
    { ...base, id: "b", code: "b", department: "FT" },
  ], undefined, Date.parse(end));
  assert.equal(summarizeDepartment([record], new Set(["PTE"])).average, 0);
  assert.equal(summarizeDepartment([record], new Set(["FT"])).average, 10 * 3600000);
  assert.equal(summarizeDepartment([record], new Set(["PTE", "FT"])).average, 10 * 3600000);
});
