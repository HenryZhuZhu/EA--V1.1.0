import assert from "node:assert/strict";
import test from "node:test";
import vm from "node:vm";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";

const { outputFiles } = await build({
  entryPoints: [fileURLToPath(new URL("../src/app/components/departmentAnalytics.ts", import.meta.url))],
  bundle: true, write: false, platform: "node", format: "cjs",
});
const box = { module: { exports: {} } };
vm.runInNewContext(outputFiles[0].text, box);
const { departmentTreeFor, departmentScope, departmentPath, summarizeDepartment, departmentCaseRecord, taskDepartmentId, caseCycleMetrics } = box.module.exports;
const plain = value => JSON.parse(JSON.stringify(value));
const tree = departmentTreeFor(["PTE", "新部门"]);

test("recursive department scope, breadcrumb and unknown department support", () => {
  assert.deepEqual([...departmentScope(tree, "PTE", false)], ["PTE"]);
  assert.deepEqual([...departmentScope(tree, "PTE", true)], ["PTE", "pte-product", "pte-ddr", "pte-lpddr", "pte-dev"]);
  assert.deepEqual(plain(departmentPath(tree, "pte-ddr").map(node => node.name)), ["测试中心", "PTE", "产品测试组", "DDR 测试小组"]);
  assert.ok(departmentScope(tree, "__other", true).has("新部门"));
  assert.equal(taskDepartmentId("c001", { id: "t1", department: "PTE" }), "pte-ddr");
  assert.equal(taskDepartmentId("c001", { id: "t1", department: "QA" }), "QA");
  assert.equal(taskDepartmentId("new", { id: "t1", department: "PTE" }), "PTE");
});

test("parent merges overlapping child intervals per Case and never averages child aggregates", () => {
  const records = [
    { caseItem: { id: "a" }, tasks: [
      { departmentId: "pte-ddr", intervals: [{ start: 0, end: 10 }] },
      { departmentId: "pte-dev", intervals: [{ start: 5, end: 15 }] },
    ] },
    { caseItem: { id: "b" }, tasks: [{ departmentId: "pte-ddr", intervals: [{ start: 0, end: 5 }] }] },
    { caseItem: { id: "c" }, tasks: [{ departmentId: "PTE", intervals: [{ start: 0, end: 40 }] }] },
  ];
  const parent = summarizeDepartment([...records, records[0]], departmentScope(tree, "PTE", true));
  assert.equal(parent.count, 3);
  assert.equal(parent.average, 20);
  assert.equal(parent.median, 15);
  const direct = summarizeDepartment(records, departmentScope(tree, "PTE", false));
  assert.equal(direct.count, 1);
  assert.equal(direct.average, 40);
});

test("unknown timing counts the Case but is not a zero-duration statistical sample", () => {
  const result = summarizeDepartment([{ caseItem: { id: "unknown" }, tasks: [{ departmentId: "PTE", intervals: null }] }], new Set(["PTE"]));
  assert.equal(result.count, 1);
  assert.equal(result.sampleCount, 0);
  assert.equal(result.average, null);
  assert.equal(result.median, null);
});

test("task-specific external waits cannot subtract another department's active work", () => {
  const start = "2026-09-01T00:00:00Z", end = "2026-09-01T10:00:00Z";
  const base = { owner: "工程师", createdAt: start, status: "已完成", statusHistory: [{ status: "已完成", at: end }] };
  const record = departmentCaseRecord({ id: "new", status: "进行中", createdAt: start }, [
    { ...base, id: "a", code: "a", department: "PTE", waitingFeedbackPeriods: [{ reason: "等待外部反馈", startedAt: start, endedAt: end }] },
    { ...base, id: "b", code: "b", department: "FT" },
  ], undefined, Date.parse(end));
  assert.equal(summarizeDepartment([record], new Set(["PTE"])).average, 0);
  assert.equal(summarizeDepartment([record], new Set(["FT"])).average, 10 * 3600000);
  assert.equal(summarizeDepartment([record], new Set(["PTE", "FT"])).average, 10 * 3600000);
});

test("creator-only Case is related but contributes no processing sample; roles are matched within department", () => {
  const directory = { 张伟: "PTE", 李娜: "DA", 王芳: "CP" };
  const record = departmentCaseRecord({ id: "creator-only", owner: "李娜", createdBy: "张伟", participants: [{ name: "王芳", department: "CP" }] }, [], undefined, 0, directory);
  const pte = summarizeDepartment([record], new Set(["PTE"]), ["creator"]);
  assert.equal(pte.count, 1);
  assert.equal(pte.processingCount, 0);
  assert.equal(pte.average, null);
  assert.equal(pte.taskCount, 0);
  assert.equal(summarizeDepartment([record], new Set(["PTE"]), ["owner"]).count, 0);
  assert.equal(summarizeDepartment([record], new Set(["CP"]), ["collaborator"]).count, 1);
  assert.equal(summarizeDepartment([record], new Set(["PTE"]), []).count, 0);
});

test("task averages and Case averages use distinct denominators, with deduplication", () => {
  const start = "2026-09-01T00:00:00Z";
  const end = hour => `2026-09-01T${String(hour).padStart(2, "0")}:00:00Z`;
  const task = (id, hours) => ({ id, code: id, owner: "张伟", department: "PTE", createdAt: start, status: "已完成", statusHistory: [{ status: "已完成", at: end(hours) }] });
  const a = departmentCaseRecord({ id: "a", status: "进行中", createdAt: start }, [task("a1", 10), task("a2", 4)]);
  const b = departmentCaseRecord({ id: "b", status: "进行中", createdAt: start }, [task("b1", 2)]);
  const result = summarizeDepartment([a, b, a], new Set(["PTE"]));
  assert.equal(result.count, 2);
  assert.equal(result.average, 6 * 3600000);
  assert.equal(result.taskCount, 3);
  assert.equal(result.taskAverage, 16 / 3 * 3600000);
  assert.equal(result.taskMedian, 4 * 3600000);
});

test("Case effective cycle only subtracts explicit Case verification and unions history; never task waits", () => {
  const start = "2026-09-01T00:00:00Z", end = "2026-09-01T10:00:00Z";
  const item = { status: "已结案", createdAt: start, tasks: [{ waitingTasks: [{ createdAt: start, endedAt: end }] }] };
  const closure = { state: "closed", closedAt: end, verificationStartedAt: "2026-09-01T06:00:00Z", verificationEndedAt: end,
    verificationHistory: [{ startedAt: "2026-09-01T04:00:00Z", at: "2026-09-01T08:00:00Z" }] };
  const result = caseCycleMetrics(item, closure, Date.parse(end));
  assert.equal(result.total, 10 * 3600000);
  assert.equal(result.effective, 4 * 3600000);
  assert.equal(result.excluded, 6 * 3600000);
  assert.equal(caseCycleMetrics(item, { state: "closed", closedAt: end }).effective, 10 * 3600000);
  assert.equal(caseCycleMetrics(item).effective, null);
  assert.equal(caseCycleMetrics({ ...item, status: "进行中" }, undefined, Date.parse(end)).effective, 10 * 3600000);
});
test("department total/effective unions exclude gaps and count parallel work during another task's wait", () => {
  const at = hour => new Date(Date.UTC(2026, 8, 1, hour)).toISOString();
  const task = (id, start, end, waits = []) => ({
    id, code: id, owner: "张伟", department: "PTE", createdAt: at(start), status: "已完成",
    statusHistory: [{ status: "已完成", at: at(end) }], waitingTasks: waits,
  });
  const record = departmentCaseRecord({ id: "sample", status: "进行中", createdAt: at(0) }, [
    task("a", 0, 10, [{ createdAt: at(2), endedAt: at(8) }, { createdAt: at(3), endedAt: at(5) }]),
    task("b", 4, 6),
    task("c", 20, 22),
  ]);
  const result = summarizeDepartment([record, record], new Set(["PTE"]));
  assert.equal(result.count, 1);
  assert.equal(result.taskCount, 3);
  assert.equal(result.totalAverage, 12 * 3600000);
  assert.equal(result.totalMedian, 12 * 3600000);
  assert.equal(result.average, 8 * 3600000);
  assert.equal(result.median, 8 * 3600000);
  assert.equal(result.taskAverage, 8 / 3 * 3600000);
  const relatedOnly = summarizeDepartment([{ caseItem: { id: "only" }, relations: [{ role: "creator", name: "张伟", departmentId: "PTE" }], tasks: [] }], new Set(["PTE"]));
  assert.equal(relatedOnly.totalAverage, null);
  assert.equal(relatedOnly.average, null);
});
