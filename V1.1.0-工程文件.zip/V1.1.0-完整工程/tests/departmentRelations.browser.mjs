import assert from "node:assert/strict";
import { chromium, expect } from "@playwright/test";
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1600, height: 1100 } });
const errors = [];
page.on("pageerror", error => errors.push(error.message));
try {
  await page.addInitScript(() => {
    localStorage.setItem("ea_case_task_trees_v1", JSON.stringify({ c001: [{
      id: "relation-test", code: "EA-260511000001.901", title: "QA 部门周期验证",
      owner: "质量工程师", department: "QA", status: "进行中", urgency: "一般",
      createdAt: "2026-09-20T09:00:00+08:00",
      waitingTasks: [{
        id: "verification-test", parentTaskId: "relation-test", title: "等待外部反馈",
        reason: "等待外部反馈", description: "仅阻塞原任务", owner: "张伟", assignedBy: "质量工程师",
        createdAt: "2026-10-01T09:00:00+08:00", status: "进行中",
      }, {
        id: "verification-completed", parentTaskId: "relation-test", title: "等待内部验证",
        reason: "等待内部验证", description: "已完成的验证", owner: "张伟", assignedBy: "质量工程师",
        createdAt: "2026-09-22T09:00:00+08:00", endedAt: "2026-09-24T09:00:00+08:00", status: "已完成",
      }, {
        id: "verification-cancelled", parentTaskId: "relation-test", title: "等待借机",
        reason: "等待借机", description: "已取消的验证", owner: "张伟", assignedBy: "质量工程师",
        createdAt: "2026-09-23T09:00:00+08:00", endedAt: "2026-09-25T09:00:00+08:00", status: "已中止",
      }],
    }] }));
  });
  await page.goto(process.env.EA_PREVIEW_URL || new URL("../V1.1.0.html", import.meta.url).href);
  for (let i = 0; i < 16; i++) {
    const next = page.getByRole("button", { name: /^(下一步|下一页|开始使用|开始体验|进入系统|知道了)$/ }).last();
    if (!await next.isVisible()) break;
    await next.click(); await page.waitForTimeout(100);
  }
  await page.getByText("万能看板", { exact: true }).first().click();
  const tree = page.getByRole("complementary", { name: "部门组织树" });
  await tree.getByRole("button", { name: "PTE", exact: true }).click();
  const expand = page.getByRole("button", { name: "展开 EA-260511000001", exact: true });
  await expect(expand).toHaveCount(1);
  const card = expand.locator("xpath=ancestor::div[contains(@class,'shadow-')][1]");
  await expect(card.getByText("本部门普通任务 · 0", { exact: true })).toBeVisible();
  await expect(card.getByText("本部门有效 Cycle Time · —", { exact: true })).toBeVisible();
  await expect(card.getByText("本部门总 Cycle Time · —", { exact: true })).toBeVisible();
  await expect(card.getByText("Owner", { exact: true })).toBeVisible();
  await expand.click();
  await expect(card.getByText("暂无可展示的任务", { exact: true })).toBeVisible();
  await card.getByRole("button", { name: "全部任务", exact: true }).click();
  await expect(card.locator('[data-gantt-row="relation-test"]')).toHaveCount(1);
  await expect(card.locator('[data-gantt-verification="verification-test"]')).toBeVisible();
  await expect(card.locator('[data-gantt-verification="verification-test"]').getByText(/等待验证时长：/)).toBeVisible();
  await expect(card.locator("[data-gantt-verification]")).toHaveCount(3);
  await expect(card.locator('[data-gantt-verification="verification-completed"]').getByText("等待验证时长：2.0 天", { exact: true })).toBeVisible();
  await expect(card.locator('[data-gantt-verification="verification-cancelled"]').getByText("已取消", { exact: true })).toBeVisible();
  await expect(card.locator('[data-gantt-row="relation-test"]').getByText("8.0 天", { exact: true })).toHaveCount(1);
  await card.getByRole("button", { name: "周", exact: true }).click();
  await expect(card.locator("[data-gantt-verification]")).toHaveCount(3);
  await card.getByRole("button", { name: "当前部门任务", exact: true }).click();
  await expect(card.locator("[data-gantt-verification]")).toHaveCount(0);
  await page.getByRole("button", { name: "筛选", exact: true }).click();
  const filter = page.getByLabel("Cycle Time Case 筛选");
  for (const label of ["作为 Case Owner", "作为创建人", "作为协作者"]) await filter.getByLabel(label, { exact: true }).uncheck();
  await filter.getByRole("button", { name: "完成", exact: true }).click();
  await expect(expand).toHaveCount(0);
  await page.getByRole("button", { name: /^筛选/ }).click();
  await filter.getByRole("button", { name: "重置全部" }).click();
  await filter.getByRole("button", { name: "完成", exact: true }).click();
  await expect(expand).toHaveCount(1);
  await tree.getByRole("button", { name: "展开工艺与质量中心", exact: true }).click();
  await tree.getByRole("button", { name: "QA", exact: true }).click();
  await expect(card.getByText("本部门有效 Cycle Time · 8.0 天", { exact: true })).toBeVisible();
  await expect(page.getByRole("table", { name: "部门 Cycle Time 统计" }).locator("thead tr")).toHaveCount(1);
  await expect(page.getByRole("table", { name: "部门 Cycle Time 统计" }).getByRole("columnheader")).toHaveCount(10);
  await expect(page.getByRole("table", { name: "部门 Cycle Time 统计" }).getByRole("button")).toHaveCount(0);
  await page.getByRole("button", { name: /^普通任务明细/ }).click();
  const taskList = page.getByRole("region", { name: "普通任务列表", exact: true });
  const taskRow = taskList.locator('[data-department-task="relation-test"]');
  await expect(taskRow.getByRole("button", { name: "QA 部门周期验证", exact: true })).toBeVisible();
  await expect(taskRow.getByRole("button", { name: /EA-260511000001/ })).toBeVisible();
  await expect(taskRow).toContainText("QA · 质量工程师");
  await expect(taskRow.locator(".tabular-nums")).toHaveText("8.0 天");
  const header = taskList.getByText("任务 Cycle Time", { exact: true });
  const rightEdges = await Promise.all([header, taskRow.locator(".tabular-nums")].map(async locator => {
    const rect = await locator.boundingBox(); return rect.x + rect.width;
  }));
  assert.ok(Math.abs(rightEdges[0] - rightEdges[1]) < 1);
  await expect(page.getByText("QA 部门周期验证", { exact: true })).toBeVisible();
  await expect(page.getByText("计时暂停", { exact: true }).first()).toBeVisible();
  await page.getByRole("button", { name: /^验证等待明细/ }).click();
  await expect(page.getByRole("cell", { name: "等待外部反馈", exact: true })).toBeVisible();
  await page.getByRole("button", { name: /^Case 明细/ }).click();
  await expand.click();
  await expect(card.locator("[data-gantt-row]")).toHaveCount(1);
  await expect(card.locator("[data-gantt-verification]")).toHaveCount(3);
  if (process.env.EA_SCREENSHOT) await page.screenshot({ path: process.env.EA_SCREENSHOT, fullPage: true });
  await page.getByRole("button", { name: "已结案", exact: true }).click();
  await expect(expand).toHaveCount(0);
  await page.getByRole("button", { name: "未结案 · 累计", exact: true }).click();
  await expect(expand).toHaveCount(1);
  await page.getByRole("tab", { name: "产品视角", exact: true }).click();
  await expect(page.locator("#product-analysis-global-tools")).not.toBeEmpty();
  await expect(page.getByRole("button", { name: "展开 EA-260511000001", exact: true })).toHaveCount(0);
  await page.getByRole("button", { name: "展开 EA-260901000090", exact: true }).click();
  await expect(page.locator('[data-gantt-verification="cycle-wait"]')).toBeVisible();
  assert.deepEqual(errors, []);
  console.log("PASS department-specific roles, related-only Case has no attributed duration, task/wait details, lifecycle scope and product tab");
} finally { await browser.close(); }
