import assert from "node:assert/strict";
import { chromium, expect } from "@playwright/test";
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1600, height: 1100 } });
const errors = [];
page.on("pageerror", error => errors.push(error.message));
try {
  await page.goto(new URL("../V1.1.0.html", import.meta.url).href);
  for (let i = 0; i < 16; i++) {
    const next = page.getByRole("button", { name: /^(下一步|下一页|开始使用|开始体验|进入系统|知道了)$/ }).last();
    if (!await next.isVisible()) break;
    await next.click(); await page.waitForTimeout(100);
  }
  await page.getByText("万能看板", { exact: true }).first().click();
  await expect(page.getByRole("heading", { name: "部门分析", exact: true })).toBeVisible();
  await expect(page.getByRole("heading", { name: "部门周期分析", exact: true })).toHaveCount(0);
  await page.getByRole("complementary", { name: "部门组织树" }).getByRole("button", { name: "PTE", exact: true }).click();
  const expand = page.getByRole("button", { name: "展开 EA-260901000090", exact: true });
  const card = expand.locator("xpath=ancestor::div[contains(@class,'shadow-')][1]");
  await expect(card.getByText("Case 总 Cycle Time · 11.0 天", { exact: true })).toBeVisible();
  await expect(card.getByText("Case 有效 Cycle Time · 9.0 天", { exact: true })).toBeVisible();
  await expect(card.getByText("本部门总 Cycle Time · 5.0 天", { exact: true })).toBeVisible();
  await expect(card.getByText("本部门有效 Cycle Time · 5.0 天", { exact: true })).toBeVisible();
  await expand.click();
  await expect(card.locator('[data-gantt-cycle-time="cycle-a"]')).toHaveText("3.0 天");
  await expect(card.locator('[data-gantt-verification="cycle-wait"]')).toContainText("等待验证时长：2.0 天");
  await expect(card.locator("[data-gantt-row]")).toHaveCount(2);
  for (const [code, total, effective, deptTotal, deptEffective] of [
    ["EA-260901000091", 13, 11, 5, 3],
    ["EA-260905000092", 15, 13, 9, 6],
    ["EA-260902000093", 21, 19, 7, 5],
    ["EA-260906000094", 10, 8, null, null],
  ]) {
    const c = page.getByRole("button", { name: `展开 ${code}`, exact: true }).locator("xpath=ancestor::div[contains(@class,'shadow-')][1]");
    await expect(c.getByText(`Case 总 Cycle Time · ${total.toFixed(1)} 天`, { exact: true })).toBeVisible();
    await expect(c.getByText(`Case 有效 Cycle Time · ${effective.toFixed(1)} 天`, { exact: true })).toBeVisible();
    await expect(c.getByText(`本部门总 Cycle Time · ${deptTotal === null ? "—" : deptTotal.toFixed(1) + " 天"}`, { exact: true })).toBeVisible();
    await expect(c.getByText(`本部门有效 Cycle Time · ${deptEffective === null ? "—" : deptEffective.toFixed(1) + " 天"}`, { exact: true })).toBeVisible();
  }
  await page.getByRole("tab", { name: "产品视角", exact: true }).click();
  const average = page.getByText("Case 总 Cycle Time · 平均", { exact: true }).first().locator("..");
  await expect(average).toContainText("360.0h");
  await expect(page.getByText("已结案 Case", { exact: true }).locator("..")).toContainText("3");
  await expect(page.getByRole("button", { name: /^展开 EA-/ })).toHaveCount(3);
  await expect(expand).toBeVisible();
  await expand.click();
  await expect(card.locator("[data-gantt-row]")).toHaveCount(3);
  await expect(card.locator('[data-gantt-cycle-time="cycle-c"]')).toHaveText("4.0 天");
  assert.deepEqual(errors, []);
  console.log("PASS five diverse reference Cases; product three real closed Cases and 360h average");
} finally { await browser.close(); }
