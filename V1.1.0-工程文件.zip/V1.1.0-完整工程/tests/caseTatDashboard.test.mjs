import test from "node:test";
import assert from "node:assert/strict";
import { build } from "esbuild";
import vm from "node:vm";
import { fileURLToPath } from "node:url";

const { outputFiles } = await build({
  stdin: {
    contents: "export { mergeTatIntervals, subtractTatIntervals } from './caseTatMath'; export { medianCycleTime } from './departmentAnalytics';",
    resolveDir: fileURLToPath(new URL("../src/app/components/", import.meta.url)),
  },
  bundle: true,
  write: false,
  format: "cjs",
  platform: "node",
});
const box = { module: { exports: {} } };
vm.runInNewContext(outputFiles[0].text, box);
const { mergeTatIntervals, subtractTatIntervals, medianCycleTime } = box.module.exports;

test("department median handles odd/even samples, zeros and empty data without mutating inputs", () => {
  const values = [9, 1, 4, 2];
  assert.equal(medianCycleTime(values), 3);
  assert.deepEqual(values, [9, 1, 4, 2]);
  assert.equal(medianCycleTime([9, 1, 4]), 4);
  assert.equal(medianCycleTime([0, 8]), 4);
  assert.equal(medianCycleTime([7]), 7);
  assert.equal(medianCycleTime([]), 0);
});

test("Case TAT merges overlapping and adjacent task intervals without duplicate time", () => {
  const merged = mergeTatIntervals([
    { start: 0, end: 10 },
    { start: 5, end: 15 },
    { start: 15, end: 20 },
    { start: 30, end: 35 },
  ]);
  assert.equal(JSON.stringify(merged), JSON.stringify([{ start: 0, end: 20 }, { start: 30, end: 35 }]));
});

test("Case TAT subtracts customer verification and external-wait intervals", () => {
  const effective = subtractTatIntervals(
    [{ start: 0, end: 100 }],
    [{ start: 10, end: 20 }, { start: 15, end: 30 }, { start: 70, end: 90 }],
  );
  assert.equal(JSON.stringify(effective), JSON.stringify([{ start: 0, end: 10 }, { start: 30, end: 70 }, { start: 90, end: 100 }]));
  assert.equal(effective.reduce((sum, item) => sum + item.end - item.start, 0), 60);
});
