import assert from "node:assert/strict";
import test from "node:test";
import vm from "node:vm";
import { webcrypto } from "node:crypto";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";
const { outputFiles } = await build({ entryPoints: [fileURLToPath(new URL("../src/app/components/waitingTasks.ts", import.meta.url))], bundle: true, write: false, platform: "node", format: "cjs" });
const box = { module: { exports: {} }, crypto: webcrypto };
vm.runInNewContext(outputFiles[0].text, box);
const { applyWaitingTaskAction: act, migrateWaitingTasks: migrate, taskEffectiveCycleMs: cycle, isTaskWaiting, endWaitingTasksWithParent } = box.module.exports;
test("new special task types are restricted to three waiting categories", () => {
  assert.deepEqual(Array.from(box.module.exports.WAIT_TASK_REASONS), ["等待外部反馈", "等待内部验证", "等待借机"]);
  assert.throws(() => act({ id: "p", owner: "张伟", status: "进行中" }, { kind: "create", input: { reason: "其他等待事项", description: "invalid", owner: "张伟" } }, "张伟"), /请选择等待类型/);
});
test("verification elapsed time grows while open, stops on completion/cancellation and rejects missing end times", () => {
  const { waitingTaskTiming } = box.module.exports;
  const task = { createdAt: "2026-10-01T00:00:00Z", status: "进行中" };
  const now = Date.parse("2026-10-01T05:00:00Z");
  assert.equal(waitingTaskTiming(task, now).duration, 5 * 3600000);
  for (const status of ["已完成", "已中止"]) {
    assert.equal(waitingTaskTiming({ ...task, status, endedAt: "2026-10-01T02:00:00Z" }, now).duration, 2 * 3600000);
    assert.equal(waitingTaskTiming({ ...task, status }, now), null);
  }
  assert.equal(waitingTaskTiming({ ...task, createdAt: "invalid" }, now), null);
});
const at = hour => new Date(Date.UTC(2026, 9, 25, hour)).toISOString();
const ms = hour => Date.parse(at(hour));
const input = { reason: "等待外部反馈", description: "等待客户复测报告", owner: "李娜" };
const parent = { id: "task1", owner: "张伟", status: "进行中" };
test("waiting task creates independent assignment while keeping lifecycle unchanged and freezing clock", () => {
  const next = act(parent, { kind: "create", input }, "张伟", at(2));
  assert.equal(next.status, "进行中");
  assert.equal(next.waitingTasks[0].parentTaskId, "task1");
  assert.equal(next.waitingTasks[0].owner, "李娜");
  assert.equal(next.waitingTasks[0].assignedBy, "张伟");
  assert.equal(cycle(next, ms(0), ms(7)), 2 * 3600000);
  assert.equal(cycle(next, ms(0), ms(9)), 2 * 3600000);
  assert.equal(parent.waitingTasks, undefined);
});
test("parallel waits union once and resume only after all completed/cancelled", () => {
  let next = act(parent, { kind: "create", input }, "张伟", at(2));
  next = act(next, { kind: "create", input: { ...input, reason: "等待借机" } }, "张伟", at(3));
  next = act(next, { kind: "complete", id: next.waitingTasks[0].id, result: "报告已收到" }, "李娜", at(5));
  assert.ok(isTaskWaiting(next));
  assert.equal(cycle(next, ms(0), ms(7)), 2 * 3600000);
  next = act(next, { kind: "cancel", id: next.waitingTasks[1].id, result: "改用其他机台" }, "张伟", at(6));
  assert.equal(isTaskWaiting(next), false);
  assert.equal(cycle(next, ms(0), ms(8)), 4 * 3600000);
  assert.equal(next.waitingTasks[1].status, "已中止");
});
test("legacy open wait migrates idempotently from original time, ended intervals retained without double deduction", () => {
  const old = { ...parent, status: "等待反馈", waitingFeedbackPeriods: [
    { id: "old", startedAt: at(1), endedAt: at(2), startedBy: "张伟" },
    { id: "open", startedAt: at(3), startedBy: "张伟", reason: "等待内部验证" },
  ] };
  let next = migrate(old);
  assert.equal(next.status, "进行中");
  assert.equal(next.waitingTasks.length, 1);
  assert.equal(next.waitingTasks[0].createdAt, at(3));
  assert.equal(migrate(next), next);
  assert.equal(cycle(next, ms(0), ms(6)), 2 * 3600000);
  next = act(next, { kind: "complete", id: next.waitingTasks[0].id, result: "验证完成" }, "张伟", at(6));
  assert.equal(next.waitingFeedbackPeriods[1].endedAt, at(6));
  assert.equal(cycle(next, ms(0), ms(8)), 4 * 3600000);
});
test("ending parent closes blockers; later completion cannot reopen or modify parent", () => {
  const next = act(parent, { kind: "create", input }, "张伟", at(2));
  const ended = endWaitingTasksWithParent({ ...next, status: "已完成" }, "张伟", at(5));
  assert.equal(ended.waitingTasks[0].endedAt, at(5));
  assert.equal(ended.waitingTasks[0].status, "已中止");
  assert.equal(cycle(ended, ms(0), ms(5)), 2 * 3600000);
  assert.throws(() => act(ended, { kind: "complete", id: ended.waitingTasks[0].id, result: "晚到结果" }, "李娜", at(6)), /原任务已结束/);
});
test("invalid permissions, missing inputs, duplicate completion and reversed dates explicitly fail", () => {
  assert.throws(() => act(parent, { kind: "create", input }, "其他人", at(1)), /原任务负责人/);
  assert.throws(() => act(parent, { kind: "create", input: { ...input, description: "" } }, "张伟", at(1)), /填写说明/);
  let next = act(parent, { kind: "create", input }, "张伟", at(2));
  const done = { kind: "complete", id: next.waitingTasks[0].id, result: "完成" };
  assert.throws(() => act(next, done, "其他人", at(3)), /负责人/);
  assert.throws(() => act(next, done, "李娜", at(1)), /早于/);
  next = act(next, done, "李娜", at(3));
  assert.throws(() => act(next, done, "李娜", at(4)), /已结束/);
  assert.throws(() => migrate({ ...parent, status: "等待反馈" }), /开始时间缺失/);
});
