import assert from 'node:assert/strict';
import { build } from 'esbuild';
import vm from 'node:vm';
import { createRequire } from 'node:module';
import { webcrypto } from 'node:crypto';
import { chromium, expect } from '@playwright/test';

const { outputFiles } = await build({ stdin: { contents: "export * from './domainStore';export {mockCases,mockProducts} from './data';", resolveDir: new URL('../src/app/components/', import.meta.url).pathname }, bundle: true, write: false, platform: 'node', format: 'cjs', packages: 'external' });
const storage = new Map();
const box = { module: { exports: {} }, require: createRequire(import.meta.url), crypto: webcrypto, btoa, atob, localStorage: { getItem: key => storage.get(key) ?? null, setItem: (key, value) => storage.set(key, value) } };
vm.runInNewContext(outputFiles[0].text, box);
const api = box.module.exports;
const original = api.createManualCase({ name: '原始Case跨产品验证' + ' · 根因与解决方案复核'.repeat(8), owner: '张伟', createdBy: '张伟', level: 'L2', urgency: '一般', reason: '来源跳转验收', background: '保留原始背景', tasks: [] });
const children = api.createFanoutCasesFromClose({ sourceCaseId: original.id, productIds: api.mockProducts.slice(0, 2).map(product => product.id), conclusion: '可追溯的验证结论', by: '张伟' });
assert.equal(children.length, 2);
assert.ok(children.every(item => item.fanoutSourceCaseId === original.id));
const domain = JSON.parse(storage.get('ea_domain_v6'));
const missing = { ...children[0], id: 'v110-missing-source', code: 'V110-MISSING', name: '缺失来源验收', fanoutSourceCaseId: 'unavailable-case' };
const unknown = { ...missing, id: 'v110-unknown-source', code: 'V110-UNKNOWN', name: '未记录来源验收', fanoutSourceCaseId: undefined };
domain.spawnedCases.push(missing, unknown);
storage.set('ea_domain_v6', JSON.stringify(domain));
storage.set('ea_case_closures_v4', JSON.stringify({ [children[1].id]: { caseId: children[1].id, state: 'closed', conclusion: '已验证', recovery: [] } }));
const builtIn = api.mockCases.filter(item => item.fanoutSourceCaseId && !children.includes(item) && item.id !== original.id).map(item => ({ item, source: api.mockCases.find(source => source.id === item.fanoutSourceCaseId) })).filter(pair => pair.source);
const browser = await chromium.launch({ headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.addInitScript(entries => {
    for (const [key, value] of entries) if (!localStorage.getItem(key)) localStorage.setItem(key, value);
    localStorage.setItem('ea_onboarding_v0_2', 'seen');
    localStorage.setItem('ea_whatsnew_v1_0_2_f', 'seen');
    localStorage.setItem('ea_agent_position_v1', JSON.stringify({ x: 24, y: 680 }));
  }, [...storage]);
  await page.goto(process.env.EA_PREVIEW_URL);
  await expect(page).toHaveTitle('EA系统 · V1.1.0');
  await expect(page.getByTitle('当前版本', { exact: true })).toHaveText('V1.1.0');
  const open = async item => {
    await page.getByRole('button', { name: /搜索 Case、任务/ }).click();
    await page.getByRole('checkbox', { name: '查看 Fanout', exact: true }).check();
    await page.getByPlaceholder('搜索 Case、任务、用户…（多个关键词用空格分隔）').fill(item.code);
    await page.getByRole('button').filter({ hasText: item.code }).filter({ hasText: item.name }).click();
    await expect(page.getByRole('heading', { name: item.name, exact: true, level: 1 })).toBeVisible();
  };
  const banner = page.getByRole('region', { name: 'Fanout 原始 Case', exact: true });
  for (const { item, source } of [...children.map(item => ({ item, source: original })), ...builtIn]) {
    await open(item);
    await expect(banner).toContainText(source.code);
    await expect(banner).toContainText(source.name);
    for (const width of [1280, 1440]) {
      await page.setViewportSize({ width, height: 900 });
      await page.locator('main').evaluate(element => element.scrollTop = 0);
      const title = await page.getByRole('heading', { name: item.name, exact: true, level: 1 }).boundingBox();
      const bounds = await banner.boundingBox();
      assert.ok(bounds.y >= title.y + title.height && bounds.y - title.y - title.height < 28);
      assert.ok(bounds.y + bounds.height < 900 && bounds.x + bounds.width <= width);
      assert.equal(await banner.evaluate(element => element.scrollWidth > element.clientWidth), false);
      assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), false);
      if (item.id === children[0].id) await page.screenshot({ path: `/tmp/ea-v110-fanout-source-${width}.png` });
    }
    const before = await page.evaluate(() => localStorage.getItem('ea_domain_v6'));
    await banner.getByRole('link').focus();
    await page.keyboard.press('Enter');
    await expect(page.getByRole('heading', { name: source.name, exact: true, level: 1 })).toBeVisible();
    await expect(banner).toHaveCount(source.fanoutSourceCaseId ? 1 : 0);
    assert.equal(await page.evaluate(() => localStorage.getItem('ea_domain_v6')), before);
  }
  await page.reload();
  await open(children[0]);
  await banner.getByRole('link').click();
  await expect(page.getByRole('heading', { name: original.name, exact: true, level: 1 })).toBeVisible();
  await open(missing);await expect(banner).toContainText('原始 Case 暂不可用');await expect(banner.getByRole('link')).toHaveCount(0);
  await open(unknown);await expect(banner).toContainText('原始 Case 未记录');await expect(banner.getByRole('link')).toHaveCount(0);
  assert.deepEqual(errors, []);
  console.log(`PASS: ${children.length} generated and ${builtIn.length} built-in Fanout source links; active/closed, mouse/keyboard, reload, no data writes, missing-source handling, header visibility and long-name layout at 1280/1440.`);
} finally { await browser.close(); }