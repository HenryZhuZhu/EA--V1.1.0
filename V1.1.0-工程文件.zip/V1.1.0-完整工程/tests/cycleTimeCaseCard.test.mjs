import assert from "node:assert/strict";
import test from "node:test";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import vm from "node:vm";
import { build } from "esbuild";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";

const require = createRequire(import.meta.url);
const { outputFiles } = await build({
  entryPoints: [fileURLToPath(new URL("../src/app/components/CycleTimeCaseCard.tsx", import.meta.url))],
  bundle: true, write: false, platform: "node", format: "cjs", jsx: "automatic", packages: "external",
  external: ["./data", "./closures", "./caseTaskTrees", "./CaseProductPill", "./CaseMarkCodePill"],
});
const sandbox = { module: { exports: {} }, require(name) {
  if (name === "./data") return {
    flattenTasks: function walk(nodes, depth = 0, path = []) { return nodes.flatMap(task => [{ task, depth, path }, ...walk(task.children ?? [], depth + 1, [...path, task.title])]); },
    levelColors: { L1: "" }, urgencyBar: { 一般: "" },
  };
  if (name === "./closures") return { useClosures: () => ({ get: id => id === "open" ? undefined : ({ state: "closed", closedAt: "2026-10-01T10:00:00Z" }) }) };
  if (name === "./caseTaskTrees") return { useCaseTaskRevision() {}, loadCaseTaskTree: (_id, tasks) => tasks };
  if (name === "./CaseProductPill") return { CaseProductPill: () => null };
  if (name === "./CaseMarkCodePill") return { CaseMarkCodePill: () => null };
  return require(name);
} };
vm.runInNewContext(outputFiles[0].text, sandbox);
const { CycleTimeCaseCard } = sandbox.module.exports;
const caseItem = {
  id: "case", code: "EA-test", name: "测试 Case", owner: "张伟", level: "L1", urgency: "一般", status: "进行中",
  createdAt: "2026-10-01T00:00:00Z",
  tasks: [{
    id: "task", code: "EA-test.001", title: "跨部门任务", owner: "李四", department: "QA", status: "已完成",
    createdAt: "2026-10-01T00:00:00Z",
    statusHistory: [{ status: "已完成", at: "2026-10-01T10:00:00Z" }],
    waitingFeedbackPeriods: [{ reason: "等待外部反馈", startedAt: "2026-10-01T02:00:00Z", endedAt: "2026-10-01T04:00:00Z" }],
    children: [{ id: "missing", code: "EA-test.002", title: "无时间任务", owner: "王五", status: "已完成" }],
  }],
};
const render = (expanded, item = caseItem) => renderToStaticMarkup(createElement(CycleTimeCaseCard, { caseItem: item, expanded, onToggle() {}, onOpenTask() {} }));

test("Case card shows effective Case cycle and reuses detail Gantt with all tasks", () => {
  const html = render(true);
  assert.match(html, /跨部门任务/);
  assert.match(html, /无时间任务/);
  assert.match(html, /8\.0 小时/);
  assert.match(html, /未记录/);
  assert.match(html, /Case 有效 Cycle Time/);
  assert.match(html, /Case 总 Cycle Time/);
  assert.doesNotMatch(html, /Case Cycle Time/);
  assert.match(html, /data-gantt-row="task"/);
  assert.match(html, /data-gantt-row="missing"/);
  assert.match(html, /data-gantt-cycle-time="task"[^>]*>8\.0 小时/);
  assert.match(html, />日<\/button>/);
  assert.match(html, />周<\/button>/);
});
test("verification tasks render below their parent with distinct elapsed labels and do not inflate ordinary task count", () => {
  const waits = [
    { id: "done", parentTaskId: "task", title: "外部反馈", reason: "等待外部反馈", owner: "李娜", assignedBy: "李四", createdAt: "2026-10-01T02:00:00Z", endedAt: "2026-10-01T04:00:00Z", status: "已完成" },
    { id: "cancelled", parentTaskId: "task", title: "借机", reason: "等待借机", owner: "李娜", assignedBy: "李四", createdAt: "2026-10-01T05:00:00Z", endedAt: "2026-10-01T06:00:00Z", status: "已中止" },
    { id: "unknown", parentTaskId: "task", title: "内部验证", reason: "等待内部验证", owner: "李娜", assignedBy: "李四", createdAt: "2026-10-01T05:00:00Z", status: "已完成" },
  ];
  const item = { ...caseItem, tasks: [{ ...caseItem.tasks[0], waitingTasks: waits }] };
  const html = render(true, item);
  assert.equal((html.match(/data-gantt-row=/g) ?? []).length, 2);
  assert.equal((html.match(/data-gantt-verification=/g) ?? []).length, 3);
  assert.match(html.replace(/<[^>]*>/g, ""), /2 个普通任务 · 3 个验证任务/);
  assert.ok(html.indexOf('data-gantt-row="task"') < html.indexOf('data-gantt-verification="done"'));
  assert.ok(html.indexOf('data-gantt-verification="cancelled"') < html.indexOf('data-gantt-row="missing"'));
  assert.match(html, /等待验证时长：.*2\.0 小时/);
  assert.match(html, /已取消/);
  assert.doesNotMatch(html, /data-gantt-verification-bar="unknown"/);
  const scoped = renderToStaticMarkup(createElement(CycleTimeCaseCard, { caseItem: item, expanded: true, onToggle() {}, onOpenTask() {}, scopedTaskIds: ["missing"] }));
  assert.doesNotMatch(scoped, /data-gantt-verification=/);
});
test("collapsed Case hides Gantt, empty Case has an explicit empty state", () => {
  assert.doesNotMatch(render(false), /任务甘特图/);
  assert.match(render(false), /10\.0 小时/);
  assert.match(render(false), /title="紧急度：一般"/);
  assert.match(render(false), /w-1 shrink-0/);
  assert.match(render(true, { ...caseItem, tasks: [] }), /暂无可展示的任务/);
});
test("dashboard hides thought rows and keeps all nested executable tasks without indentation", () => {
  const html = render(true, { ...caseItem, tasks: [{ id: "thought", title: "隐藏的思路", children: caseItem.tasks }] });
  assert.doesNotMatch(html, /隐藏的思路|个思路|思路 \/ 任务/);
  assert.match(html, /data-gantt-row="task"/);
  assert.match(html, /data-gantt-row="missing"/);
  assert.doesNotMatch(html, /padding-left:(20|40)px/);
});
test("unfinished task Cycle Time freezes during an open legacy waiting interval", () => {
  const createdAt = new Date(Date.now() - 5 * 3600000).toISOString();
  const html = render(true, { ...caseItem, id: "open", tasks: [{
    ...caseItem.tasks[0], status: "进行中", createdAt, children: [],
    waitingFeedbackPeriods: [{ reason: "等待外部反馈", startedAt: createdAt }],
  }] });
  assert.match(html, /data-gantt-cycle-time="task"[^>]*>0\.0 小时/);
});
test("department-scoped Gantt retains nested selected tasks exactly once and does not change Case totals", () => {
  const html = renderToStaticMarkup(createElement(CycleTimeCaseCard, {
    caseItem, expanded: true, onToggle() {}, onOpenTask() {}, scopedTaskIds: ["missing"],
  }));
  assert.match(html, /当前部门任务/);
  assert.match(html, /全部任务/);
  assert.doesNotMatch(html, /data-gantt-row="task"/);
  assert.equal((html.match(/data-gantt-row="missing"/g) ?? []).length, 1);
  assert.match(html, /10\.0 小时/);
});
