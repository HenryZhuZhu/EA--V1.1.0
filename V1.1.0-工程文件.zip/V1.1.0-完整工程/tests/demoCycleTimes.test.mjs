import test from "node:test";
import assert from "node:assert/strict";
import vm from "node:vm";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";
import { webcrypto } from "node:crypto";
const { outputFiles } = await build({
  stdin: {
    contents: `export {mockCases, flattenTasks, ownerToDepartment} from './data';
      export {getClosure} from './closures';
      export {taskLifecycleTimes} from './caseTiming';
      export {loadCaseTaskTree} from './caseTaskTrees';
      export {caseCycleMetrics, departmentCaseRecord, summarizeDepartment, departmentScope, departmentTreeFor} from './departmentAnalytics';
      export {taskCaseRange} from './cycleTimeRanges';
      export {dashboardDemoTimeMigrations} from './data';`,
    resolveDir: fileURLToPath(new URL("../src/app/components", import.meta.url)),
  },
  bundle: true, write: false, platform: "node", format: "cjs",
  plugins: [{ name: "hooks", setup(builder) {
    builder.onResolve({ filter: /^react$/ }, () => ({ path: "react", namespace: "test" }));
    builder.onLoad({ filter: /.*/, namespace: "test" }, () => ({ contents: "export const useEffect=()=>{}; export const useState=()=>[0,()=>{}];" }));
  } }],
});
function boot(saved = {}) {
  const storage = new Map(Object.entries(saved));
  const box = { module: { exports: {} }, btoa, atob, crypto: webcrypto, localStorage: {
    getItem: key => storage.get(key) ?? null,
    setItem: (key, value) => storage.set(key, value),
  } };
  vm.runInNewContext(outputFiles[0].text, box);
  return { ...box.module.exports, storage };
}
const day = 86400000;
test("all seeded terminal tasks have ordered final events; all closed Cases have explicit closing dates", () => {
  const api = boot();
  const now = Date.parse("2026-10-26T09:00:00+08:00");
  for (const item of api.mockCases) {
    const closure = api.getClosure(item.id);
    const metrics = api.caseCycleMetrics(item, closure, now);
    if (metrics.closed) {
      assert.notEqual(metrics.total, null, item.id);
      assert.ok(metrics.total >= metrics.effective && metrics.effective >= 0, item.id);
    }
    for (const { task } of api.flattenTasks(item.tasks).filter(({ task }) => task.code)) {
      assert.equal(new Date(task.createdAt).getMonth(), 8, task.id);
      if (!["已完成", "已拒绝", "已中止"].includes(task.status)) continue;
      const timing = api.taskLifecycleTimes(task, new Date(now));
      assert.ok(timing.endedAt, task.id);
      assert.ok(Date.parse(timing.endedAt) >= Date.parse(task.createdAt), task.id);
      assert.equal(timing.cycleEnd, api.taskLifecycleTimes(task, new Date(now + day)).cycleEnd);
      if (metrics.closed) assert.ok(Date.parse(timing.cycleEnd) <= Date.parse(closure.closedAt), task.id);
    }
  }
});
test("reference sample exactly matches Case 11/9 days, PTE 5/5 days, task 3 days and wait 2 days", () => {
  const api = boot();
  const item = api.mockCases.find(item => item.id === "c-cycle-demo");
  const closure = api.getClosure(item.id);
  const metrics = api.caseCycleMetrics(item, closure);
  assert.equal(metrics.total, 11 * day);
  assert.equal(metrics.effective, 9 * day);
  assert.equal(metrics.excluded, 2 * day);
  const record = api.departmentCaseRecord(item, item.tasks, closure, Date.parse(closure.closedAt), api.ownerToDepartment);
  const pte = api.summarizeDepartment([record], new Set(["PTE"]));
  assert.equal(pte.taskCount, 2);
  assert.equal(pte.totalAverage, 5 * day);
  assert.equal(pte.average, 5 * day);
  assert.equal(pte.taskAverage, 3 * day);
});
test("known cached seeds missing end time are repaired without overwriting edited later histories", () => {
  const seed = boot().mockCases.find(item => item.id === "c004").tasks;
  const clone = JSON.parse(JSON.stringify(seed));
  const flatten = nodes => nodes.flatMap(task => [task, ...flatten(task.children ?? [])]);
  const task = flatten(clone).find(task => task.id === "t41");
  task.statusHistory = [];
  task.title = "保留用户编辑";
  const api = boot({ ea_case_task_trees_v1: JSON.stringify({ c004: clone }) });
  const restored = api.flattenTasks(api.loadCaseTaskTree("c004", seed)).find(({ task }) => task.id === "t41").task;
  assert.equal(restored.title, "保留用户编辑");
  assert.ok(api.taskLifecycleTimes(restored).endedAt);
  task.statusHistory = [{ status: "进行中", at: "2026-10-25T09:00:00+08:00" }];
  const newer = boot({ ea_case_task_trees_v1: JSON.stringify({ c004: clone }) });
  const unchanged = newer.flattenTasks(newer.loadCaseTaskTree("c004", seed)).find(({ task }) => task.id === "t41").task;
  assert.equal(newer.taskLifecycleTimes(unchanged).endedAt, undefined);
});
test("all departments and parent scopes stay inside each Case lifecycle on multiple reporting dates", () => {
  const api = boot();
  const tree = api.departmentTreeFor(Object.values(api.ownerToDepartment));
  let measured = 0, distinct = 0;
  for (const now of ["2026-10-26T00:00:00+08:00", "2026-11-15T18:00:00+08:00"]) {
    for (const item of api.mockCases) {
      const closure = api.getClosure(item.id);
      const metrics = api.caseCycleMetrics(item, closure, Date.parse(now));
      const tasks = api.flattenTasks(api.loadCaseTaskTree(item.id, item.tasks)).map(entry => entry.task).filter(t => t.code);
      const record = api.departmentCaseRecord(item, tasks, closure, Date.parse(now), api.ownerToDepartment);
      assert.notEqual(metrics.total, null, item.id);
      for (const task of record.tasks) {
        assert.equal(task.timingIssue, undefined, `${item.id}/${task.task.id}: ${task.timingIssue}`);
        const taskEnd = Date.parse(api.taskLifecycleTimes(task.task, new Date(now)).cycleEnd);
        for (const wait of task.task.waitingTasks ?? []) {
          assert.ok(Date.parse(wait.createdAt) >= Date.parse(task.task.createdAt), wait.id);
          const waitEnd = wait.endedAt ? Date.parse(wait.endedAt) : Date.parse(now);
          assert.ok(waitEnd >= Date.parse(wait.createdAt) && waitEnd <= taskEnd, wait.id);
        }
        for (const part of task.totalIntervals ?? []) {
          assert.ok(part.start >= Date.parse(item.createdAt), task.task.id);
          assert.ok(part.end <= Date.parse(item.createdAt) + metrics.total, task.task.id);
        }
      }
      for (const dept of tree) {
        const result = api.summarizeDepartment([record], api.departmentScope(tree, dept.id, true));
        if (result.totalAverage === null) continue;
        measured++;
        assert.ok(result.totalAverage <= metrics.total, `${item.id}/${dept.id}: department > Case`);
        assert.ok(result.average >= 0 && result.average <= result.totalAverage, `${item.id}/${dept.id}`);
        if (result.totalAverage < metrics.total) distinct++;
      }
    }
  }
  assert.ok(distinct / measured > 0.7, `Too many identical cycles: ${distinct}/${measured}`);
});
test("diverse reference scenarios have exact serial, parallel, gap and creator-only totals", () => {
  const api = boot();
  for (const [id, total, effective, pteTotal, pteEffective] of [
    ["cycle-serial", 13, 11, 5, 3], ["cycle-parallel", 15, 13, 9, 6],
    ["cycle-gap", 21, 19, 7, 5], ["cycle-creator", 10, 8, null, null],
  ]) {
    const item = api.mockCases.find(c => c.id === id), closure = api.getClosure(id);
    const caseMetrics = api.caseCycleMetrics(item, closure);
    const record = api.departmentCaseRecord(item, item.tasks, closure, Date.now(), api.ownerToDepartment);
    const pte = api.summarizeDepartment([record], new Set(["PTE"]));
    assert.equal(caseMetrics.total / day, total, id);
    assert.equal(caseMetrics.effective / day, effective, id);
    assert.equal(pte.totalAverage === null ? null : pte.totalAverage / day, pteTotal, id);
    assert.equal(pte.average === null ? null : pte.average / day, pteEffective, id);
    assert.equal(pte.count, 1, id);
  }
});
test("cached c001 pre-Case dates cannot inflate department totals; raw user edits are preserved and flagged", () => {
  const task = { id: "t1b", code: "EA-260511000001.002", title: "用户修改保留", department: "PTE", owner: "张伟", status: "进行中", createdAt: "2026-04-22T09:00:00+08:00", urgency: "一般" };
  const api = boot({ ea_case_task_trees_v1: JSON.stringify({ c001: [task] }) });
  const item = api.mockCases.find(c => c.id === "c001");
  const loaded = api.loadCaseTaskTree(item.id, item.tasks);
  const now = Date.parse("2026-10-26T09:00:00+08:00");
  const metrics = api.caseCycleMetrics(item, undefined, now);
  const record = api.departmentCaseRecord(item, loaded, undefined, now, api.ownerToDepartment);
  const result = api.summarizeDepartment([record], api.departmentScope(api.departmentTreeFor(["PTE"]), "PTE", true));
  assert.ok(result.totalAverage <= metrics.total);
  assert.match(record.tasks[0].timingIssue, /交集/);
  assert.equal(loaded[0].createdAt, task.createdAt);
  assert.equal(loaded[0].title, task.title);
  const closed = { state: "closed", closedAt: "2026-09-30T09:00:00+08:00" };
  const first = api.taskCaseRange(item, loaded[0], closed, now);
  const later = api.taskCaseRange(item, loaded[0], closed, now + day * 30);
  assert.equal(first.interval.end, later.interval.end);
});
test("exact old seed timing is updated once without resetting other user fields", () => {
  const initial = boot();
  const [key, correction] = [...initial.dashboardDemoTimeMigrations.entries()][0];
  assert.ok(key);
  const [caseId, taskId] = key.split("/");
  const original = JSON.parse(correction.signature);
  const node = { ...original, id: taskId, code: "cached-code", title: "用户说明保留", department: "PTE", owner: "张伟", urgency: "一般" };
  const api = boot({ ea_case_task_trees_v1: JSON.stringify({ [caseId]: [node] }) });
  const updated = api.loadCaseTaskTree(caseId, [node])[0];
  assert.equal(updated.createdAt, correction.createdAt);
  assert.equal(updated.title, node.title);
  assert.equal(api.loadCaseTaskTree(caseId, [node])[0].createdAt, updated.createdAt);
});
