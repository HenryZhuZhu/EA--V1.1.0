import type { ComponentProps } from "react";
import { MyTaskWorkbench } from "./MyTaskWorkbench";

export function MyTaskHub(props: ComponentProps<typeof MyTaskWorkbench>) {
  return <MyTaskWorkbench {...props} />;
}