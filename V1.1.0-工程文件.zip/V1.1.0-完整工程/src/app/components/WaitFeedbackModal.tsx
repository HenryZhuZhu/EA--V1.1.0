import { useRef, useState } from "react";
import { Pause } from "lucide-react";
import { WAITING_FEEDBACK_REASONS, type WaitingFeedbackInput, type WaitingFeedbackReason } from "./data";
import { TaskDialog } from "./TaskDialog";

export function WaitFeedbackModal({ title, onClose, onConfirm }: {
  title: string;
  onClose: () => void;
  onConfirm: (input: WaitingFeedbackInput) => void;
}) {
  const [reason, setReason] = useState<WaitingFeedbackReason | "">("");
  const [description, setDescription] = useState("");
  const [error, setError] = useState("");
  const submitting = useRef(false);
  const confirm = () => {
    if (!reason || !description.trim() || submitting.current) return;
    submitting.current = true;
    try { onConfirm({ reason, description: description.trim() }); onClose(); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "等待状态保存失败，请重试。"); }
    finally { submitting.current = false; }
  };
  return <TaskDialog title="进入等待反馈" description="选择当前阻塞原因并补充说明。等待时间将从确认时开始记录，收到反馈后可重新启动任务。" onClose={onClose} footer={<>
    <button type="button" onClick={onClose} className="h-9 rounded-md border border-slate-200 bg-white px-4 text-xs text-slate-600 hover:bg-slate-50">取消</button>
    <button type="button" onClick={confirm} disabled={!reason || !description.trim()} className="inline-flex h-9 items-center gap-1.5 rounded-md bg-amber-600 px-4 text-xs font-medium text-white hover:bg-amber-700 disabled:cursor-not-allowed disabled:opacity-40"><Pause size={13} />确认等待</button>
  </>}>
    <div className="mb-4 rounded-lg border border-slate-200 bg-slate-50 px-3 py-3 text-sm text-slate-700">{title}</div>
    <fieldset>
      <legend className="text-xs font-medium text-slate-600">等待类型 <span className="text-red-400">*</span></legend>
      <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-3">
        {WAITING_FEEDBACK_REASONS.map((item) => <button key={item} type="button" aria-pressed={reason === item} onClick={() => { setReason(item); setError(""); }} className={`h-10 rounded-md border px-3 text-xs font-medium transition-colors ${reason === item ? "border-amber-500 bg-amber-50 text-amber-800" : "border-slate-200 bg-white text-slate-600 hover:border-amber-300 hover:bg-amber-50/40"}`}>{item}</button>)}
      </div>
    </fieldset>
    <label className="mt-5 block text-xs font-medium text-slate-600">等待描述 <span className="text-red-400">*</span>
      <textarea autoFocus required maxLength={500} aria-label="等待描述" value={description} onChange={(event) => { setDescription(event.target.value); setError(""); }} placeholder="请说明正在等待谁、什么结果，以及后续如何继续" className="mt-2 min-h-[110px] w-full resize-none rounded-lg border border-slate-200 px-3 py-2.5 text-sm font-normal leading-relaxed outline-none focus:border-amber-500" />
    </label>
    <div className="mt-1 text-right text-[10px] tabular-nums text-slate-400">{description.length}/500</div>
    {error && <p role="alert" className="mt-3 text-xs text-red-600">{error}</p>}
  </TaskDialog>;
}