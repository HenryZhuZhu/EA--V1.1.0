import { useRef, useState } from "react";
import { currentUser, ownerToDepartment } from "./data";
import { PersonInput } from "./PersonInput";
import { TaskDialog } from "./TaskDialog";
import { WAIT_TASK_REASONS, type WaitingTaskInput, type WaitTaskReason } from "./waitingTasks";

export function WaitFeedbackModal({ title, onClose, onConfirm }: {
  title: string; onClose: () => void; onConfirm: (input: WaitingTaskInput) => void;
}) {
  const [reason, setReason] = useState<WaitTaskReason>("等待外部反馈");
  const [description, setDescription] = useState("");
  const [owner, setOwner] = useState(currentUser.name);
  const [dueDate, setDueDate] = useState("");
  const [error, setError] = useState("");
  const submitting = useRef(false);
  const confirm = () => {
    if (submitting.current) return;
    if (!description.trim() || !ownerToDepartment[owner]) { setError("请填写说明，并从人员候选中选择任务负责人。"); return; }
    submitting.current = true;
    try { onConfirm({ reason, description, owner, dueDate: dueDate || undefined }); onClose(); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "等待任务保存失败，请重试。"); }
    finally { submitting.current = false; }
  };
  return <TaskDialog title="新增特殊任务" description="特殊任务挂在原任务的验证节点后。创建后原任务计时暂停，全部特殊任务完成或取消后自动恢复。" onClose={onClose} footer={<>
    <button onClick={onClose} className="h-9 rounded-md border border-slate-200 px-4 text-xs">取消</button>
    <button onClick={confirm} className="h-9 rounded-md bg-amber-600 px-4 text-xs text-white">创建特殊任务</button>
  </>}>
    <div className="mb-4 rounded-lg bg-slate-50 p-3 text-sm">原任务：{title}</div>
    <fieldset><legend className="text-xs text-slate-600">等待类型</legend><div className="mt-2 grid grid-cols-2 gap-2">{WAIT_TASK_REASONS.map(value => <button key={value} aria-pressed={reason === value} onClick={() => setReason(value)} className={`rounded-md border p-3 text-xs ${reason === value ? "border-amber-500 bg-amber-50 text-amber-800" : "border-slate-200"}`}>{value}</button>)}</div></fieldset>
    <div className="mt-4"><label htmlFor="waiting-task-owner" className="mb-2 block text-xs text-slate-600">任务负责人</label><PersonInput id="waiting-task-owner" value={owner} onChange={setOwner} placeholder="搜索姓名或部门" /></div>
    <label className="mt-4 block text-xs text-slate-600">预计完成日期（可选）<input type="date" value={dueDate} onChange={event => setDueDate(event.target.value)} className="mt-2 h-9 w-full rounded-md border border-slate-200 px-3" /></label>
    <label className="mt-4 block text-xs text-slate-600">等待说明<textarea aria-label="等待说明" value={description} onChange={event => setDescription(event.target.value)} maxLength={500} className="mt-2 min-h-24 w-full rounded-md border border-slate-200 p-3" /></label>
    {error && <p role="alert" className="mt-3 text-xs text-red-600">{error}</p>}
  </TaskDialog>;
}
