import { useEffect, useState } from "react";
import { currentUser } from "./data";
import { WaitFeedbackModal } from "./WaitFeedbackModal";
import { activeWaitingTasks, type WaitingTaskAction, type WaitingTaskRecord } from "./waitingTasks";

export function WaitingTaskPanel({ record, title, disabledReason, onAction, allowCreate = true }: {
  record: WaitingTaskRecord; title: string; disabledReason?: string; onAction: (action: WaitingTaskAction) => void; allowCreate?: boolean;
}) {
  const [adding, setAdding] = useState(false);
  const [ending, setEnding] = useState<{ id: string; kind: "complete" | "cancel" }>();
  const [result, setResult] = useState("");
  const [error, setError] = useState("");
  const [now, setNow] = useState(Date.now);
  useEffect(() => { const timer = setInterval(() => setNow(Date.now()), 60000); return () => clearInterval(timer); }, []);
  const active = activeWaitingTasks(record);
  const canOperate = !disabledReason && ["进行中", "整改中"].includes(record.status);
  return <section aria-label="等待任务" className="rounded-lg border border-amber-200 bg-amber-50/40 p-4">
    <header className="flex items-center gap-3"><h3 className="text-sm font-semibold text-amber-800">等待任务</h3><span className="text-xs text-amber-700">{active.length ? `${active.length} 项阻塞 · 原任务计时暂停` : "无未解除阻塞"}</span>
      {allowCreate && canOperate && record.owner === currentUser.name && <button onClick={() => setAdding(true)} className="ml-auto rounded-md border border-amber-300 bg-white px-3 py-1.5 text-xs text-amber-800">新建等待任务</button>}
    </header>
    <div className="mt-2 text-[11px] text-slate-500">等待任务独立记录，不计入普通任务数量与完成率。原任务 Cycle Time 扣除重叠去重后的阻塞时段。</div>
    {!record.waitingTasks?.length && <p className="mt-3 text-xs text-slate-400">暂无等待任务</p>}
    <div className="mt-3 space-y-2">{record.waitingTasks?.map(task => <article key={task.id} className="rounded-lg border border-amber-200 bg-white p-3">
      <div className="flex items-center gap-2"><b className="text-xs">{task.title}</b><span className="rounded bg-amber-50 px-2 py-0.5 text-[10px] text-amber-800">{task.status === "已中止" ? "已取消" : task.status}</span><span className="ml-auto text-[11px] text-slate-500">{(Math.max(0, Date.parse(task.endedAt ?? new Date(now).toISOString()) - Date.parse(task.createdAt)) / 3600000).toFixed(1)} 小时</span></div>
      <p className="mt-1 break-all font-mono text-[10px] text-slate-400">{task.id}</p>
      <div className="mt-2 text-[11px] text-slate-500">任务负责人：{task.owner} · 任务分派人：{task.assignedBy} · 创建：{new Date(task.createdAt).toLocaleString("zh-CN")}</div>
      {task.dueDate && <div className="mt-1 text-[11px] text-slate-500">预计完成：{task.dueDate}</div>}
      <p className="mt-2 whitespace-pre-wrap text-xs text-slate-600">{task.description}</p>
      {task.result && <p className="mt-2 whitespace-pre-wrap text-xs text-slate-600">{task.status === "已完成" ? "完成结果" : "取消原因"}：{task.result} · {task.endedBy}</p>}
      {canOperate && task.status === "进行中" && (record.owner === currentUser.name || task.owner === currentUser.name) && <div className="mt-3 flex gap-2">
        <button onClick={() => { setEnding({ id: task.id, kind: "complete" }); setResult(""); }} className="rounded bg-[#0052D9] px-3 py-1.5 text-xs text-white">完成等待任务</button>
        <button onClick={() => { setEnding({ id: task.id, kind: "cancel" }); setResult(""); }} className="rounded border border-slate-200 px-3 py-1.5 text-xs">取消等待任务</button>
      </div>}
      {ending?.id === task.id && <div className="mt-3"><textarea aria-label="等待任务结果或取消原因" placeholder={ending.kind === "complete" ? "填写完成结果" : "填写取消原因"} value={result} onChange={event => setResult(event.target.value)} className="min-h-20 w-full rounded border border-slate-200 p-2 text-xs" /><div className="mt-2 flex gap-2"><button onClick={() => {
        try { onAction({ ...ending, result }); setEnding(undefined); setError(""); }
        catch (cause) { setError(cause instanceof Error ? cause.message : "操作失败，请重试。"); }
      }} className="rounded bg-[#0052D9] px-3 py-1.5 text-xs text-white">确认</button><button onClick={() => setEnding(undefined)} className="text-xs text-slate-500">返回</button></div></div>}
    </article>)}</div>
    {error && <p role="alert" className="mt-2 text-xs text-red-600">{error}</p>}
    {adding && <WaitFeedbackModal title={title} onClose={() => setAdding(false)} onConfirm={input => onAction({ kind: "create", input })} />}
  </section>;
}
