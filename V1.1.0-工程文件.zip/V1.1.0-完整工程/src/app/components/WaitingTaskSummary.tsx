import { activeWaitingTasks, type WaitingTaskRecord } from "./waitingTasks";

export function WaitingTaskSummary({ record, onOpen }: { record: WaitingTaskRecord; onOpen?: () => void }) {
  const active = activeWaitingTasks(record);
  if (!record.waitingTasks?.length) return null;
  return <div className="mt-2 space-y-1.5" aria-label="关联等待任务">
    {active.length > 0 && <div className="rounded border border-amber-200 bg-amber-50 px-2 py-1 text-[10px] font-medium text-amber-800">计时暂停 · {active.length} 项等待未结束</div>}
    {record.waitingTasks.map(task => <button key={task.id} type="button" onClick={onOpen} className="flex w-full items-center gap-2 rounded-md border border-dashed border-amber-300 bg-amber-50/70 px-2 py-2 text-left text-[10px] text-amber-900">
      <span aria-hidden>↳</span><span className="min-w-0 flex-1"><b className="block truncate">等待任务 · {task.title}</b><span className="block">任务负责人：{task.owner}</span></span><span className="shrink-0">{task.status === "已中止" ? "已取消" : task.status}</span>
    </button>)}
  </div>;
}
