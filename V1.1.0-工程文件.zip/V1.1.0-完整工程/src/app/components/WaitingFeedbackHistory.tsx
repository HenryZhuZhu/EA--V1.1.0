import { Clock3 } from "lucide-react";
import type { WaitingFeedbackPeriod } from "./data";

function formatTime(value: string) {
  return new Date(value).toLocaleString("zh-CN", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hour12: false });
}

function durationText(startedAt: string, endedAt?: string) {
  const milliseconds = Math.max(0, Date.parse(endedAt ?? new Date().toISOString()) - Date.parse(startedAt));
  const hours = milliseconds / 3600000;
  return hours < 1 ? `${Math.max(1, Math.round(milliseconds / 60000))} 分钟` : hours < 48 ? `${hours.toFixed(1)} 小时` : `${(hours / 24).toFixed(1)} 天`;
}

export function WaitingFeedbackHistory({ periods, compact = false }: { periods?: WaitingFeedbackPeriod[]; compact?: boolean }) {
  if (!periods?.length) return null;
  const ordered = [...periods].reverse();
  return <section aria-label="等待反馈时间记录" className={compact ? "mt-3 rounded-lg border border-amber-200 bg-amber-50/60 p-3" : "rounded-lg border border-amber-200 bg-amber-50/50 p-4"}>
    <h3 className="flex items-center gap-1.5 text-xs font-medium text-amber-800"><Clock3 size={13} />历史等待时间记录 · {periods.length} 次</h3>
    <div className="mt-2 space-y-1.5">
      {ordered.map((period) => <div key={period.id} className="flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-slate-600">
        <span className="rounded border border-amber-200 bg-white px-1.5 py-0.5 font-medium text-amber-700">{period.reason ?? "等待反馈"}</span>
        <span>{formatTime(period.startedAt)}</span><span className="text-slate-300">→</span><span>{period.endedAt ? formatTime(period.endedAt) : "等待中"}</span>
        <span className={`rounded px-1.5 py-0.5 ${period.endedAt ? "bg-white text-slate-500" : "bg-amber-100 font-medium text-amber-700"}`}>{durationText(period.startedAt, period.endedAt)}</span>
        {period.description && <span className="basis-full pl-0.5 leading-5 text-slate-500">{period.description}</span>}
      </div>)}
    </div>
  </section>;
}