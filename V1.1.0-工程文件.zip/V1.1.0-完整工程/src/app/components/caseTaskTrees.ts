import { useEffect, useState } from "react";
import { applyWaitingFeedbackTransition, currentUser, flattenTasks, mockCases, normalizeTaskType, TaskNode, dashboardDemoTimeMigrations, type WaitingFeedbackInput } from "./data";
import { demoTaskTimeSignature } from "./dashboardDemoScenarios";
import { taskCreationTime, taskLifecycleTimes } from "./caseTiming";
import { DEMO_TASK_END_TIMES } from "./demoCycleTimes";
import { applyWaitingTaskAction, endWaitingTasksWithParent, migrateWaitingTasks, type WaitingTaskAction } from "./waitingTasks";
import { allClosureRecords, getClosure, isCaseClosed, registerCaseReturnTaskHandler } from "./closures";
import { addTaskComment, mergeTaskActivities, mergeTaskComments, recordTaskChange, taskActivity } from "./taskActivity";
import { activeRecovery, canReopenRecord, canReturnRecord, validateRecoveryAction, finishRecovery, trackRecoveryEdit, startRecovery, supplementRecord, type RecoveryAction, type RecoveryFile } from "./recordRecovery";

const KEY = "ea_case_task_trees_v1";
const demoCreationDates = new Map(mockCases.map(item => [item.id, new Map(flattenTasks(item.tasks).map(({ task }) => [task.id, task.createdAt]))]));
const demoTaskStatuses = new Map(mockCases.map(item => [item.id, new Map(flattenTasks(item.tasks).map(({ task }) => [task.id, task.status]))]));
let revision = 0;
const listeners = new Set<() => void>();

export function useCaseTaskRevision() {
  const [value, setValue] = useState(revision);
  useEffect(() => {
    const listener = () => setValue(revision);
    listeners.add(listener);
    listener();
    return () => { listeners.delete(listener); };
  }, []);
  return value;
}

function readAll(): Record<string, TaskNode[]> {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function normalizeLegacyStatuses(nodes: TaskNode[]): TaskNode[] {
  return nodes.map((node) => ({
    ...node,
    type: normalizeTaskType(node.type),
    status: (node.status as string) === "待开始" ? "待接受" : node.status,
    statusHistory: node.statusHistory?.map((entry) => ({
      ...entry,
      status: (entry.status as string) === "待开始" ? "待接受" : entry.status,
    })),
    children: node.children ? normalizeLegacyStatuses(node.children) : node.children,
  }));
}

export function loadCaseTaskTree(caseId: string, fallback: TaskNode[]): TaskNode[] {
  const saved = readAll();
  let datesChanged = false;
  const restoreDates = (nodes: TaskNode[]): TaskNode[] => nodes.map(node => {
    const correction = dashboardDemoTimeMigrations.get(`${caseId}/${node.id}`);
    if (correction && demoTaskTimeSignature(node) === correction.signature) {
      node = { ...node, createdAt: correction.createdAt };
      datesChanged = true;
    }
    let createdAt = taskCreationTime(node);
    if (node.code && !createdAt) {
      const seedDate = demoCreationDates.get(caseId)?.get(node.id);
      const earliestHistory = node.statusHistory?.filter(entry => Number.isFinite(Date.parse(entry.at)))
        .map(entry => entry.at).sort((a, b) => Date.parse(a) - Date.parse(b))[0];
      createdAt = earliestHistory ?? seedDate;
    }
    if (createdAt && createdAt !== node.createdAt) datesChanged = true;
    let datedNode = { ...node, createdAt: createdAt ?? node.createdAt };
    const seedEnd = DEMO_TASK_END_TIMES[`${caseId}/${node.id}`];
    if (seedEnd && demoTaskStatuses.get(caseId)?.get(node.id) === node.status && ["已完成", "已拒绝", "已中止"].includes(node.status) && !taskLifecycleTimes(datedNode).endedAt) {
      const latest = Math.max(Date.parse(datedNode.createdAt ?? "") || 0,
        ...(node.statusHistory ?? []).map(entry => Date.parse(entry.at) || 0),
        ...(node.recovery ?? []).map(entry => Date.parse(entry.at) || 0));
      if (Date.parse(seedEnd) >= latest) {
        datedNode = { ...datedNode, statusHistory: [...(node.statusHistory ?? []), { status: node.status, at: seedEnd, by: node.owner }] };
        datesChanged = true;
      }
    }
    const migrated = migrateWaitingTasks(datedNode);
    if (migrated !== datedNode) datesChanged = true;
    return { ...migrated, createdAt: createdAt ?? node.createdAt, children: node.children ? restoreDates(node.children) : node.children };
  });
  const source = restoreDates(normalizeLegacyStatuses(saved[caseId] ?? fallback));
  const reconciled = reconcileCaseTaskRemediation(source);
  if (datesChanged || reconciled !== source) {
    localStorage.setItem(KEY, JSON.stringify({ ...saved, [caseId]: reconciled }));
    const caseItem = mockCases.find((item) => item.id === caseId);
    if (caseItem) caseItem.tasks = reconciled;
  }
  return reconciled;
}

export function reconcileCaseTaskRemediation(nodes: TaskNode[], now = new Date().toISOString()): TaskNode[] {
  let changed = false;
  const reconcile = (items: TaskNode[]): TaskNode[] => items.map((node) => {
    let next = node;
    if (node.status === "整改中" && node.caseRemediation && !node.caseRemediation.editedAt && Date.parse(now) >= Date.parse(node.caseRemediation.expiresAt)) {
      changed = true;
      const restoredAt = now;
      next = {
        ...node,
        status: node.caseRemediation.originalStatus,
        caseRemediation: { ...node.caseRemediation, restoredAt },
        statusHistory: [...(node.statusHistory ?? []), { status: node.caseRemediation.originalStatus, at: restoredAt, by: "系统" }],
        activityLog: [...(node.activityLog ?? []), taskActivity("status", "整改期满且任务未修改，恢复原状态", [{ field: "状态", before: "整改中", after: node.caseRemediation.originalStatus }], undefined, restoredAt)],
      };
    }
    const children = next.children ? reconcile(next.children) : next.children;
    return children === next.children ? next : { ...next, children };
  });
  const result = reconcile(nodes);
  return changed ? result : nodes;
}

export function startCaseTaskRemediation(caseId: string, recoveryId: string, startedAt: string, expiresAt: string) {
  const caseItem = mockCases.find((item) => item.id === caseId);
  if (!caseItem) throw new Error("Case 不存在。");
  const tasks = loadCaseTaskTree(caseId, caseItem.tasks);
  const mark = (nodes: TaskNode[]): TaskNode[] => nodes.map((node) => {
    const children = node.children ? mark(node.children) : node.children;
    if (!node.code) return children === node.children ? node : { ...node, children };
    const originalStatus = node.status === "整改中" && node.caseRemediation ? node.caseRemediation.originalStatus : node.status;
    return {
      ...node,
      children,
      status: "整改中",
      caseRemediation: { recoveryId, startedAt, expiresAt, originalStatus },
      statusHistory: [...(node.statusHistory ?? []), { status: "整改中", at: startedAt, by: currentUser.name }],
      activityLog: [...(node.activityLog ?? []), taskActivity("status", "所属 Case 退回整改", [{ field: "状态", before: node.status, after: "整改中" }], undefined, startedAt)],
    };
  });
  return saveCaseTaskTree(caseId, mark(tasks), true, tasks);
}

export function saveCaseTaskTree(caseId: string, tasks: TaskNode[], strict = false, expectedTree?: TaskNode[], waitingChangeTaskId?: string) {
  tasks = normalizeLegacyStatuses(tasks);
  const saved = readAll();
  const caseItem = mockCases.find((item) => item.id === caseId);
  if (expectedTree && JSON.stringify(normalizeLegacyStatuses(saved[caseId] ?? caseItem?.tasks ?? [])) !== JSON.stringify(normalizeLegacyStatuses(expectedTree))) {
    throw new Error("任务已由其他操作更新。请重新打开详情后修改，避免覆盖新的记录。");
  }
  // 比较同样归一化后的状态，避免把旧状态迁移冒充一次用户流转。
  const previous = new Map(flattenTasks(normalizeLegacyStatuses(saved[caseId] ?? caseItem?.tasks ?? [])).map(({ task }) => [task.id, task]));
  const retainedIds = new Set(flattenTasks(tasks).map(({ task }) => task.id));
  for (const old of previous.values()) {
    if (!retainedIds.has(old.id) && (old.verificationNode || old.waitingTasks?.length)) throw new Error("含验证分支的原任务不能直接删除，请保留特殊任务及其计时历史。");
  }
  const record = (nodes: TaskNode[]): TaskNode[] => nodes.map((node) => {
    const old = previous.get(node.id);
    let next = { ...node, children: node.children ? record(node.children) : node.children };
    if (old) {
      next.createdAt = taskCreationTime(old);
      if (node.id !== waitingChangeTaskId) {
        next.waitingTasks = old.waitingTasks;
        next.verificationNode = old.verificationNode;
      }
      next = trackRecoveryEdit(old, next);
      if (old.status !== "已完成" && node.status === "已完成") next = { ...next, ...finishRecovery(next) };
      next = { ...next, activityLog: mergeTaskActivities(old.activityLog, next.activityLog), comments: mergeTaskComments(old.comments, next.comments) };
      next.statusHistory = [...new Map([...(old.statusHistory ?? []), ...(node.statusHistory ?? [])].map((entry) => [`${entry.at}:${entry.status}:${entry.by ?? ""}`, entry])).values()];
      if (node.code) {
        const changed = recordTaskChange(old, next);
        // 没有字段变化仍须保留本次新增的评论/回复（不当作字段编辑重复记日志）。
        if (changed !== old) {
          next = changed;
          if (old.status === "整改中" && old.caseRemediation && !old.caseRemediation.editedAt) {
            next = { ...next, caseRemediation: { ...old.caseRemediation, editedAt: new Date().toISOString() } };
          }
        }
        if (old.status !== node.status && !node.statusHistory?.some((entry) => entry.status === node.status && !(old.statusHistory ?? []).some((prior) => prior.at === entry.at && prior.status === entry.status))) {
          const at = next.activityLog?.at(-1)?.at ?? new Date().toISOString();
          next.statusHistory = [...(next.statusHistory ?? []), { status: node.status, at, by: currentUser.name }];
        }
      }
    } else if (node.code) {
      const createdAt = taskCreationTime(node) ?? new Date().toISOString();
      next.createdAt = createdAt;
      next.activityLog = [...(node.activityLog ?? []), taskActivity("create", "创建执行任务", [{ field: "状态", before: "未创建", after: node.status }], undefined, createdAt)];
    }
    return old && old.status !== next.status
      ? endWaitingTasksWithParent(next, currentUser.name, new Date().toISOString()) : next;
  });
  const recorded = record(tasks);
  try {
    localStorage.setItem(KEY, JSON.stringify({ ...saved, [caseId]: recorded }));
  } catch {
    if (strict) throw new Error("任务状态保存失败，请检查浏览器存储后重试。");
    return tasks; // 保存失败时不发布“成功”的日志或评论。
  }
  if (caseItem) caseItem.tasks = recorded;
  revision += 1;
  listeners.forEach((listener) => listener());
  return recorded;
}

// 仅变更选中的执行任务；不联动父节点、子任务或同 Case 的其他任务。
export function respondToCaseTask(caseId: string, taskId: string, response: "accept" | "reject", reason?: string) {
  const caseItem = mockCases.find((item) => item.id === caseId);
  if (!caseItem) throw new Error("Case 不存在。");
  if (isCaseClosed(caseId)) throw new Error("Case 已结案，无法操作任务。");
  const tasks = loadCaseTaskTree(caseId, caseItem.tasks);
  const task = flattenTasks(tasks).find((entry) => entry.task.id === taskId)?.task;
  if (!task?.code || task.owner !== currentUser.name) throw new Error("仅任务负责人可以接受或拒绝任务。");
  if (task.status !== "待接受") throw new Error("任务状态已更新，请刷新后重试。");
  if (response === "reject" && !reason?.trim()) throw new Error("请填写拒绝理由。");
  const status = response === "accept" ? "进行中" : "已拒绝";
  const at = new Date().toISOString();
  const updated: TaskNode = {
    ...task,
    status,
    rejectReason: response === "reject" ? reason!.trim() : undefined,
    statusHistory: [...(task.statusHistory ?? []), { status, at, by: currentUser.name }],
  };
  const patch = (nodes: TaskNode[]): TaskNode[] => nodes.map((node) => node.id === taskId ? updated : { ...node, children: node.children ? patch(node.children) : node.children });
  const next = patch(tasks);
  const saved = saveCaseTaskTree(caseId, next, true);
  return flattenTasks(saved).find((entry) => entry.task.id === taskId)!.task;
}

function findCaseTask(caseId: string, taskId: string) {
  const caseItem = mockCases.find((item) => item.id === caseId);
  if (!caseItem) throw new Error("Case 不存在。");
  const tasks = loadCaseTaskTree(caseId, caseItem.tasks);
  const task = flattenTasks(tasks).find((entry) => entry.task.id === taskId)?.task;
  if (!task?.code) throw new Error("执行任务不存在。");
  return { caseItem, tasks, task };
}

function replaceCaseTask(caseId: string, tasks: TaskNode[], next: TaskNode, waitingChange = false) {
  const replace = (nodes: TaskNode[]): TaskNode[] => nodes.map((node) => node.id === next.id ? next : { ...node, children: node.children ? replace(node.children) : node.children });
  const saved = saveCaseTaskTree(caseId, replace(tasks), true, tasks, waitingChange ? next.id : undefined);
  return flattenTasks(saved).find((entry) => entry.task.id === next.id)!.task;
}

export function caseTaskReadOnlyReason(caseId: string) {
  const item = mockCases.find((candidate) => candidate.id === caseId);
  if (!item) return "Case 不存在。";
  if (isCaseClosed(caseId)) return "Case 已结案，无法操作任务。";
  const approval = getClosure(caseId)?.approval;
  if (approval?.kind === "closure" && !approval.decision) return "Case 结案审批中，无法操作任务。";
  return undefined;
}

export function caseOwnerTaskReopenGrant(actor = currentUser.name) {
  for (const record of allClosureRecords()) {
    const item = mockCases.find(item => item.id === record.caseId);
    const entry = activeRecovery(record);
    if (item?.owner === actor && entry?.kind === "return" && canReturnRecord(item.owner, entry.by) && !caseTaskReadOnlyReason(item.id)) {
      return { caseId: item.id, recoveryId: entry.id };
    }
  }
  return undefined;
}

export function canReopenCaseTask(caseId: string, task: TaskNode, actor = currentUser.name) {
  if (!task.code || activeRecovery(task) || caseTaskReadOnlyReason(caseId)) return false;
  if (!["已完成", "已拒绝", "已中止"].includes(task.status)) return false;
  return Boolean(caseOwnerTaskReopenGrant(actor)) || (task.status === "已完成" && canReopenRecord(task.owner, actor));
}

export function caseReworkDisabledReason(caseId: string, task: TaskNode) {
  return "退回重做已取消。";
}

export function returnCaseTaskForRework(caseId: string, taskId: string, reason: string) {
  throw new Error("退回重做已取消。");
}

export function commentOnCaseTask(caseId: string, taskId: string, content: string, replyTo?: string) {
  const { tasks, task } = findCaseTask(caseId, taskId);
  const comments = addTaskComment(task.comments, content, replyTo);
  return replaceCaseTask(caseId, tasks, { ...task, comments, activityLog: [...(task.activityLog ?? []), taskActivity("comment", replyTo ? "回复评论" : "发表评论")] });
}

export function recoverCaseTask(caseId: string, taskId: string, action: RecoveryAction, text: string, files: RecoveryFile[] = [], dueDate?: string) {
  const { caseItem, tasks, task } = findCaseTask(caseId, taskId);
  if (action !== "supplement" && caseTaskReadOnlyReason(caseId)) throw new Error("请先重新开启所属 Case，再处理任务。");
  const grant = action === "reopen" ? caseOwnerTaskReopenGrant() : undefined;
  if (action === "reopen") {
    if (!canReopenCaseTask(caseId, task)) throw new Error("仅直属主管或当前有待处理 Case 整改的 Owner 可以重新处理符合条件的任务。");
  } else validateRecoveryAction(task.owner, action);
  if (action === "supplement" && task.status !== "已完成") throw new Error("仅已完成任务支持此操作。");
  if (action === "return" && !["进行中", "已完成"].includes(task.status)) throw new Error("当前任务不支持此操作。");
  const next = action === "supplement" ? supplementRecord(task, text, files) : { ...startRecovery(task, action, text, [task.owner, caseItem.owner], dueDate), status: "进行中" as const, progress: 0 };
  if (grant) next.recovery![next.recovery!.length - 1].authorizedByCaseReturn = grant;
  const event = taskActivity(action === "reopen" || action === "return" ? "status" : "edit", { reopen: grant ? "整改 Case Owner 重新开启任务" : "主管确认重新处理", return: "退回整改", supplement: "补充记录" }[action], [], text.trim());
  return replaceCaseTask(caseId, tasks, { ...next, activityLog: [...(task.activityLog ?? []), event] });
}

// 详情中的显式保存走同一条持久化/审计路径，不再只修改 React 内存。
export function updateCaseTask(caseId: string, taskId: string, patch: Partial<TaskNode>, waitingFeedback?: WaitingFeedbackInput) {
  const { caseItem, tasks, task } = findCaseTask(caseId, taskId);
  if (isCaseClosed(caseId)) throw new Error("Case 已结案，无法修改任务。");
  if (task.owner !== currentUser.name && task.supervisor !== currentUser.name) throw new Error("仅任务负责人或分派人可以修改任务。");
  if (!["待接受", "进行中", "等待反馈", "整改中"].includes(task.status)) throw new Error("已结束的任务不支持直接修改，请补充记录或先重新处理。");
  const { id: _id, createdAt: _createdAt, code: _code, children: _children, comments: _comments, activityLog: _log, statusHistory: _history, waitingFeedbackPeriods: _periods, waitingTasks: _waitingTasks, verificationNode: _verificationNode, reworkReason: _rework, recovery: _recovery, caseRemediation: _caseRemediation, ...fields } = patch;
  if (patch.status === "等待反馈") throw new Error("等待反馈状态已取消，请新建等待任务。");
  let next = { ...task, ...fields };
  const remediationContentChanged = Object.entries(fields).some(([key, value]) => !["status", "progress"].includes(key) && JSON.stringify(task[key as keyof TaskNode]) !== JSON.stringify(value));
  if (task.status === "整改中" && remediationContentChanged) {
    const editedAt = task.caseRemediation?.editedAt ?? new Date().toISOString();
    next.caseRemediation = task.caseRemediation ? { ...task.caseRemediation, editedAt } : undefined;
  }

  if (next.status !== task.status) {
    if (task.owner !== currentUser.name) throw new Error("仅任务负责人可以变更状态。");
    const allowed = task.status === "待接受" ? ["进行中", "已拒绝", "已中止"] : task.status === "进行中" ? ["等待反馈", "已完成", "已中止"] : task.status === "等待反馈" ? ["进行中"] : task.status === "整改中" ? ["已完成"] : [];
    if (!allowed.includes(next.status)) throw new Error("当前任务不支持此状态操作。");
    if (task.status === "整改中" && next.status === "已完成" && !next.caseRemediation?.editedAt) throw new Error("请先修改并保存任务内容，再重新提交。");
    if (next.status === "已完成" && !next.conclusion?.trim()) throw new Error("请先填写并保存任务结论。");
    if (next.status === "已中止" && !next.terminateReason?.trim()) throw new Error("请填写中止原因。");
    if (next.status === "已拒绝" && !next.rejectReason?.trim()) throw new Error("请填写拒绝理由。");
    if (next.status === "等待反馈" || task.status === "等待反馈") next = applyWaitingFeedbackTransition({ ...next, status: task.status }, next.status, currentUser.name, waitingFeedback);
    if (task.status === "整改中" && next.status === "已完成" && next.caseRemediation) {
      next.caseRemediation = { ...next.caseRemediation, submittedAt: new Date().toISOString() };
    }
  }
  return replaceCaseTask(caseId, tasks, next);
}

export function createCaseVerificationNode(caseId: string, taskId: string) {
  const reason = caseTaskReadOnlyReason(caseId);
  if (reason) throw new Error(reason);
  const { tasks, task } = findCaseTask(caseId, taskId);
  if (task.owner !== currentUser.name) throw new Error("仅原任务负责人可以添加验证节点。");
  if (!["进行中", "整改中"].includes(task.status)) throw new Error("仅进行中或整改中的任务可以添加验证节点。");
  if (task.verificationNode) return task;
  return replaceCaseTask(caseId, tasks, {
    ...task,
    verificationNode: { id: `verification-${crypto.randomUUID()}`, createdAt: new Date().toISOString() },
  }, true);
}

export function manageCaseWaitingTask(caseId: string, taskId: string, action: WaitingTaskAction) {
  const reason = caseTaskReadOnlyReason(caseId);
  if (reason) throw new Error(reason);
  const { tasks, task } = findCaseTask(caseId, taskId);
  const next = applyWaitingTaskAction(task, action, currentUser.name);
  return replaceCaseTask(caseId, tasks, {
    ...next,
    verificationNode: task.verificationNode ?? { id: `verification-${crypto.randomUUID()}`, createdAt: new Date().toISOString() },
    activityLog: [...(task.activityLog ?? []), taskActivity("edit", action.kind === "create" ? "验证节点下创建特殊任务，原任务计时暂停" : "结束特殊任务，重新计算阻塞关系")],
  }, true);
}

registerCaseReturnTaskHandler((caseId, entry) => {
  if (!entry.dueDate) throw new Error("Case 整改截止时间缺失，无法同步任务。");
  startCaseTaskRemediation(caseId, entry.id, entry.at, entry.dueDate);
});