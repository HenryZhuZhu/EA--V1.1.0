import { Handle, Position } from "@xyflow/react";
import { CheckCheck, Plus, X } from "lucide-react";
import type { WaitingTask } from "./waitingTasks";

export interface VerificationFlowData extends Record<string, unknown> {
  direction: "LR" | "TB";
  canCreate: boolean;
  onCreate: () => void;
  parentTitle: string;
  count: number;
}
export function VerificationFlowNode({ data }: { data: VerificationFlowData }) {
  return <div className="w-[256px] rounded-xl border border-violet-300 bg-violet-50 p-4 shadow-sm" aria-label="验证节点">
    <Handle type="target" position={data.direction === "LR" ? Position.Left : Position.Top} />
    <Handle type="source" position={data.direction === "LR" ? Position.Right : Position.Bottom} />
    <div className="flex items-center gap-2"><b className="text-sm text-violet-900">验证</b><span className="rounded border border-violet-200 bg-white px-2 py-0.5 text-[10px] text-violet-700">特殊思路</span></div>
    <div className="mt-2 truncate text-[10px] text-violet-700" title={data.parentTitle}>原任务：{data.parentTitle}</div>
    <div className="mt-2 text-[10px] text-slate-500">{data.count} 个特殊任务 · 仅支持等待类任务</div>
    {data.canCreate && <button type="button" onClick={data.onCreate} className="nodrag mt-3 inline-flex h-7 items-center gap-1 rounded bg-violet-600 px-3 text-[11px] text-white"><Plus size={12} />新增特殊任务</button>}
  </div>;
}

export interface SpecialTaskFlowData extends Record<string, unknown> {
  direction: "LR" | "TB";
  task: WaitingTask;
  canManage: boolean;
  onComplete: () => void;
  onCancel: () => void;
}
export function SpecialTaskFlowNode({ data }: { data: SpecialTaskFlowData }) {
  const { task } = data;
  return <div className="w-[256px] rounded-xl border border-amber-300 bg-amber-50/90 p-3 shadow-sm" aria-label={`特殊任务：${task.title}`}>
    <Handle type="target" position={data.direction === "LR" ? Position.Left : Position.Top} />
    <div className="flex items-center justify-between"><span className="rounded border border-amber-200 bg-white px-1.5 text-[10px] text-amber-800">特殊任务</span><span className="text-[10px] text-slate-500">{task.status === "已中止" ? "已取消" : task.status}</span></div>
    <h4 className="mt-2 text-xs font-semibold text-amber-950">{task.reason}</h4>
    <p className="mt-1 text-[10px] text-slate-600">任务负责人：{task.owner} · 任务分派人：{task.assignedBy}</p>
    <p className="mt-1 truncate text-[10px] text-slate-500" title={task.description}>{task.description}</p>
    <p className="mt-1 text-[9px] text-slate-500">创建：{new Date(task.createdAt).toLocaleString("zh-CN", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" })}</p>
    {task.result && <p className="mt-1 truncate text-[10px] text-slate-600" title={task.result}>结果：{task.result}</p>}
    {data.canManage && <div className="mt-2 flex gap-2"><button onClick={data.onComplete} className="nodrag inline-flex h-6 items-center gap-1 rounded bg-[#0052D9] px-2 text-[10px] text-white"><CheckCheck size={11} />完成</button><button onClick={data.onCancel} className="nodrag inline-flex h-6 items-center gap-1 rounded border border-amber-300 bg-white px-2 text-[10px]"><X size={11} />取消</button></div>}
  </div>;
}
