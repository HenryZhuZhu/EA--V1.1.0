export type TatInterval = { start: number; end: number };

export function mergeTatIntervals(items: TatInterval[]) {
  const result: TatInterval[] = [];
  items.filter(item => item.end > item.start).sort((a, b) => a.start - b.start).forEach(item => {
    const previous = result.at(-1);
    if (!previous || item.start > previous.end) result.push({ ...item });
    else previous.end = Math.max(previous.end, item.end);
  });
  return result;
}

export function tatIntervalDuration(items: TatInterval[]) {
  return mergeTatIntervals(items).reduce((sum, item) => sum + item.end - item.start, 0);
}

export function subtractTatIntervals(source: TatInterval[], exclusions: TatInterval[]) {
  const blocks = mergeTatIntervals(exclusions);
  return source.flatMap(item => {
    let parts = [item];
    blocks.forEach(block => {
      parts = parts.flatMap(part => block.end <= part.start || block.start >= part.end ? [part] : [
        ...(block.start > part.start ? [{ start: part.start, end: block.start }] : []),
        ...(block.end < part.end ? [{ start: block.end, end: part.end }] : []),
      ]);
    });
    return parts;
  });
}
