export const CASE_IMPACT_OPTIONS = ["客户", "生产", "项目进度", "交付", "良率", "质量", "成本"] as const;
export const GATING_NODE_OPTIONS = ["Tape Out", "EVT", "DVT", "PVT", "MP"] as const;

export function RequiredMultiSelectField({
  label,
  options,
  value,
  onChange,
  compact = false,
}: {
  label: string;
  options: readonly string[];
  value: string[];
  onChange: (value: string[]) => void;
  compact?: boolean;
}) {
  const toggle = (option: string) => {
    onChange(value.includes(option) ? value.filter((item) => item !== option) : [...value, option]);
  };

  return (
    <div className={`min-w-0 text-[11px] text-slate-500 ${compact ? "flex items-center gap-1.5" : ""}`}>
      <span className="shrink-0">{label} <span className="text-red-500">*</span></span>
      <Popover>
        <PopoverTrigger asChild>
          <button type="button" aria-label={`${label}（可多选）`} className={`flex items-center gap-2 rounded border border-slate-200 bg-white text-left outline-none hover:border-[#0052D9]/50 ${compact ? "h-7 w-[132px] px-1.5 text-[11px]" : "mt-1 h-9 w-full px-2.5 text-xs"}`}>
          <span className={`min-w-0 flex-1 truncate ${value.length ? "text-slate-700" : "text-slate-400"}`}>
            {value.length ? value.join("、") : "请选择（可多选）"}
          </span>
            <span className="text-[9px] text-slate-400">▼</span>
          </button>
        </PopoverTrigger>
        <PopoverContent align="start" sideOffset={6} aria-label={`${label}选项`} className="z-[90] w-[220px] p-1.5">
          {options.map((option) => (
            <label key={option} className="flex cursor-pointer items-center gap-2 rounded px-2 py-1.5 text-xs text-slate-600 hover:bg-[#0052D9]/5">
              <input type="checkbox" checked={value.includes(option)} onChange={() => toggle(option)} className="accent-[#0052D9]" />
              <span>{option}</span>
            </label>
          ))}
        </PopoverContent>
      </Popover>
    </div>
  );
}
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
