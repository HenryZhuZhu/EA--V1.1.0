import { Hash, Pencil } from "lucide-react";
import { caseMarkCode } from "./data";

type CaseMarkRef = {
  id?: string;
  code?: string;
  markCode?: string;
  material?: string;
};

// Mark Code 标签：仅当 Case 物料为 Die/IC · DIMM · CAMM 时展示。
export function CaseMarkCodePill({ caseItem, compact = false, onEdit }: { caseItem?: CaseMarkRef | null; compact?: boolean; onEdit?: () => void }) {
  const mc = caseItem ? caseMarkCode(caseItem) : null;
  if (!mc) return null;
  const className = `inline-flex items-center rounded-full border border-amber-200 bg-amber-50 text-amber-700 font-medium shrink-0 whitespace-nowrap ${compact ? "gap-0.5 px-1.5 py-0.5 text-[9px] leading-none" : "gap-1 px-2 py-0.5 text-[10px]"} ${onEdit ? "hover:border-amber-300 hover:bg-amber-100" : ""}`;
  if (onEdit) return (
    <button type="button" onClick={onEdit} title={`编辑 Mark Code：${mc}`} aria-label={`编辑 Mark Code ${mc}`} className={className}>
      <Hash size={compact ? 9 : 10} strokeWidth={2} />
      {mc}
      <Pencil size={compact ? 8 : 9} strokeWidth={2} aria-hidden="true" />
    </button>
  );
  return (
    <span
      title={`Mark Code：${mc}`}
      className={className}
    >
      <Hash size={compact ? 9 : 10} strokeWidth={2} />
      {mc}
    </span>
  );
}
