import { useState } from "react";
import type { TaskNode } from "./data";

export interface CoverageCompletionInput {
  coverageProgramVersion: string;
  coverageTestName: string;
  coverageTestTime: string;
}

export function CompleteCoverageModal({ task, onClose, onConfirm }: {
  task: TaskNode;
  onClose: () => void;
  onConfirm: (input: CoverageCompletionInput) => boolean | void;
}) {
  const [input, setInput] = useState<CoverageCompletionInput>({
    coverageProgramVersion: task.coverageProgramVersion ?? "",
    coverageTestName: task.coverageTestName ?? "",
    coverageTestTime: task.coverageTestTime ?? "",
  });
  const [error, setError] = useState("");
  const ready = Object.values(input).every(value => value.trim());
  const patch = (field: keyof CoverageCompletionInput, value: string) => setInput(current => ({ ...current, [field]: value }));
  const confirm = () => {
    if (!ready) {
      setError("请填写上线名称、上线测试时间和程式版本。");
      return;
    }
    try {
      const accepted = onConfirm({
        coverageProgramVersion: input.coverageProgramVersion.trim(),
        coverageTestName: input.coverageTestName.trim(),
        coverageTestTime: input.coverageTestTime.trim(),
      });
      if (accepted === false) return;
      onClose();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Coverage 任务完成失败，请重试。");
    }
  };
  return <div className="fixed inset-0 z-[155] flex items-center justify-center bg-slate-900/45" onClick={onClose}>
    <section role="dialog" aria-modal="true" aria-label="确认完成 Coverage 任务" className="w-[480px] rounded-xl border border-slate-200 bg-white p-5 shadow-2xl" onClick={event => event.stopPropagation()}>
      <h2 className="text-base font-semibold text-slate-900">确认完成 Coverage 任务</h2>
      <p className="mt-1 text-xs leading-5 text-slate-500">请再次确认本次实际上线信息。默认带入任务已填写内容，可在完成前修改。</p>
      <div className="mt-4 space-y-3">
        <label className="block text-xs text-slate-600">上线名称 <span className="text-red-500">*</span><input autoFocus value={input.coverageTestName} onChange={event => patch("coverageTestName", event.target.value)} placeholder="请输入上线名称" className="mt-1 h-9 w-full rounded-md border border-slate-200 px-3 text-sm outline-none focus:border-cyan-500" /></label>
        <label className="block text-xs text-slate-600">上线测试时间 <span className="text-red-500">*</span><input value={input.coverageTestTime} onChange={event => patch("coverageTestTime", event.target.value)} placeholder="请输入上线测试时间" className="mt-1 h-9 w-full rounded-md border border-slate-200 px-3 text-sm outline-none focus:border-cyan-500" /></label>
        <label className="block text-xs text-slate-600">程式版本 <span className="text-red-500">*</span><input value={input.coverageProgramVersion} onChange={event => patch("coverageProgramVersion", event.target.value)} placeholder="请输入程式版本" className="mt-1 h-9 w-full rounded-md border border-slate-200 px-3 text-sm outline-none focus:border-cyan-500" /></label>
      </div>
      {error && <p role="alert" className="mt-3 rounded-md bg-red-50 px-3 py-2 text-xs text-red-600">{error}</p>}
      <div className="mt-5 flex justify-end gap-2">
        <button type="button" onClick={onClose} className="h-8 rounded-md border border-slate-200 bg-white px-3 text-xs text-slate-600 hover:bg-slate-50">取消</button>
        <button type="button" disabled={!ready} onClick={confirm} className="h-8 rounded-md bg-cyan-600 px-3 text-xs font-medium text-white hover:bg-cyan-700 disabled:opacity-40">确认并完成</button>
      </div>
    </section>
  </div>;
}
