import { AlertTriangle, CheckCircle2, X, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { VoiceInputButton } from "./VoiceInputButton";

interface Props {
  caseCode: string;
  caseName: string;
  initialConclusion?: string;
  onCancel: () => void;
  onSubmit: (result: { decision: "close"; conclusion: string } | { decision: "fail"; reason: string }) => void;
}

export function CloseCaseModal({ caseCode, caseName, initialConclusion, onCancel, onSubmit }: Props) {
  const [conclusion, setConclusion] = useState(initialConclusion ?? "");
  const [decision, setDecision] = useState<"" | "close" | "fail">("close");
  const [failureReason, setFailureReason] = useState("");
  const canSubmit = decision === "close" ? conclusion.trim().length >= 2 : decision === "fail" ? failureReason.trim().length >= 2 : false;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40"
      onClick={onCancel}
    >
      <div
        className="w-[560px] max-w-[95vw] bg-white rounded-lg shadow-xl border border-slate-200 p-5 space-y-4 max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-2">
          <ShieldCheck size={16} className="text-[#00B578]" />
          <h3 className="text-slate-900">Fanout Case 验证结果</h3>
          <span className="text-[11px] px-1.5 py-0.5 rounded-full bg-cyan-50 text-cyan-700 border border-cyan-200">验证中</span>
          <button onClick={onCancel} className="ml-auto text-slate-400 hover:text-slate-600">
            <X size={16} />
          </button>
        </div>

        <div className="text-xs text-slate-600 bg-slate-50 border border-slate-100 rounded p-2.5 leading-relaxed">
          <span className="font-mono text-slate-500">{caseCode}</span>
          <span className="mx-1.5 text-slate-300">·</span>
          <span className="text-slate-800">{caseName}</span>
        </div>

        <div className="rounded-md bg-cyan-50/60 border border-cyan-200 p-2.5 text-xs text-slate-700 leading-relaxed">
          请选择本次方案验证结果。验证通过后直接结案；验证不通过时需填写原因，Case 将返回进行中。
        </div>

        <div className="space-y-4 min-w-0">
          <div className="grid grid-cols-2 gap-2">
            <button type="button" onClick={() => setDecision("close")} className={`rounded-md border p-3 text-left transition-colors ${decision === "close" ? "border-[#00B578] bg-[#00B578]/[0.06] ring-1 ring-[#00B578]/20" : "border-slate-200 hover:border-[#00B578]/40"}`}><span className="flex items-center gap-1.5 text-[13px] font-medium text-slate-800"><CheckCircle2 size={15} className="text-[#00B578]" />验证通过</span><span className="mt-1 block text-[11px] text-slate-500">确认方案有效并结案</span></button>
            <button type="button" onClick={() => setDecision("fail")} className={`rounded-md border p-3 text-left transition-colors ${decision === "fail" ? "border-red-300 bg-red-50 ring-1 ring-red-200" : "border-slate-200 hover:border-red-200"}`}><span className="flex items-center gap-1.5 text-[13px] font-medium text-slate-800"><AlertTriangle size={15} className="text-red-500" />验证不通过</span><span className="mt-1 block text-[11px] text-slate-500">记录原因并返回进行中</span></button>
          </div>
          {decision === "close" && <label className="block text-xs text-slate-600">
            结案结论 <span className="text-red-500">*</span>
            <div className="mt-1 relative">
              <textarea
                autoFocus
                value={conclusion}
                onChange={(e) => setConclusion(e.target.value)}
                placeholder="简要填写验证结果与结案结论"
                className="w-full min-h-[130px] p-2.5 pr-9 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9] leading-relaxed"
              />
              <div className="absolute right-2 top-2">
                <VoiceInputButton
                  size="sm"
                  onTranscript={(t) => setConclusion((p) => (p ? p + " " + t : t))}
                  hint="语音输入结论"
                />
              </div>
            </div>
          </label>}
          {decision === "fail" && <label className="block text-xs text-slate-600">
            验证不通过原因 <span className="text-red-500">*</span>
            <textarea autoFocus value={failureReason} onChange={(event) => setFailureReason(event.target.value)} placeholder="请说明验证现象、未通过原因及后续处理方向" className="mt-1 min-h-[120px] w-full rounded border border-red-200 p-2.5 text-sm leading-relaxed outline-none focus:border-red-400" />
          </label>}

        </div>

        <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
          <button
            onClick={onCancel}
            className="h-8 px-3 text-sm rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50"
          >
            取消
          </button>
          <button
            disabled={!canSubmit}
            onClick={() => decision === "close" ? onSubmit({ decision, conclusion: conclusion.trim() }) : decision === "fail" && onSubmit({ decision, reason: failureReason.trim() })}
            className={`h-8 px-3.5 text-sm rounded-md text-white disabled:opacity-40 inline-flex items-center gap-1 ${decision === "fail" ? "bg-red-600 hover:bg-red-700" : "bg-[#00B578] hover:bg-[#009962]"}`}
          >
            {decision === "fail" ? <><AlertTriangle size={13} /> 确认不通过并返回进行中</> : <><CheckCircle2 size={13} /> 验证通过并结案</>}
          </button>
        </div>
      </div>
    </div>
  );
}
