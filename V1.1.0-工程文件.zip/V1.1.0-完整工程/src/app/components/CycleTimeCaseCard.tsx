import { ChevronDown, FolderOpen } from "lucide-react";
import { useState } from "react";
import { flattenTasks, levelColors, urgencyBar, type CaseItem } from "./data";
import { useClosures } from "./closures";
import { loadCaseTaskTree, useCaseTaskRevision } from "./caseTaskTrees";
import { caseVerificationTimes, formatCaseTime } from "./caseTiming";
import { subtractTatIntervals, tatIntervalDuration, type TatInterval } from "./caseTatMath";
import { CaseProductPill } from "./CaseProductPill";
import { CaseMarkCodePill } from "./CaseMarkCodePill";
import { CaseStatusBadge, caseDisplayStatus } from "./CaseStatusBadge";
import { CaseGanttView } from "./CaseGanttView";

const durationLabel = (ms: number) => ms < 86400000 ? `${(ms / 3600000).toFixed(1)} 小时` : `${(ms / 86400000).toFixed(1)} 天`;
const timestamp = (value?: string) => value && Number.isFinite(Date.parse(value)) ? Date.parse(value) : undefined;

export function CycleTimeCaseCard({ caseItem, expanded, onToggle, onOpenCase, onOpenTask, scopedTaskIds }: {
  caseItem: CaseItem;
  expanded: boolean;
  onToggle: () => void;
  onOpenCase?: (id: string) => void;
  onOpenTask: (caseId: string, taskId: string) => void;
  scopedTaskIds?: string[];
}) {
  const [showAllTasks, setShowAllTasks] = useState(false);
  useCaseTaskRevision();
  const closures = useClosures();
  const closure = closures.get(caseItem.id);
  const taskTree = loadCaseTaskTree(caseItem.id, caseItem.tasks);
  const tasks = flattenTasks(taskTree).map(entry => entry.task).filter(task => Boolean(task.code));
  const visibleTasks = scopedTaskIds && !showAllTasks
    ? tasks.filter(task => scopedTaskIds.includes(task.id)).map(task => ({ ...task, children: undefined }))
    : taskTree;
  const visibleTaskCount = scopedTaskIds && !showAllTasks ? tasks.filter(task => scopedTaskIds.includes(task.id)).length : tasks.length;
  const now = Date.now();
  const end = timestamp(closure?.verificationEndedAt ?? closure?.closedAt) ?? now;
  const verification = caseVerificationTimes(closure);
  const excluded: TatInterval[] = [];
  const addExclusion = (start?: string, finish?: string) => {
    const from = timestamp(start);
    const to = timestamp(finish) ?? end;
    if (from !== undefined && to > from) excluded.push({ start: from, end: to });
  };
  addExclusion(verification.start, verification.end);
  tasks.forEach(task => task.waitingFeedbackPeriods?.filter(period => period.reason === "等待外部反馈").forEach(period => addExclusion(period.startedAt, period.endedAt)));
  const start = timestamp(caseItem.createdAt) ?? timestamp(caseItem.updatedAt);
  const cycleTime = start !== undefined && end >= start
    ? durationLabel(tatIntervalDuration(subtractTatIntervals([{ start, end }], excluded)))
    : "未记录";

  return <div className="bg-white border border-slate-200/80 rounded-xl overflow-hidden shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] transition-shadow hover:shadow-md">
    <div className="flex">
      <div className={`w-1 shrink-0 ${urgencyBar[caseItem.urgency]}`} title={`紧急度：${caseItem.urgency}`} />
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2.5 px-5 pt-3.5 pb-2.5">
          <button aria-label={`展开 ${caseItem.code}`} aria-expanded={expanded} onClick={onToggle} className="grid h-6 w-6 shrink-0 place-items-center rounded text-slate-500 hover:bg-blue-50"><ChevronDown size={14} className={expanded ? "" : "-rotate-90"} /></button>
          <FolderOpen size={15} className="shrink-0 text-[#0052D9]" />
          <span className={`shrink-0 rounded border px-1.5 py-0.5 text-[10px] ${levelColors[caseItem.level]}`}>{caseItem.level}</span>
          <CaseProductPill caseItem={caseItem} compact />
          <CaseMarkCodePill caseItem={caseItem} compact />
          <span className="shrink-0 font-mono text-[11px] text-slate-400">{caseItem.code}</span>
          <button title={caseItem.name} onClick={() => onOpenCase ? onOpenCase(caseItem.id) : onToggle()} className="min-w-[160px] flex-1 truncate text-left text-sm text-slate-800 hover:text-[#0052D9]">{caseItem.name}</button>
          <CaseStatusBadge status={caseDisplayStatus(caseItem, { closed: closure?.state === "closed", rootCaused: closure?.state === "rootcause" })} />
          <div className="w-[120px] shrink-0 text-right"><div className="text-[10px] text-slate-400">Cycle Time</div><div className="mt-1 text-sm font-semibold tabular-nums text-[#0052D9]">{cycleTime}</div></div>
        </div>
        <div className="flex flex-wrap gap-x-5 gap-y-2 pb-3.5 pl-[52px] pr-5 text-[11px] text-slate-500">
          <span>Case Owner · {caseItem.owner}</span><span>创建人 · {caseItem.createdBy || "未记录"}</span>
          <span>创建日期 · {formatCaseTime(caseItem.createdAt)}</span>
          <span>协作者 · {caseItem.participants?.map(person => person.name).join("、") || "—"}</span><span>{tasks.length} 任务</span>
        </div>
      </div>
    </div>
    {expanded && <section className="min-w-0 border-t border-slate-100 bg-slate-50/60 p-4">
      {scopedTaskIds && <div className="mb-3 flex items-center gap-3"><div className="inline-flex gap-1 rounded-md bg-slate-100 p-1">{[{ all: false, label: "当前部门任务" }, { all: true, label: "全部任务" }].map(option => <button key={option.label} aria-pressed={showAllTasks === option.all} onClick={() => setShowAllTasks(option.all)} className={`h-7 rounded px-3 text-xs ${showAllTasks === option.all ? "bg-white font-medium text-[#0052D9] shadow-sm" : "text-slate-500"}`}>{option.label}</button>)}</div><span className="text-[11px] text-slate-400">{visibleTaskCount} / {tasks.length} 个任务</span></div>}
      <CaseGanttView caseItem={caseItem} tasks={visibleTasks} tasksOnly onTaskClick={taskId => onOpenTask(caseItem.id, taskId)} />
    </section>}
  </div>;
}
