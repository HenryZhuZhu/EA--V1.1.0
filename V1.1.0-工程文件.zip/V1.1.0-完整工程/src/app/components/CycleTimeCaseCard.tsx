import { ChevronDown, FolderOpen } from "lucide-react";
import { useEffect, useState } from "react";
import { flattenTasks, levelColors, urgencyBar, type CaseItem } from "./data";
import { useClosures } from "./closures";
import { loadCaseTaskTree, useCaseTaskRevision } from "./caseTaskTrees";
import { formatCaseTime } from "./caseTiming";
import { caseCycleMetrics, DEPARTMENT_ROLE_LABELS, type DepartmentRelation } from "./departmentAnalytics";
import { CaseProductPill } from "./CaseProductPill";
import { CaseMarkCodePill } from "./CaseMarkCodePill";
import { CaseStatusBadge, caseDisplayStatus } from "./CaseStatusBadge";
import { CaseGanttView } from "./CaseGanttView";

const durationLabel = (ms: number) => ms < 86400000 ? `${(ms / 3600000).toFixed(1)} 小时` : `${(ms / 86400000).toFixed(1)} 天`;

export function CycleTimeCaseCard({ caseItem, expanded, onToggle, onOpenCase, onOpenTask, scopedTaskIds, departmentInfo, calculationTime }: {
  caseItem: CaseItem;
  expanded: boolean;
  onToggle: () => void;
  onOpenCase?: (id: string) => void;
  onOpenTask: (caseId: string, taskId: string) => void;
  scopedTaskIds?: string[];
  departmentInfo?: { relations: DepartmentRelation[]; cycleTime: number | null; totalCycleTime: number | null; taskCount: number; timingIssues?: string[] };
  calculationTime?: number;
}) {
  const [showAllTasks, setShowAllTasks] = useState(false);
  useCaseTaskRevision();
  const closures = useClosures();
  const closure = closures.get(caseItem.id);
  const taskTree = loadCaseTaskTree(caseItem.id, caseItem.tasks);
  const tasks = flattenTasks(taskTree).map(entry => entry.task).filter(task => Boolean(task.code));
  const visibleTasks = scopedTaskIds && !showAllTasks
    ? tasks.filter(task => scopedTaskIds.includes(task.id)).map(task => ({ ...task, children: undefined }))
    : taskTree;
  const visibleTaskCount = scopedTaskIds && !showAllTasks ? tasks.filter(task => scopedTaskIds.includes(task.id)).length : tasks.length;
  const [now, setNow] = useState(Date.now);
  useEffect(() => { const timer = setInterval(() => setNow(Date.now()), 60000); return () => clearInterval(timer); }, []);
  const metrics = caseCycleMetrics(caseItem, closure, calculationTime ?? now);
  const cycleTime = metrics.effective === null ? "未记录" : durationLabel(metrics.effective);

  return <div className="bg-white border border-slate-200/80 rounded-xl overflow-hidden shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] transition-shadow hover:shadow-md">
    <div className="flex">
      <div className={`w-1 shrink-0 ${urgencyBar[caseItem.urgency]}`} title={`紧急度：${caseItem.urgency}`} />
      <div className="min-w-0 flex-1">
        <div data-case-summary-row="primary" className="flex h-12 items-center gap-2 whitespace-nowrap px-4">
          <button aria-label={`展开 ${caseItem.code}`} aria-expanded={expanded} onClick={onToggle} className="grid h-6 w-6 shrink-0 place-items-center rounded text-slate-500 hover:bg-blue-50"><ChevronDown size={14} className={expanded ? "" : "-rotate-90"} /></button>
          <FolderOpen size={15} className="shrink-0 text-[#0052D9]" />
          <span className={`shrink-0 rounded border px-1.5 py-0.5 text-[10px] ${levelColors[caseItem.level]}`}>{caseItem.level}</span>
          <div className="flex max-w-[150px] min-w-0 items-center gap-1 overflow-hidden"><CaseProductPill caseItem={caseItem} compact /><CaseMarkCodePill caseItem={caseItem} compact /></div>
          <span className="shrink-0 font-mono text-[11px] text-slate-400">{caseItem.code}</span>
          <button title={caseItem.name} onClick={() => onOpenCase ? onOpenCase(caseItem.id) : onToggle()} className="min-w-0 flex-1 truncate text-left text-sm text-slate-800 hover:text-[#0052D9]">{caseItem.name}</button>
          <CaseStatusBadge status={caseDisplayStatus(caseItem, { closed: closure?.state === "closed", rootCaused: closure?.state === "rootcause" })} />
          <div className="ml-auto flex shrink-0 items-center gap-3 text-[10px] text-right">
            <span title={`Case 创建至${metrics.closed ? "结案" : "当前（累计）"}的完整历时，不扣等待`} className="text-slate-400">Case 总 Cycle Time · <b className="text-xs tabular-nums text-slate-700">{metrics.total === null ? "未记录" : durationLabel(metrics.total)}</b></span>
            <span title="Case 总 Cycle Time 扣除明确记录的 Case 级验证等待区间，不扣单个任务的验证等待" className="text-slate-400">Case 有效 Cycle Time · <b className="text-xs tabular-nums text-[#0052D9]">{cycleTime}</b></span>
          </div>
        </div>
        <div data-case-summary-row="secondary" className="flex h-10 items-center gap-3 whitespace-nowrap border-t border-slate-100 pl-[48px] pr-4 text-[10px] text-slate-500">
          <div className="flex min-w-0 flex-1 items-center gap-3 overflow-x-auto" tabIndex={0} aria-label="Case 人员与日期信息">
          <span>Case Owner · {caseItem.owner}</span><span>创建人 · {caseItem.createdBy || "未记录"}</span>
          <span>创建日期 · {formatCaseTime(caseItem.createdAt)}</span>
          {departmentInfo?.timingIssues?.length ? <span className="text-amber-700" title={departmentInfo.timingIssues.join("\n")}>时间记录需核对 · {departmentInfo.timingIssues.length} 项</span> : null}
          <span>协作者 · {caseItem.participants?.map(person => person.name).join("、") || "—"}</span><span>{tasks.length} 任务</span>
          <span title="仅指明确记录的 Case 级验证等待区间的并集，不包含任务级验证等待">Case 级等待验证时长 · {metrics.excluded === null ? "未记录" : durationLabel(metrics.excluded)}</span>
        {departmentInfo && <>
          <span className="text-slate-400">本部门关系</span>
          {[...new Set(departmentInfo.relations.map(relation => relation.role))].map(role => <span key={role} title={[...new Set(departmentInfo.relations.filter(relation => relation.role === role).map(relation => relation.name))].join("、")} className="rounded border border-blue-200 bg-blue-50 px-2 py-0.5 text-[#0052D9]">{DEPARTMENT_ROLE_LABELS[role]}</span>)}
          <span className="ml-auto text-slate-500">本部门普通任务 · {departmentInfo.taskCount}</span>
        </>}
          </div>
        {departmentInfo && <div className="flex shrink-0 items-center gap-3">
          <span className="text-slate-500" title="本部门普通任务的完整区间合并去重，包含等待，不含无任务的空档">本部门总 Cycle Time · <b className="text-slate-700">{departmentInfo.totalCycleTime === null ? "—" : durationLabel(departmentInfo.totalCycleTime)}</b></span>
          <span className="text-slate-500" title="本部门各普通任务先扣自身阻塞，再合并有效区间；仅有关联身份不产生处理时间">本部门有效 Cycle Time · <b className="text-[#0052D9]">{departmentInfo.cycleTime === null ? "—" : durationLabel(departmentInfo.cycleTime)}</b></span>
        </div>}
        </div>
      </div>
    </div>
    {expanded && <section className="min-w-0 border-t border-slate-100 bg-slate-50/60 p-4">
      {scopedTaskIds && <div className="mb-3 flex items-center gap-3"><div className="inline-flex gap-1 rounded-md bg-slate-100 p-1">{[{ all: false, label: "当前部门任务" }, { all: true, label: "全部任务" }].map(option => <button key={option.label} aria-pressed={showAllTasks === option.all} onClick={() => setShowAllTasks(option.all)} className={`h-7 rounded px-3 text-xs ${showAllTasks === option.all ? "bg-white font-medium text-[#0052D9] shadow-sm" : "text-slate-500"}`}>{option.label}</button>)}</div><span className="text-[11px] text-slate-400">{visibleTaskCount} / {tasks.length} 个任务</span></div>}
      <CaseGanttView caseItem={caseItem} tasks={visibleTasks} tasksOnly showVerificationTasks onTaskClick={taskId => onOpenTask(caseItem.id, taskId)} />
    </section>}
  </div>;
}
