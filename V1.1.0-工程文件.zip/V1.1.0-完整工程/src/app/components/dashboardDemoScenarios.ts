import type { CaseItem, TaskNode } from "./data";
import type { ClosureRecord } from "./closures";

const date = (day: number) => `2026-09-${String(day).padStart(2, "0")}T09:00:00+08:00`;
function task(id: string, department: string, owner: string, start: number, end: number, wait?: [number, number]): TaskNode {
  return {
    id, code: id, title: `${department} ${wait ? "验证结果分析" : "阶段处理"}`, department, owner, supervisor: "张伟",
    urgency: "一般", status: "已完成", progress: 100, type: "通用", createdAt: date(start), dueDate: date(end).slice(0, 10),
    conclusion: "阶段结果已确认", statusHistory: [{ status: "进行中", at: date(start) }, { status: "已完成", at: date(end) }],
    ...(wait ? {
      verificationNode: { id: `${id}-verification`, createdAt: date(wait[0]) },
      waitingTasks: [{ id: `${id}-wait`, parentTaskId: id, title: "等待内部验证", reason: "等待内部验证" as const,
        owner: "李娜", assignedBy: owner, description: "独立验证期间暂停原任务，其他部门照常推进",
        createdAt: date(wait[0]), endedAt: date(wait[1]), endedBy: "李娜", status: "已完成" as const, result: "验证通过" }],
    } : {}),
  };
}
const specs = [
  { id: "cycle-serial", code: "EA-260901000091", name: "部门串行交接 · 两天等待", start: 1, end: 14, verify: 12,
    tasks: [task("serial-pte", "PTE", "张伟", 3, 8, [4, 6]), task("serial-cp", "CP", "王芳", 8, 12)] },
  { id: "cycle-parallel", code: "EA-260905000092", name: "跨部门并行 · 各自等待", start: 5, end: 20, verify: 18,
    tasks: [task("parallel-pte", "PTE", "刘洋", 7, 16, [9, 12]), task("parallel-ft", "FT", "赵敏", 10, 18)] },
  { id: "cycle-gap", code: "EA-260902000093", name: "同部门分段处理 · 空档不累计", start: 2, end: 23, verify: 21,
    tasks: [task("gap-pte-a", "PTE", "张伟", 4, 7), task("gap-pte-b", "PTE", "刘洋", 15, 19, [16, 18]), task("gap-cp", "CP", "王芳", 7, 12)] },
  { id: "cycle-creator", code: "EA-260906000094", name: "PTE 仅创建 · 无部门任务归属", start: 6, end: 16, verify: 14,
    tasks: [task("creator-da", "DA", "李娜", 8, 14)] },
];
export const dashboardDemoScenarios: { caseItem: CaseItem; closure: ClosureRecord }[] = specs.map((spec, index) => ({
  caseItem: {
    id: spec.id, code: spec.code, name: spec.name, owner: index === 3 ? "李娜" : "张伟", createdBy: "张伟",
    participants: [{ name: "陈磊", department: "EFA" }], level: "L2", urgency: "一般", status: "已关闭",
    reason: "部门周期核对示例", background: spec.name, impact: "模拟数据", levelReason: "周期核对",
    product: index % 2 ? "LPDDR5-7500" : "DDR5-X-6400", material: "Die/IC", density: "16Gb", ioType: "x8",
    failStage: "CP", customer: "演示客户", failPlatform: "演示平台", failMode: "周期对照", ppm: "—", pdId: "—",
    createdAt: date(spec.start), updatedAt: date(spec.end), dueDate: date(spec.end).slice(0, 10), dueIn: 0,
    departments: [...new Set(spec.tasks.map(t => t.department))], tasks: spec.tasks.map(t => ({ ...t, code: `${spec.code}.${spec.tasks.indexOf(t) + 1}` })),
    source: "手动", aiSummary: { progress: "已结案", method: "阶段对照", conclusion: "验证通过", solution: "归档", risk: "无" },
    timeline: [{ time: date(spec.start), user: "张伟", content: "创建示例" }, { time: date(spec.verify), user: "张伟", content: "开始 Case 验证" }, { time: date(spec.end), user: "张伟", content: "结案" }],
  },
  closure: { caseId: spec.id, state: "closed", closedAt: date(spec.end), verificationStartedAt: date(spec.verify), verificationEndedAt: date(spec.end) },
}));

export function demoTaskTimeSignature(task: TaskNode) {
  return JSON.stringify({
    status: task.status, createdAt: task.createdAt, statusHistory: task.statusHistory,
    dueDate: task.dueDate, requestedDueDate: task.requestedDueDate,
    activityLog: task.activityLog, recovery: task.recovery, waitingTasks: task.waitingTasks,
    waitingFeedbackPeriods: task.waitingFeedbackPeriods,
  });
}
