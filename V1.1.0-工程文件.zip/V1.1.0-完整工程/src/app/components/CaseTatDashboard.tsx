import { useEffect, useMemo, useState, type ReactNode } from "react";
import { ChevronDown, ChevronRight, Filter, Search } from "lucide-react";
import { currentUser, flattenTasks, mockCases, mockProducts, ownerToDepartment, urgencyBar } from "./data";
import { StatusBadge } from "./StatusBadge";
import { tatIntervalDuration } from "./caseTatMath";
import { activeWaitingTasks, waitingTaskTiming } from "./waitingTasks";
import { useClosures } from "./closures";
import { loadCaseTaskTree, useCaseTaskRevision } from "./caseTaskTrees";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { CASE_FILTER_PANEL_CLASS_NAME } from "./CaseFilterPanel";
import { CASE_LEVEL_OPTIONS, CASE_URGENCY_OPTIONS } from "./CaseFilterFields";
import { ProductPicker } from "./ProductPicker";
import { CycleTimeCaseCard } from "./CycleTimeCaseCard";
import { caseDisplayStatus } from "./CaseStatusBadge";
import {
  departmentCaseRecord, departmentPath, departmentScope, departmentTreeFor, summarizeDepartment, departmentRelations,
  type DepartmentNode,
} from "./departmentAnalytics";

type PersonRole = "owner" | "creator" | "collaborator" | "taskOwner";
const ROLES: { value: PersonRole; label: string }[] = [
  { value: "owner", label: "作为 Case Owner" }, { value: "creator", label: "作为创建人" },
  { value: "collaborator", label: "作为协作者" }, { value: "taskOwner", label: "作为任务负责人" },
];
const formatDuration = (value: number | null) => value === null ? "—"
  : value < 86400000 ? `${(value / 3600000).toFixed(1)} 小时` : `${(value / 86400000).toFixed(1)} 天`;

export function CaseTatDashboard({ onOpenCase, onOpenTask }: {
  onOpenCase?: (id: string) => void;
  onOpenTask: (caseId: string, taskId: string) => void;
}) {
  const closures = useClosures();
  const revision = useCaseTaskRevision();
  const [now, setNow] = useState(Date.now);
  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 60000);
    return () => window.clearInterval(timer);
  }, []);
  const taskRecords = useMemo(() => mockCases.map(caseItem => ({
    caseItem, tasks: flattenTasks(loadCaseTaskTree(caseItem.id, caseItem.tasks)).map(entry => entry.task).filter(task => Boolean(task.code)),
  })), [revision]);
  const tree = useMemo(() => departmentTreeFor([...Object.values(ownerToDepartment), ...taskRecords.flatMap(record => [
    ...record.tasks.map(task => task.department || "未记录部门"),
    ...(record.caseItem.participants ?? []).map(person => person.department),
  ])].filter(Boolean)), [taskRecords]);
  const [selected, setSelected] = useState("test");
  const [openNodes, setOpenNodes] = useState<string[]>(["test", "PTE", "pte-product"]);
  const [query, setQuery] = useState("");
  const [expandedCases, setExpandedCases] = useState<string[]>([]);
  const [selectedProducts, setSelectedProducts] = useState<string[]>([]);
  const [status, setStatus] = useState("全部");
  const [personRoles, setPersonRoles] = useState<PersonRole[]>(ROLES.map(role => role.value));
  const [level, setLevel] = useState("全部");
  const [urgency, setUrgency] = useState("全部");
  const [filterOpen, setFilterOpen] = useState(false);
  const [detailTab, setDetailTab] = useState<"case" | "task" | "waiting">("case");
  const [period, setPeriod] = useState<"all" | "closed" | "open">("all");
  const scope = departmentScope(tree, selected, true);
  const path = departmentPath(tree, selected);
  const current = path[path.length - 1];
  const directChildren = tree.filter(node => node.parentId === selected);
  const records = taskRecords.filter(({ caseItem: item }) => {
    const closure = closures.get(item.id);
    const displayStatus = caseDisplayStatus(item, { closed: closure?.state === "closed", rootCaused: closure?.state === "rootcause" });
    return (!selectedProducts.length || selectedProducts.some(id => {
      const product = mockProducts.find(candidate => candidate.id === id);
      return item.productIds?.includes(id) || item.productId === id || item.product === id || item.product === product?.code || item.product === product?.name;
    }))
      && (status === "全部" || caseDisplayStatus(item, { closed: closure?.state === "closed", rootCaused: closure?.state === "rootcause" }) === status)
      && (period === "all" || (period === "closed" ? displayStatus === "已结案" : displayStatus !== "已结案"))
      && (level === "全部" || item.level === level)
      && (urgency === "全部" || item.urgency === urgency);
  }).map(({ caseItem, tasks }) => departmentCaseRecord(caseItem, tasks, closures.get(caseItem.id), now, ownerToDepartment));
  const summary = summarizeDepartment(records, scope, personRoles);
  const detailTasks = summary.cases.flatMap(record => record.tasks.filter(task => scope.has(task.departmentId)).map(task => ({ ...task, caseItem: record.caseItem })));
  const waitingDetails = detailTasks.flatMap(item => (item.task.waitingTasks ?? []).map(wait => ({ ...item, wait })));
  const activeFilterCount = [status, level, urgency].filter(value => value !== "全部").length
    + Number(selectedProducts.length > 0) + Number(personRoles.length !== ROLES.length);
  const resetFilters = () => {
    setSelectedProducts([]); setStatus("全部"); setPersonRoles(ROLES.map(role => role.value)); setLevel("全部"); setUrgency("全部");
  };
  const selectDepartment = (id: string) => {
    setSelected(id);
    setOpenNodes(previous => [...new Set([...previous, ...departmentPath(tree, id).map(node => node.id)])]);
    setExpandedCases([]);
  };
  const renderBranch = (parentId: string | null, depth = 0): ReactNode => tree.filter(node => node.parentId === parentId).map(node => {
    const hasChildren = tree.some(child => child.parentId === node.id);
    const open = openNodes.includes(node.id);
    return <div key={node.id}>
      <div className={`my-0.5 flex min-h-9 items-center rounded-md ${selected === node.id ? "bg-blue-50 text-[#0052D9]" : "text-slate-600 hover:bg-slate-50"}`} style={{ paddingLeft: depth * 14 }}>
        {hasChildren ? <button type="button" aria-label={`展开${node.name}`} aria-expanded={open} onClick={() => setOpenNodes(previous => open ? previous.filter(id => id !== node.id) : [...previous, node.id])} className="grid h-7 w-6 shrink-0 place-items-center text-slate-400"><ChevronRight size={13} className={open ? "rotate-90" : ""} /></button> : <span className="w-6 shrink-0" />}
        <button type="button" aria-current={selected === node.id ? "true" : undefined} onClick={() => selectDepartment(node.id)} className="min-w-0 flex-1 truncate py-2 pr-2 text-left text-xs">{node.name}</button>
      </div>
      {hasChildren && open && renderBranch(node.id, depth + 1)}
    </div>;
  });
  const statRow = (node: DepartmentNode, isSummary = false) => {
    const data = isSummary ? summary : summarizeDepartment(records, departmentScope(tree, node.id, true), personRoles);
    return <tr key={node.id} className={isSummary ? "bg-blue-50/60 font-medium" : "border-t border-slate-100"}>
      <td className="px-4 py-3">{isSummary ? `${node.name} 汇总` : node.name}</td>
      <td className="px-4 py-3 tabular-nums">{data.count}</td>
      <td className="px-4 py-3 tabular-nums" title={`有效计时 Case：${data.sampleCount} 个`}>{data.processingCount}</td>
      <td className="px-4 py-3 tabular-nums">{formatDuration(data.totalAverage)}</td>
      <td className="px-4 py-3 tabular-nums">{formatDuration(data.totalMedian)}</td>
      <td className="px-4 py-3 tabular-nums text-[#0052D9]">{formatDuration(data.average)}</td>
      <td className="px-4 py-3 tabular-nums text-[#0052D9]">{formatDuration(data.median)}</td>
      <td className="border-l border-slate-100 px-4 py-3 tabular-nums" title={`有效计时任务：${data.taskSampleCount} 个`}>{data.taskCount}</td>
      <td className="px-4 py-3 tabular-nums text-[#0052D9]">{formatDuration(data.taskAverage)}</td>
      <td className="px-4 py-3 tabular-nums text-[#0052D9]">{formatDuration(data.taskMedian)}</td>
    </tr>;
  };

  return <div className="grid grid-cols-[240px_minmax(0,1fr)] items-start gap-5">
    <aside aria-label="部门组织树" className="sticky top-4 max-h-[calc(100vh-140px)] overflow-auto rounded-xl border border-slate-200 bg-white p-3">
      <div className="mb-4 flex items-center justify-between px-2"><h3 className="text-sm font-semibold">部门组织树</h3><span className="text-[10px] text-slate-400">{tree.length} 个部门</span></div>
      <div className="relative mb-3"><Search size={13} className="absolute left-2.5 top-2.5 text-slate-400" /><input aria-label="搜索部门名称" placeholder="搜索部门名称" value={query} onChange={event => setQuery(event.target.value)} className="h-8 w-full rounded-md border border-slate-200 bg-white pl-8 pr-2 text-xs outline-none focus:border-[#0052D9]" /></div>
      {query.trim() ? tree.filter(node => node.name.toLowerCase().includes(query.trim().toLowerCase())).map(node => <button key={node.id} onClick={() => selectDepartment(node.id)} className={`block w-full rounded-md px-2 py-2 text-left text-xs hover:bg-blue-50 ${selected === node.id ? "bg-blue-50 text-[#0052D9]" : ""}`}><span>{node.name}</span><span className="mt-1 block text-[10px] text-slate-400">{departmentPath(tree, node.id).map(item => item.name).join(" / ")}</span></button>) : renderBranch(null)}
      {query.trim() && !tree.some(node => node.name.toLowerCase().includes(query.trim().toLowerCase())) && <div className="py-8 text-center text-xs text-slate-400">未找到匹配部门</div>}
    </aside>
    <div className="min-w-0 space-y-4">
      <section className="overflow-hidden rounded-xl border border-slate-200 bg-white">
        <header className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 px-4 py-3"><h4 className="text-sm font-semibold">部门分析</h4>
        <div className="inline-flex rounded-md bg-slate-100 p-1" aria-label="Case 统计范围">{([{ value: "all", label: "全部 Case" }, { value: "closed", label: "已结案" }, { value: "open", label: "未结案 · 累计" }] as const).map(option => <button key={option.value} aria-pressed={period === option.value} onClick={() => setPeriod(option.value)} className={`rounded px-3 py-1 text-xs ${period === option.value ? "bg-white text-[#0052D9] shadow-sm" : "text-slate-500"}`}>{option.label}</button>)}</div>
        <Popover open={filterOpen} onOpenChange={setFilterOpen}>
          <PopoverTrigger asChild><button className={`inline-flex h-9 items-center gap-1.5 rounded-lg border px-3 text-xs ${filterOpen || activeFilterCount ? "border-[#0052D9]/40 bg-blue-50 text-[#0052D9]" : "border-slate-200 bg-white text-slate-600"}`}><Filter size={13} />筛选{activeFilterCount > 0 && <span className="rounded-full bg-[#0052D9] px-1.5 text-[10px] text-white">{activeFilterCount}</span>}<ChevronDown size={13} /></button></PopoverTrigger>
          <PopoverContent align="end" sideOffset={8} aria-label="Cycle Time Case 筛选" className={CASE_FILTER_PANEL_CLASS_NAME} onInteractOutside={event => { if (event.target instanceof Element && event.target.closest("[data-product-picker-panel]")) event.preventDefault(); }}>
            <div className="min-h-0 overflow-y-auto p-4"><p className="mb-3 text-[11px] text-slate-400">筛选维度</p><div className="grid grid-cols-2 gap-3">
              <fieldset className="col-span-2"><legend className="mb-2 text-xs text-slate-500">人员身份</legend><div className="grid grid-cols-2 gap-2">{ROLES.map(({ value, label }) => <label key={value} className="flex items-center gap-2 text-xs text-slate-600"><input type="checkbox" checked={personRoles.includes(value)} onChange={event => setPersonRoles(previous => event.target.checked ? [...previous, value] : previous.filter(role => role !== value))} />{label}</label>)}</div></fieldset>
              <div className="min-w-0"><div className="mb-1 text-xs text-slate-500">产品</div><ProductPicker multiple value={selectedProducts} onChange={setSelectedProducts} placeholder="全部产品" /></div>
              <label className="text-xs text-slate-500">状态<select aria-label="Case 状态" value={status} onChange={event => setStatus(event.target.value)} className="mt-1 h-8 w-full rounded-md border border-slate-200 bg-white px-2">{["全部", "进行中", "验证中", "暂存", "已结案"].map(value => <option key={value}>{value}</option>)}</select></label>
              <label className="text-xs text-slate-500">层级<select aria-label="Case 层级" value={level} onChange={event => setLevel(event.target.value)} className="mt-1 h-8 w-full rounded-md border border-slate-200 bg-white px-2">{CASE_LEVEL_OPTIONS.map(value => <option key={value}>{value}</option>)}</select></label>
              <label className="text-xs text-slate-500">紧急程度<select aria-label="Case 紧急程度" value={urgency} onChange={event => setUrgency(event.target.value)} className="mt-1 h-8 w-full rounded-md border border-slate-200 bg-white px-2">{CASE_URGENCY_OPTIONS.map(value => <option key={value}>{value}</option>)}</select></label>
            </div></div>
            <div className="flex justify-between border-t border-slate-100 px-4 py-3"><button onClick={resetFilters} className="text-xs text-slate-500">重置全部</button><button onClick={() => setFilterOpen(false)} className="h-8 rounded-lg bg-[#0052D9] px-4 text-xs text-white">完成</button></div>
          </PopoverContent>
        </Popover>
        </header>
        <div className="overflow-x-auto"><table aria-label="部门 Cycle Time 统计" className="w-full min-w-[1660px] text-left text-xs"><thead className="whitespace-nowrap bg-slate-50 text-[11px] text-slate-500">
          <tr>
            <th scope="col" className="min-w-[160px] px-4 py-3 font-medium">部门</th>
            <th scope="col" className="px-4 py-3 font-medium" title="本部门人员以所选身份关联的 Case，按 ID 去重">相关 Case 数</th>
            <th scope="col" className="px-4 py-3 font-medium">实际处理 Case 数</th>
            <th scope="col" className="px-4 py-3 font-medium" title="按 Case 合并本部门普通任务完整区间，含等待、重叠去重，再按 Case 求平均">本部门总 Cycle Time · 平均</th>
            <th scope="col" className="px-4 py-3 font-medium" title="与总 Cycle Time 平均值使用同一组 Case 样本">本部门总 Cycle Time · 中位数</th>
            <th scope="col" className="px-4 py-3 font-medium" title="各普通任务先扣自身阻塞，再按 Case 合并有效区间，最后按 Case 求平均">本部门有效 Cycle Time · 平均</th>
            <th scope="col" className="px-4 py-3 font-medium" title="与有效 Cycle Time 平均值使用同一组 Case 样本">本部门有效 Cycle Time · 中位数</th>
            <th scope="col" className="border-l border-slate-200 px-4 py-3 font-medium">普通任务数</th>
            <th scope="col" className="px-4 py-3 font-medium" title="普通任务扣除自身阻塞后按任务求平均，不含验证特殊任务">任务平均 Cycle Time</th>
            <th scope="col" className="px-4 py-3 font-medium" title="普通任务扣除自身阻塞后按任务取中位数，不含验证特殊任务">任务中位数 Cycle Time</th>
          </tr>
        </thead><tbody>{statRow(current, true)}{directChildren.map(node => statRow(node))}</tbody></table></div>
        {summary.sampleCount < summary.processingCount && <div className="border-t border-slate-100 px-4 py-2 text-[10px] text-slate-400">{summary.processingCount - summary.sampleCount} 个实际处理 Case 缺少有效任务时间，不计入均值与中位数。</div>}
      </section>
      <div className="inline-flex gap-1 rounded-lg bg-slate-100 p-1">{([{ value: "case", label: `Case 明细 · ${summary.count}` }, { value: "task", label: `普通任务明细 · ${detailTasks.length}` }, { value: "waiting", label: `验证等待明细 · ${waitingDetails.length}` }] as const).map(tab => <button key={tab.value} aria-pressed={detailTab === tab.value} onClick={() => setDetailTab(tab.value)} className={`rounded-md px-3 py-2 text-xs ${detailTab === tab.value ? "bg-white font-medium text-[#0052D9] shadow-sm" : "text-slate-500"}`}>{tab.label}</button>)}</div>
      {detailTab === "case" && <div className="space-y-3">{summary.cases.map(record => {
        const local = summarizeDepartment([record], scope, personRoles);
        return <CycleTimeCaseCard key={`${selected}/${record.caseItem.id}`} caseItem={record.caseItem} calculationTime={now} expanded={expandedCases.includes(record.caseItem.id)} onToggle={() => setExpandedCases(previous => previous.includes(record.caseItem.id) ? previous.filter(id => id !== record.caseItem.id) : [...previous, record.caseItem.id])} onOpenCase={onOpenCase} onOpenTask={onOpenTask} scopedTaskIds={record.tasks.filter(task => scope.has(task.departmentId)).map(task => task.task.id)} departmentInfo={{ relations: departmentRelations(record, scope), cycleTime: local.average, totalCycleTime: local.totalAverage, taskCount: local.taskCount, timingIssues: record.tasks.filter(task => scope.has(task.departmentId) && task.timingIssue).map(task => `${task.task.title}：${task.timingIssue}`) }} />;
      })}</div>}
      {detailTab === "task" && <section aria-label="普通任务列表" className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
        <div className="min-w-[800px]">
          <div className="flex items-center gap-3 border-b border-slate-100 bg-slate-50 py-2.5 pl-6 pr-5 text-[11px] text-slate-500">
            <span className="w-24 shrink-0">状态</span><span className="min-w-0 flex-1">普通任务 / 所属 Case</span><span className="w-40 shrink-0">任务负责人</span><span className="w-28 shrink-0 text-right">任务 Cycle Time</span>
          </div>
          <div className="divide-y divide-slate-100/70">{detailTasks.map(({ task, caseItem, intervals, timingIssue }) => <div key={`${caseItem.id}/${task.id}`} data-department-task={task.id} title={timingIssue || `紧急度：${task.urgency}`} className="group relative flex items-center gap-3 py-2.5 pl-6 pr-5 transition-colors hover:bg-slate-50/60">
            <div className={`absolute bottom-1.5 left-0 top-1.5 w-[3px] rounded-r ${urgencyBar[task.urgency]}`} />
            <div className="w-24 shrink-0"><span className="inline-flex items-center gap-1.5 text-[11px] text-slate-500"><StatusBadge status={task.status} size={16} />{task.status}</span>{activeWaitingTasks(task).length > 0 && <span className="mt-1 block text-[10px] text-amber-700">计时暂停</span>}</div>
            <div className="min-w-0 flex-1">
              <button onClick={() => onOpenTask(caseItem.id, task.id)} title={task.title} className="block w-full truncate text-left text-sm text-slate-800 hover:text-[#0052D9]">{task.title}</button>
              {timingIssue && <span className="text-[10px] text-amber-700">时间记录需核对</span>}
              <button onClick={() => onOpenCase?.(caseItem.id)} disabled={!onOpenCase} title={`${caseItem.code} · ${caseItem.name}`} className="mt-0.5 block w-full truncate text-left text-[11px] text-slate-400 enabled:hover:text-[#0052D9]">{caseItem.code} · {caseItem.name}</button>
            </div>
            <div className="flex w-40 shrink-0 items-center gap-1.5 text-xs text-slate-600">
              <span className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[10px] font-medium ${!task.owner || ["待指派", "待分派"].includes(task.owner) ? "bg-slate-100 text-slate-400" : "bg-[#0052D9]/8 text-[#0052D9]"}`}>{!task.owner || ["待指派", "待分派"].includes(task.owner) ? "—" : task.owner[0]}</span>
              <span className="truncate" title={`${task.department} · ${task.owner}`}>{task.department} · {task.owner}</span>
              {task.owner === currentUser.name && <span className="shrink-0 rounded border border-slate-200 px-1 text-[10px] text-slate-400">我</span>}
            </div>
            <span className="w-28 shrink-0 whitespace-nowrap text-right text-xs tabular-nums text-[#0052D9]">{formatDuration(intervals === null ? null : tatIntervalDuration(intervals))}</span>
          </div>)}</div>
        </div>
        {!detailTasks.length && <div className="p-10 text-center text-xs text-slate-400">相关 Case 中暂无本部门普通任务</div>}
      </section>}
      {detailTab === "waiting" && <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white"><table className="w-full text-left text-xs"><thead className="bg-slate-50 text-slate-500"><tr>{["特殊任务类型", "原任务 / Case", "任务负责人", "状态", "开始 / 结束时间", "等待验证时长"].map(label => <th key={label} className="px-3 py-3 font-medium">{label}</th>)}</tr></thead><tbody>{waitingDetails.map(item => <tr key={`${item.caseItem.id}/${item.wait.id}`} className="border-t border-slate-100"><td className="px-3 py-3">{item.wait.reason}</td><td className="px-3 py-3"><button onClick={() => onOpenCase?.(item.caseItem.id)} className="text-left text-[#0052D9]">{item.task.title}</button><span className="block text-[10px] text-slate-400">{item.caseItem.code}</span></td><td className="px-3 py-3">{item.wait.owner}</td><td className="px-3 py-3">{item.wait.status === "已中止" ? "已取消" : item.wait.status}</td><td className="px-3 py-3 text-[10px]">{new Date(item.wait.createdAt).toLocaleString("zh-CN")}<br />{item.wait.endedAt ? new Date(item.wait.endedAt).toLocaleString("zh-CN") : item.wait.status === "进行中" ? "等待中" : "未记录"}</td><td className="whitespace-nowrap px-3 py-3">{formatDuration(waitingTaskTiming(item.wait, now)?.duration ?? null)}</td></tr>)}</tbody></table>{!waitingDetails.length && <div className="p-10 text-center text-xs text-slate-400">本部门任务暂无验证等待记录</div>}</div>}
      {!summary.count && <div className="rounded-xl border border-dashed border-slate-300 bg-white py-12 text-center text-xs text-slate-400">当前范围暂无 Case，请切换部门或重置筛选。</div>}
    </div>
  </div>;
}
