import { useEffect, useMemo, useState, type ReactNode } from "react";
import { ChevronDown, ChevronRight, Filter, Search } from "lucide-react";
import { flattenTasks, mockCases, mockProducts, type CaseItem } from "./data";
import { useClosures } from "./closures";
import { loadCaseTaskTree, useCaseTaskRevision } from "./caseTaskTrees";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { CASE_FILTER_PANEL_CLASS_NAME } from "./CaseFilterPanel";
import { CASE_LEVEL_OPTIONS, CASE_URGENCY_OPTIONS } from "./CaseFilterFields";
import { ProductPicker } from "./ProductPicker";
import { CycleTimeCaseCard } from "./CycleTimeCaseCard";
import { caseDisplayStatus } from "./CaseStatusBadge";
import {
  departmentCaseRecord, departmentPath, departmentScope, departmentTreeFor, summarizeDepartment,
  type DepartmentNode,
} from "./departmentAnalytics";

type PersonRole = "owner" | "creator" | "collaborator" | "taskOwner";
const ROLES: { value: PersonRole; label: string }[] = [
  { value: "owner", label: "作为 Case Owner" }, { value: "creator", label: "作为创建人" },
  { value: "collaborator", label: "作为协作者" }, { value: "taskOwner", label: "作为任务负责人" },
];
const formatDuration = (value: number | null) => value === null ? "—"
  : value < 86400000 ? `${(value / 3600000).toFixed(1)} 小时` : `${(value / 86400000).toFixed(1)} 天`;

export function CaseTatDashboard({ onOpenCase, onOpenTask }: {
  onOpenCase?: (id: string) => void;
  onOpenTask: (caseId: string, taskId: string) => void;
}) {
  const closures = useClosures();
  const revision = useCaseTaskRevision();
  const [now, setNow] = useState(Date.now);
  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 60000);
    return () => window.clearInterval(timer);
  }, []);
  const taskRecords = useMemo(() => mockCases.map(caseItem => ({
    caseItem, tasks: flattenTasks(loadCaseTaskTree(caseItem.id, caseItem.tasks)).map(entry => entry.task).filter(task => Boolean(task.code)),
  })), [revision]);
  const tree = useMemo(() => departmentTreeFor(taskRecords.flatMap(record => record.tasks.map(task => task.department || "未记录部门"))), [taskRecords]);
  const [selected, setSelected] = useState("test");
  const [openNodes, setOpenNodes] = useState<string[]>(["test", "PTE", "pte-product"]);
  const [query, setQuery] = useState("");
  const [expandedCases, setExpandedCases] = useState<string[]>([]);
  const [selectedProducts, setSelectedProducts] = useState<string[]>([]);
  const [status, setStatus] = useState("全部");
  const [personRoles, setPersonRoles] = useState<PersonRole[]>(ROLES.map(role => role.value));
  const [level, setLevel] = useState("全部");
  const [urgency, setUrgency] = useState("全部");
  const [filterOpen, setFilterOpen] = useState(false);
  const scope = departmentScope(tree, selected, true);
  const path = departmentPath(tree, selected);
  const current = path[path.length - 1];
  const directChildren = tree.filter(node => node.parentId === selected);
  const records = taskRecords.filter(({ caseItem: item, tasks }) => {
    const closure = closures.get(item.id);
    const roles: Record<PersonRole, boolean> = {
      owner: Boolean(item.owner), creator: Boolean(item.createdBy || item.owner),
      collaborator: Boolean(item.participants?.length),
      taskOwner: tasks.some(task => task.owner && !["待指派", "待分派"].includes(task.owner)),
    };
    return (!selectedProducts.length || selectedProducts.some(id => {
      const product = mockProducts.find(candidate => candidate.id === id);
      return item.productIds?.includes(id) || item.productId === id || item.product === id || item.product === product?.code || item.product === product?.name;
    }))
      && (status === "全部" || caseDisplayStatus(item, { closed: closure?.state === "closed", rootCaused: closure?.state === "rootcause" }) === status)
      && personRoles.some(role => roles[role])
      && (level === "全部" || item.level === level)
      && (urgency === "全部" || item.urgency === urgency);
  }).map(({ caseItem, tasks }) => departmentCaseRecord(caseItem, tasks, closures.get(caseItem.id), now));
  const summary = summarizeDepartment(records, scope);
  const activeFilterCount = [status, level, urgency].filter(value => value !== "全部").length
    + Number(selectedProducts.length > 0) + Number(personRoles.length !== ROLES.length);
  const resetFilters = () => {
    setSelectedProducts([]); setStatus("全部"); setPersonRoles(ROLES.map(role => role.value)); setLevel("全部"); setUrgency("全部");
  };
  const selectDepartment = (id: string) => {
    setSelected(id);
    setOpenNodes(previous => [...new Set([...previous, ...departmentPath(tree, id).map(node => node.id)])]);
    setExpandedCases([]);
  };
  const renderBranch = (parentId: string | null, depth = 0): ReactNode => tree.filter(node => node.parentId === parentId).map(node => {
    const hasChildren = tree.some(child => child.parentId === node.id);
    const open = openNodes.includes(node.id);
    return <div key={node.id}>
      <div className={`my-0.5 flex min-h-9 items-center rounded-md ${selected === node.id ? "bg-blue-50 text-[#0052D9]" : "text-slate-600 hover:bg-slate-50"}`} style={{ paddingLeft: depth * 14 }}>
        {hasChildren ? <button type="button" aria-label={`展开${node.name}`} aria-expanded={open} onClick={() => setOpenNodes(previous => open ? previous.filter(id => id !== node.id) : [...previous, node.id])} className="grid h-7 w-6 shrink-0 place-items-center text-slate-400"><ChevronRight size={13} className={open ? "rotate-90" : ""} /></button> : <span className="w-6 shrink-0" />}
        <button type="button" aria-current={selected === node.id ? "true" : undefined} onClick={() => selectDepartment(node.id)} className="min-w-0 flex-1 truncate py-2 pr-2 text-left text-xs">{node.name}</button>
      </div>
      {hasChildren && open && renderBranch(node.id, depth + 1)}
    </div>;
  });
  const statRow = (node: DepartmentNode, isSummary = false) => {
    const data = isSummary ? summary : summarizeDepartment(records, departmentScope(tree, node.id, true));
    return <tr key={node.id} className={isSummary ? "bg-blue-50/60 font-medium" : "border-t border-slate-100"}>
      <td className="px-4 py-3">{isSummary ? `${node.name} 汇总` : node.name}</td>
      <td className="px-4 py-3 tabular-nums">{data.count}</td>
      <td className="px-4 py-3 tabular-nums text-[#0052D9]">{formatDuration(data.average)}</td>
      <td className="px-4 py-3 tabular-nums text-[#0052D9]">{formatDuration(data.median)}</td>
    </tr>;
  };

  return <div className="grid grid-cols-[240px_minmax(0,1fr)] items-start gap-5">
    <aside aria-label="部门组织树" className="sticky top-4 max-h-[calc(100vh-140px)] overflow-auto rounded-xl border border-slate-200 bg-white p-3">
      <div className="mb-4 flex items-center justify-between px-2"><h3 className="text-sm font-semibold">部门组织树</h3><span className="text-[10px] text-slate-400">{tree.length} 个部门</span></div>
      <div className="relative mb-3"><Search size={13} className="absolute left-2.5 top-2.5 text-slate-400" /><input aria-label="搜索部门名称" placeholder="搜索部门名称" value={query} onChange={event => setQuery(event.target.value)} className="h-8 w-full rounded-md border border-slate-200 bg-white pl-8 pr-2 text-xs outline-none focus:border-[#0052D9]" /></div>
      {query.trim() ? tree.filter(node => node.name.toLowerCase().includes(query.trim().toLowerCase())).map(node => <button key={node.id} onClick={() => selectDepartment(node.id)} className={`block w-full rounded-md px-2 py-2 text-left text-xs hover:bg-blue-50 ${selected === node.id ? "bg-blue-50 text-[#0052D9]" : ""}`}><span>{node.name}</span><span className="mt-1 block text-[10px] text-slate-400">{departmentPath(tree, node.id).map(item => item.name).join(" / ")}</span></button>) : renderBranch(null)}
      {query.trim() && !tree.some(node => node.name.toLowerCase().includes(query.trim().toLowerCase())) && <div className="py-8 text-center text-xs text-slate-400">未找到匹配部门</div>}
    </aside>
    <div className="min-w-0 space-y-4">
      <section className="overflow-hidden rounded-xl border border-slate-200 bg-white">
        <header className="flex items-center justify-between border-b border-slate-100 px-4 py-3"><h4 className="text-sm font-semibold">部门 Cycle Time</h4>
        <Popover open={filterOpen} onOpenChange={setFilterOpen}>
          <PopoverTrigger asChild><button className={`inline-flex h-9 items-center gap-1.5 rounded-lg border px-3 text-xs ${filterOpen || activeFilterCount ? "border-[#0052D9]/40 bg-blue-50 text-[#0052D9]" : "border-slate-200 bg-white text-slate-600"}`}><Filter size={13} />筛选{activeFilterCount > 0 && <span className="rounded-full bg-[#0052D9] px-1.5 text-[10px] text-white">{activeFilterCount}</span>}<ChevronDown size={13} /></button></PopoverTrigger>
          <PopoverContent align="end" sideOffset={8} aria-label="Cycle Time Case 筛选" className={CASE_FILTER_PANEL_CLASS_NAME} onInteractOutside={event => { if (event.target instanceof Element && event.target.closest("[data-product-picker-panel]")) event.preventDefault(); }}>
            <div className="min-h-0 overflow-y-auto p-4"><p className="mb-3 text-[11px] text-slate-400">筛选维度</p><div className="grid grid-cols-2 gap-3">
              <fieldset className="col-span-2"><legend className="mb-2 text-xs text-slate-500">人员身份</legend><div className="grid grid-cols-2 gap-2">{ROLES.map(({ value, label }) => <label key={value} className="flex items-center gap-2 text-xs text-slate-600"><input type="checkbox" checked={personRoles.includes(value)} onChange={event => setPersonRoles(previous => event.target.checked ? [...previous, value] : previous.filter(role => role !== value))} />{label}</label>)}</div></fieldset>
              <div className="min-w-0"><div className="mb-1 text-xs text-slate-500">产品</div><ProductPicker multiple value={selectedProducts} onChange={setSelectedProducts} placeholder="全部产品" /></div>
              <label className="text-xs text-slate-500">状态<select aria-label="Case 状态" value={status} onChange={event => setStatus(event.target.value)} className="mt-1 h-8 w-full rounded-md border border-slate-200 bg-white px-2">{["全部", "进行中", "验证中", "暂存", "已结案"].map(value => <option key={value}>{value}</option>)}</select></label>
              <label className="text-xs text-slate-500">层级<select aria-label="Case 层级" value={level} onChange={event => setLevel(event.target.value)} className="mt-1 h-8 w-full rounded-md border border-slate-200 bg-white px-2">{CASE_LEVEL_OPTIONS.map(value => <option key={value}>{value}</option>)}</select></label>
              <label className="text-xs text-slate-500">紧急程度<select aria-label="Case 紧急程度" value={urgency} onChange={event => setUrgency(event.target.value)} className="mt-1 h-8 w-full rounded-md border border-slate-200 bg-white px-2">{CASE_URGENCY_OPTIONS.map(value => <option key={value}>{value}</option>)}</select></label>
            </div></div>
            <div className="flex justify-between border-t border-slate-100 px-4 py-3"><button onClick={resetFilters} className="text-xs text-slate-500">重置全部</button><button onClick={() => setFilterOpen(false)} className="h-8 rounded-lg bg-[#0052D9] px-4 text-xs text-white">完成</button></div>
          </PopoverContent>
        </Popover>
        </header>
        <table aria-label="部门 Cycle Time 统计" className="w-full table-fixed text-left text-xs"><thead className="bg-slate-50 text-[11px] text-slate-500"><tr><th className="w-[40%] px-4 py-2 font-medium">部门</th><th className="px-4 py-2 font-medium">Case 数</th><th className="px-4 py-2 font-medium">平均 Cycle Time</th><th className="px-4 py-2 font-medium">中位数 Cycle Time</th></tr></thead><tbody>{statRow(current, true)}{directChildren.map(node => statRow(node))}</tbody></table>
        {summary.sampleCount < summary.count && <div className="border-t border-slate-100 px-4 py-2 text-[10px] text-slate-400">{summary.count - summary.sampleCount} 个 Case 缺少有效任务时间，不计入均值与中位数。</div>}
      </section>
      <div className="flex items-center gap-3"><h4 className="text-sm font-semibold">Case 列表</h4><span className="text-[11px] text-slate-400">{summary.count} 个 Case</span></div>
      <div className="space-y-3">{summary.cases.map(record => <CycleTimeCaseCard key={`${selected}/${record.caseItem.id}`} caseItem={record.caseItem} expanded={expandedCases.includes(record.caseItem.id)} onToggle={() => setExpandedCases(previous => previous.includes(record.caseItem.id) ? previous.filter(id => id !== record.caseItem.id) : [...previous, record.caseItem.id])} onOpenCase={onOpenCase} onOpenTask={onOpenTask} scopedTaskIds={record.tasks.filter(task => scope.has(task.departmentId)).map(task => task.task.id)} />)}</div>
      {!summary.count && <div className="rounded-xl border border-dashed border-slate-300 bg-white py-12 text-center text-xs text-slate-400">当前范围暂无 Case，请切换部门或重置筛选。</div>}
    </div>
  </div>;
}
