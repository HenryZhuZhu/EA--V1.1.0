import type { TaskNode, WaitingFeedbackPeriod } from "./data";
import { subtractTatIntervals, tatIntervalDuration, type TatInterval } from "./caseTatMath";

export const WAIT_TASK_REASONS = ["等待外部反馈", "等待内部验证", "等待借机"] as const;
export type WaitTaskReason = typeof WAIT_TASK_REASONS[number];
export interface WaitingTask {
  id: string;
  parentTaskId: string;
  title: string;
  reason: WaitTaskReason | "其他等待事项";
  description: string;
  owner: string;
  assignedBy: string;
  createdAt: string;
  dueDate?: string;
  status: "进行中" | "已完成" | "已中止";
  endedAt?: string;
  endedBy?: string;
  result?: string;
  legacyPeriodId?: string;
}
export interface WaitingTaskInput { reason: WaitTaskReason; description: string; owner: string; dueDate?: string }
export type WaitingTaskAction = { kind: "create"; input: WaitingTaskInput } | { kind: "complete" | "cancel"; id: string; result: string };
export interface WaitingTaskRecord {
  id: string; owner: string; status: string; waitingTasks?: WaitingTask[]; waitingFeedbackPeriods?: WaitingFeedbackPeriod[];
}
export class WaitingTaskMigrationError extends Error {}
export function waitingTaskTiming(task: WaitingTask, now = Date.now()) {
  const start = Date.parse(task.createdAt);
  const end = task.status === "进行中" && !task.endedAt ? now : Date.parse(task.endedAt ?? "");
  return Number.isFinite(start) && Number.isFinite(end) && end >= start
    ? { start, end, duration: end - start } : null;
}
export function activeWaitingTasks(record: Pick<WaitingTaskRecord, "status" | "waitingTasks">) {
  return ["进行中", "整改中"].includes(record.status) ? (record.waitingTasks ?? []).filter(task => task.status === "进行中" && !task.endedAt) : [];
}
export function isTaskWaiting(record: Pick<WaitingTaskRecord, "status" | "waitingTasks">) {
  return activeWaitingTasks(record).length > 0;
}

// 老等待时间保留原起点。历史已结束区间仍留在 periods 中，不重复转换为新任务。
export function migrateWaitingTasks<T extends WaitingTaskRecord>(record: T): T {
  if (record.status !== "等待反馈") return record;
  const periods = record.waitingFeedbackPeriods ?? [];
  const open = periods.filter(period => !period.endedAt);
  if (!open.length) throw new WaitingTaskMigrationError(`任务 ${record.id} 的旧等待开始时间缺失，无法迁移，请补充等待记录。`);
  const waitingTasks = [...(record.waitingTasks ?? [])];
  open.forEach(period => {
    if (!Number.isFinite(Date.parse(period.startedAt))) throw new WaitingTaskMigrationError(`任务 ${record.id} 的等待开始时间无效。`);
    if (waitingTasks.some(task => task.legacyPeriodId === period.id)) return;
    waitingTasks.push({
      id: `wait-${record.id}-${period.id}`, parentTaskId: record.id, title: period.reason ?? "等待外部反馈",
      reason: period.reason ?? "等待外部反馈", description: period.description || "由旧等待记录迁移",
      owner: record.owner, assignedBy: period.startedBy, createdAt: period.startedAt, status: "进行中", legacyPeriodId: period.id,
    });
  });
  return { ...record, status: "进行中", waitingTasks };
}

export function applyWaitingTaskAction<T extends WaitingTaskRecord>(record: T, action: WaitingTaskAction, actor: string, now = new Date().toISOString()): T {
  if (!Number.isFinite(Date.parse(now))) throw new Error("操作时间无效。");
  if (!["进行中", "整改中"].includes(record.status)) throw new Error("原任务已结束或尚未开始，不能操作等待任务。");
  const tasks = [...(record.waitingTasks ?? [])];
  if (action.kind === "create") {
    if (actor !== record.owner) throw new Error("仅原任务负责人可以新建阻塞型等待任务。");
    const input = action.input;
    if (!WAIT_TASK_REASONS.includes(input.reason) || !input.description.trim() || !input.owner.trim()) throw new Error("请选择等待类型、任务负责人并填写说明。");
    if (input.description.trim().length > 500) throw new Error("等待说明不能超过 500 个字符。");
    if (input.dueDate && !Number.isFinite(Date.parse(input.dueDate))) throw new Error("预计完成日期无效。");
    tasks.push({
      id: `wait-${crypto.randomUUID()}`, parentTaskId: record.id, title: input.reason, reason: input.reason,
      description: input.description.trim(), owner: input.owner.trim(), assignedBy: actor, createdAt: now,
      dueDate: input.dueDate, status: "进行中",
    });
  } else {
    const index = tasks.findIndex(task => task.id === action.id);
    const task = tasks[index];
    if (!task || task.status !== "进行中" || task.endedAt) throw new Error("等待任务已结束或不存在，请刷新后重试。");
    if (actor !== task.owner && actor !== record.owner) throw new Error("仅等待任务负责人或原任务负责人可以结束等待任务。");
    if (!action.result.trim()) throw new Error(action.kind === "cancel" ? "请填写取消原因。" : "请填写等待任务的完成结果。");
    if (Date.parse(now) < Date.parse(task.createdAt)) throw new Error("结束时间不能早于等待开始时间。");
    tasks[index] = { ...task, status: action.kind === "complete" ? "已完成" : "已中止", endedAt: now, endedBy: actor, result: action.result.trim() };
  }
  const periods = record.waitingFeedbackPeriods?.map(period => {
    const task = tasks.find(task => task.legacyPeriodId === period.id);
    return task?.endedAt ? { ...period, endedAt: task.endedAt, endedBy: task.endedBy } : period;
  });
  return { ...record, waitingTasks: tasks, waitingFeedbackPeriods: periods };
}

export function endWaitingTasksWithParent<T extends WaitingTaskRecord>(record: T, actor: string, now: string): T {
  if (!["已完成", "已拒绝", "已中止"].includes(record.status)) return record;
  const tasks = (record.waitingTasks ?? []).map(task => task.status === "进行中" && !task.endedAt
    ? { ...task, status: "已中止" as const, endedAt: now, endedBy: actor, result: "原任务已结束，自动解除阻塞" } : task);
  return {
    ...record, waitingTasks: tasks,
    waitingFeedbackPeriods: record.waitingFeedbackPeriods?.map(period => !period.endedAt ? { ...period, endedAt: now, endedBy: actor } : period),
  };
}

export function taskBlockingIntervals(record: Pick<TaskNode, "waitingTasks" | "waitingFeedbackPeriods">, end: number): TatInterval[] {
  const tasks = record.waitingTasks ?? [];
  const migrated = new Set(tasks.map(task => task.legacyPeriodId).filter(Boolean));
  const raw = [
    ...tasks.map(task => ({ start: task.createdAt, end: task.endedAt })),
    ...(record.waitingFeedbackPeriods ?? []).filter(period => !migrated.has(period.id)).map(period => ({ start: period.startedAt, end: period.endedAt })),
  ];
  return raw.flatMap(period => {
    const start = Date.parse(period.start);
    const finish = period.end ? Date.parse(period.end) : end;
    return Number.isFinite(start) && Number.isFinite(finish) && finish > start ? [{ start, end: Math.min(finish, end) }] : [];
  });
}

export function taskEffectiveCycleMs(record: Pick<TaskNode, "waitingTasks" | "waitingFeedbackPeriods">, start: number, end: number) {
  return tatIntervalDuration(subtractTatIntervals([{ start, end }], taskBlockingIntervals(record, end)));
}
