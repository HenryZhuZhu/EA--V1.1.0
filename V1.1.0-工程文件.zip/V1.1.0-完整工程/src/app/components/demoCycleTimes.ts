import type { ClosureRecord } from "./closures";

// 显式演示事件，不在读取时将更新时间或当前时间推断为结束时间。
export const DEMO_TASK_END_TIMES: Record<string, string> = {
  "c001/t3c": "2026-09-23T16:00:00+08:00",
  "c002/t23": "2026-09-21T16:00:00+08:00",
  "c004/t41": "2026-09-15T17:00:00+08:00",
  "c-complex-hierarchy-demo/complex-task-16": "2026-09-12T17:00:00+08:00",
  "vp-recovery-example-5/vp-recovery-example-5-verify": "2026-09-21T10:00:00+08:00",
  "vp-recovery-example-6/vp-recovery-example-6-verify": "2026-09-20T15:30:00+08:00",
};

export const DEMO_CASE_CLOSURES: Record<string, ClosureRecord> = {
  c6: { caseId: "c6", state: "closed", closedAt: "2026-09-09T09:30:00+08:00", verificationStartedAt: "2026-09-08T09:30:00+08:00", verificationEndedAt: "2026-09-09T09:30:00+08:00" },
  c7: { caseId: "c7", state: "closed", closedAt: "2026-10-10T08:10:00+08:00", verificationStartedAt: "2026-10-08T08:10:00+08:00", verificationEndedAt: "2026-10-10T08:10:00+08:00" },
  c14: { caseId: "c14", state: "closed", closedAt: "2026-10-03T15:00:00+08:00", verificationStartedAt: "2026-10-01T15:00:00+08:00", verificationEndedAt: "2026-10-03T15:00:00+08:00" },
  "c-cycle-demo": { caseId: "c-cycle-demo", state: "closed", closedAt: "2026-09-12T09:00:00+08:00", verificationStartedAt: "2026-09-10T09:00:00+08:00", verificationEndedAt: "2026-09-12T09:00:00+08:00" },
};
