import type { CaseItem, TaskNode } from "./data";
import { taskBlockingIntervals } from "./waitingTasks";
import { caseVerificationTimes } from "./caseTiming";
import { caseCycleRange, taskCaseRange } from "./cycleTimeRanges";
import type { ClosureRecord } from "./closures";
import { mergeTatIntervals, subtractTatIntervals, tatIntervalDuration, type TatInterval } from "./caseTatMath";

export interface DepartmentNode { id: string; name: string; parentId: string | null }
export const DEPARTMENT_TREE: DepartmentNode[] = [
  { id: "test", name: "测试中心", parentId: null },
  ...["PTE", "CP", "FT", "DA", "SLT"].map(name => ({ id: name, name, parentId: "test" })),
  { id: "pte-product", name: "产品测试组", parentId: "PTE" },
  { id: "pte-ddr", name: "DDR 测试小组", parentId: "pte-product" },
  { id: "pte-lpddr", name: "LPDDR 测试小组", parentId: "pte-product" },
  { id: "pte-dev", name: "测试开发组", parentId: "PTE" },
  { id: "quality", name: "工艺与质量中心", parentId: null },
  ...["PE", "QA", "EFA", "PKG"].map(name => ({ id: name, name, parentId: "quality" })),
  { id: "design", name: "设计与项目中心", parentId: null },
  ...["RD", "PM"].map(name => ({ id: name, name, parentId: "design" })),
];

// 已确认方案的细分组织演示归属，不修改任务原有的一级业务部门。
const DEMO_TASK_DEPARTMENTS: Record<string, string> = {
  "c001/t1": "pte-ddr",
  "c001/t1b": "pte-dev",
  "c001/t1c": "pte-product",
  "c001/t1c_r2": "pte-dev",
  "c001/t3c": "PTE",
};

export function taskDepartmentId(caseId: string, task: TaskNode) {
  return (task.department === "PTE" && DEMO_TASK_DEPARTMENTS[`${caseId}/${task.id}`]) || task.department || "未记录部门";
}

export function departmentTreeFor(departments: string[]): DepartmentNode[] {
  const known = new Set(DEPARTMENT_TREE.map(node => node.id));
  const unknown = [...new Set(departments)].filter(name => !known.has(name));
  return [...DEPARTMENT_TREE, ...(unknown.length ? [
    { id: "__other", name: "其他组织", parentId: null },
    ...unknown.map(name => ({ id: name, name, parentId: "__other" })),
  ] : [])];
}

export function departmentScope(tree: DepartmentNode[], id: string, includeChildren: boolean): Set<string> {
  const result = new Set([id]);
  if (includeChildren) tree.filter(node => node.parentId === id).forEach(child => {
    departmentScope(tree, child.id, true).forEach(value => result.add(value));
  });
  return result;
}

export function departmentPath(tree: DepartmentNode[], id: string): DepartmentNode[] {
  const node = tree.find(item => item.id === id);
  return node ? [...(node.parentId ? departmentPath(tree, node.parentId) : []), node] : [];
}

export interface DepartmentCaseRecord {
  caseItem: CaseItem;
  tasks: { task: TaskNode; departmentId: string; intervals: TatInterval[] | null; totalIntervals?: TatInterval[] | null; timingIssue?: string }[];
  relations?: DepartmentRelation[];
}
export type DepartmentRole = "owner" | "creator" | "collaborator" | "taskOwner";
export const DEPARTMENT_ROLE_LABELS: Record<DepartmentRole, string> = { owner: "Owner", creator: "创建人", collaborator: "协作者", taskOwner: "任务负责人" };
export interface DepartmentRelation { role: DepartmentRole; name: string; departmentId: string }
export function departmentRelations(record: DepartmentCaseRecord, scope: Set<string>) {
  return (record.relations ?? []).filter(relation => scope.has(relation.departmentId));
}

function timestamp(value?: string | null) {
  const parsed = Date.parse(value ?? "");
  return Number.isFinite(parsed) ? parsed : undefined;
}

export function departmentCaseRecord(caseItem: CaseItem, tasks: TaskNode[], closure?: ClosureRecord, now = Date.now(), directory: Record<string, string> = {}): DepartmentCaseRecord {
  const relations: DepartmentRelation[] = [];
  const add = (role: DepartmentRole, name?: string, departmentId?: string) => {
    if (name && !["待指派", "待分派"].includes(name) && departmentId) relations.push({ role, name, departmentId });
  };
  add("owner", caseItem.owner, directory[caseItem.owner]);
  add("creator", caseItem.createdBy, caseItem.createdBy ? directory[caseItem.createdBy] : undefined);
  caseItem.participants?.forEach(person => add("collaborator", person.name, person.department || directory[person.name]));
  tasks.filter(task => task.code).forEach(task => add("taskOwner", task.owner, taskDepartmentId(caseItem.id, task)));
  return {
    caseItem,
    relations,
    tasks: tasks.filter(task => Boolean(task.code)).map(task => {
      const range = taskCaseRange(caseItem, task, closure, now);
      const waits = taskBlockingIntervals(task, range.interval?.end ?? now);
      return {
        task, departmentId: taskDepartmentId(caseItem.id, task),
        timingIssue: range.issue,
        totalIntervals: range.interval ? [range.interval] : null,
        intervals: range.interval
          ? subtractTatIntervals([range.interval], waits)
          : null,
      };
    }),
  };
}

export function medianCycleTime(values: number[]) {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

export function summarizeDepartment(records: DepartmentCaseRecord[], scope: Set<string>, roles: DepartmentRole[] = ["owner", "creator", "collaborator", "taskOwner"]) {
  const related = new Map<string, DepartmentCaseRecord>();
  const grouped = new Map<string, { record: DepartmentCaseRecord; intervals: TatInterval[]; totalIntervals: TatInterval[]; hasTime: boolean }>();
  const taskValues = new Map<string, number | null>();
  records.forEach(record => {
    const matches = record.relations
      ? departmentRelations(record, scope).some(relation => roles.includes(relation.role))
      : roles.includes("taskOwner") && record.tasks.some(task => scope.has(task.departmentId));
    if (!matches) return;
    related.set(record.caseItem.id, record);
    const tasks = record.tasks.filter(task => scope.has(task.departmentId));
    if (!tasks.length) return;
    const current = grouped.get(record.caseItem.id) ?? { record, intervals: [], totalIntervals: [], hasTime: false };
    tasks.forEach(task => {
      taskValues.set(`${record.caseItem.id}/${task.task?.id ?? task.departmentId}`, task.intervals === null ? null : tatIntervalDuration(task.intervals));
      if (task.intervals !== null) {
        current.hasTime = true;
        current.intervals.push(...task.intervals);
        current.totalIntervals.push(...(task.totalIntervals ?? task.intervals));
      }
    });
    grouped.set(record.caseItem.id, current);
  });
  const samples = [...grouped.values()].filter(item => item.hasTime)
    .map(item => tatIntervalDuration(mergeTatIntervals(item.intervals)));
  const totalSamples = [...grouped.values()].filter(item => item.hasTime)
    .map(item => tatIntervalDuration(mergeTatIntervals(item.totalIntervals)));
  const taskSamples = [...taskValues.values()].filter((value): value is number => value !== null);
  return {
    cases: [...related.values()], count: related.size, processingCount: grouped.size, sampleCount: samples.length,
    average: samples.length ? samples.reduce((sum, value) => sum + value, 0) / samples.length : null,
    median: samples.length ? medianCycleTime(samples) : null,
    totalAverage: totalSamples.length ? totalSamples.reduce((sum, value) => sum + value, 0) / totalSamples.length : null,
    totalMedian: totalSamples.length ? medianCycleTime(totalSamples) : null,
    taskCount: taskValues.size, taskSampleCount: taskSamples.length,
    taskAverage: taskSamples.length ? taskSamples.reduce((sum, value) => sum + value, 0) / taskSamples.length : null,
    taskMedian: taskSamples.length ? medianCycleTime(taskSamples) : null,
  };
}

export function caseCycleMetrics(caseItem: CaseItem, closure?: ClosureRecord, now = Date.now()) {
  const { closed, interval } = caseCycleRange(caseItem, closure, now);
  if (!interval) return { total: null, effective: null, excluded: null, closed };
  const { start, end } = interval;
  const verification = caseVerificationTimes(closure);
  const verificationStart = timestamp(verification.start);
  const verificationEnd = timestamp(verification.end) ?? (closure?.state === "rootcause" ? end : undefined);
  const exclusions = verificationStart !== undefined && verificationEnd !== undefined && verificationEnd > verificationStart
    ? [{ start: verificationStart, end: verificationEnd }] : [];
  closure?.verificationHistory?.forEach(entry => {
    const from = timestamp(entry.startedAt), to = timestamp(entry.at);
    if (from !== undefined && to !== undefined && to > from) exclusions.push({ start: from, end: to });
  });
  const effective = tatIntervalDuration(subtractTatIntervals([{ start, end }], exclusions));
  return { total: end - start, effective, excluded: end - start - effective, closed };
}
