import type { CaseItem, TaskNode } from "./data";
import { caseVerificationTimes, taskLifecycleTimes } from "./caseTiming";
import type { ClosureRecord } from "./closures";
import { mergeTatIntervals, subtractTatIntervals, tatIntervalDuration, type TatInterval } from "./caseTatMath";

export interface DepartmentNode { id: string; name: string; parentId: string | null }
export const DEPARTMENT_TREE: DepartmentNode[] = [
  { id: "test", name: "测试中心", parentId: null },
  ...["PTE", "CP", "FT", "DA", "SLT"].map(name => ({ id: name, name, parentId: "test" })),
  { id: "pte-product", name: "产品测试组", parentId: "PTE" },
  { id: "pte-ddr", name: "DDR 测试小组", parentId: "pte-product" },
  { id: "pte-lpddr", name: "LPDDR 测试小组", parentId: "pte-product" },
  { id: "pte-dev", name: "测试开发组", parentId: "PTE" },
  { id: "quality", name: "工艺与质量中心", parentId: null },
  ...["PE", "QA", "EFA", "PKG"].map(name => ({ id: name, name, parentId: "quality" })),
  { id: "design", name: "设计与项目中心", parentId: null },
  ...["RD", "PM"].map(name => ({ id: name, name, parentId: "design" })),
];

// 已确认方案的细分组织演示归属，不修改任务原有的一级业务部门。
const DEMO_TASK_DEPARTMENTS: Record<string, string> = {
  "c001/t1": "pte-ddr",
  "c001/t1b": "pte-dev",
  "c001/t1c": "pte-product",
  "c001/t1c_r2": "pte-dev",
  "c001/t3c": "PTE",
};

export function taskDepartmentId(caseId: string, task: TaskNode) {
  return (task.department === "PTE" && DEMO_TASK_DEPARTMENTS[`${caseId}/${task.id}`]) || task.department || "未记录部门";
}

export function departmentTreeFor(departments: string[]): DepartmentNode[] {
  const known = new Set(DEPARTMENT_TREE.map(node => node.id));
  const unknown = [...new Set(departments)].filter(name => !known.has(name));
  return [...DEPARTMENT_TREE, ...(unknown.length ? [
    { id: "__other", name: "其他组织", parentId: null },
    ...unknown.map(name => ({ id: name, name, parentId: "__other" })),
  ] : [])];
}

export function departmentScope(tree: DepartmentNode[], id: string, includeChildren: boolean): Set<string> {
  const result = new Set([id]);
  if (includeChildren) tree.filter(node => node.parentId === id).forEach(child => {
    departmentScope(tree, child.id, true).forEach(value => result.add(value));
  });
  return result;
}

export function departmentPath(tree: DepartmentNode[], id: string): DepartmentNode[] {
  const node = tree.find(item => item.id === id);
  return node ? [...(node.parentId ? departmentPath(tree, node.parentId) : []), node] : [];
}

export interface DepartmentCaseRecord {
  caseItem: CaseItem;
  tasks: { task: TaskNode; departmentId: string; intervals: TatInterval[] | null }[];
}

function timestamp(value?: string) {
  const parsed = Date.parse(value ?? "");
  return Number.isFinite(parsed) ? parsed : undefined;
}

export function departmentCaseRecord(caseItem: CaseItem, tasks: TaskNode[], closure?: ClosureRecord, now = Date.now()): DepartmentCaseRecord {
  const end = timestamp(closure?.verificationEndedAt) ?? timestamp(closure?.closedAt) ?? now;
  const verification = caseVerificationTimes(closure);
  const verificationStart = timestamp(verification.start);
  const verificationEnd = timestamp(verification.end) ?? (closure?.state === "rootcause" ? end : undefined);
  const exclusions = verificationStart !== undefined && verificationEnd !== undefined && verificationEnd > verificationStart
    ? [{ start: verificationStart, end: verificationEnd }] : [];
  return {
    caseItem,
    tasks: tasks.filter(task => Boolean(task.code)).map(task => {
      const lifecycle = taskLifecycleTimes(task, new Date(end));
      const start = timestamp(lifecycle.createdAt);
      const finish = timestamp(task.status === "已完成" ? lifecycle.completedAt : lifecycle.end);
      const waits = (task.waitingFeedbackPeriods ?? []).filter(period => period.reason === "等待外部反馈").flatMap(period => {
        const from = timestamp(period.startedAt);
        const to = timestamp(period.endedAt) ?? end;
        return from !== undefined && to > from ? [{ start: from, end: to }] : [];
      });
      return {
        task, departmentId: taskDepartmentId(caseItem.id, task),
        intervals: start !== undefined && finish !== undefined && finish >= start
          ? subtractTatIntervals([{ start, end: finish }], [...exclusions, ...waits])
          : null,
      };
    }),
  };
}

export function medianCycleTime(values: number[]) {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

export function summarizeDepartment(records: DepartmentCaseRecord[], scope: Set<string>) {
  const grouped = new Map<string, { record: DepartmentCaseRecord; intervals: TatInterval[]; hasTime: boolean }>();
  records.forEach(record => {
    const tasks = record.tasks.filter(task => scope.has(task.departmentId));
    if (!tasks.length) return;
    const current = grouped.get(record.caseItem.id) ?? { record, intervals: [], hasTime: false };
    tasks.forEach(task => {
      if (task.intervals !== null) { current.hasTime = true; current.intervals.push(...task.intervals); }
    });
    grouped.set(record.caseItem.id, current);
  });
  const samples = [...grouped.values()].filter(item => item.hasTime)
    .map(item => tatIntervalDuration(mergeTatIntervals(item.intervals)));
  return {
    cases: [...grouped.values()].map(item => item.record), count: grouped.size, sampleCount: samples.length,
    average: samples.length ? samples.reduce((sum, value) => sum + value, 0) / samples.length : null,
    median: samples.length ? medianCycleTime(samples) : null,
  };
}
