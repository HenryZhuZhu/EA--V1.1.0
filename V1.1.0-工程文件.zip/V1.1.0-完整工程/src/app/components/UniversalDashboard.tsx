import { useState } from "react";
import * as Tabs from "@radix-ui/react-tabs";
import { ArrowLeft, BarChart3, Check, ChevronDown, ChevronRight, Clock3, Copy, GripVertical, LayoutDashboard, LineChart, List, MoreHorizontal, Package, PieChart, Plus, Search, Settings2, Sigma, Trash2, X } from "lucide-react";
import { departments, flattenTasks, mockCases, ownerToDepartment, type CaseItem } from "./data";
import { CaseTatDashboard } from "./CaseTatDashboard";
import { MultiPersonInput } from "./PersonInput";
import { ProductAnalysisRestored } from "./ProductAnalysisRestored";

type ChartType = "column" | "line" | "pie" | "list" | "metric";
type LegacyChartType = ChartType | "bar";
type Dimension = "status" | "level" | "urgency" | "owner" | "department" | "product" | "material" | "source" | "qualityTier" | "riskLevel";
type Metric = "caseCount" | "openCaseCount" | "overdueCaseCount" | "highRiskCaseCount" | "urgentCaseCount" | "taskCount" | "completedTaskCount" | "averageQualityScore" | "averageProgress" | "highQualityCaseCount" | "lowQualityCaseCount";
type FilterKey = "status" | "level" | "urgency" | "overdue" | "qualityScoreMin" | "qualityScoreMax" | "progressMin" | "progressMax";
type WidgetWidth = "third" | "half" | "full";
type ListField = "code" | "name" | "status" | "level" | "urgency" | "owner" | "product" | "material" | "source" | "departments" | "taskCount" | "completedTaskCount" | "progress" | "qualityScore" | "riskLevel" | "overdue" | "qualityIssues" | "updatedAt";
type SortBy = "default" | "qualityScore" | "progress" | "updatedAt";
type SortDirection = "asc" | "desc";
type ParticipationRole = "creator" | "owner" | "collaborator" | "participant";
interface PersonnelScope {
  roles: ParticipationRole[];
  people: string[];
  departments: string[];
}
interface BusinessScope {
  products: string[];
  platforms: string[];
  createdFrom: string;
  createdTo: string;
}

interface DashboardWidget {
  id: string;
  name: string;
  type: ChartType;
  dimension: Dimension;
  metric: Metric;
  filters: Partial<Record<FilterKey, string>>;
  personnelScope: PersonnelScope;
  businessScope: BusinessScope;
  width: WidgetWidth;
  listFields: ListField[];
  sortBy: SortBy;
  sortDirection: SortDirection;
  limit: number;
}
interface StoredWidget extends Omit<DashboardWidget, "type" | "width" | "listFields" | "personnelScope" | "businessScope" | "sortBy" | "sortDirection" | "limit"> {
  type: LegacyChartType;
  width?: WidgetWidth;
  listFields?: ListField[];
  personnelScope?: PersonnelScope;
  businessScope?: BusinessScope;
  sortBy?: SortBy;
  sortDirection?: SortDirection;
  limit?: number;
}
interface LegacyDashboard {
  id: string;
  name: string;
  widgets?: StoredWidget[];
  type?: LegacyChartType;
  dimension?: Dimension;
  metric?: Metric;
  filters?: Partial<Record<FilterKey, string>>;
}

const KEY = "ea_universal_dashboards_v1";
const DEFAULT_LIST_FIELDS: ListField[] = ["code", "name", "status", "owner", "taskCount"];
const CHART_TYPES: { value: ChartType; label: string; Icon: typeof BarChart3 }[] = [
  { value: "list", label: "列表", Icon: List },
  { value: "column", label: "柱状图", Icon: BarChart3 },
  { value: "line", label: "折线图", Icon: LineChart },
  { value: "pie", label: "饼图", Icon: PieChart },
  { value: "metric", label: "指标卡", Icon: Sigma },
];
const DIMENSIONS: { value: Dimension; label: string }[] = [
  { value: "status", label: "Case 状态" }, { value: "level", label: "Case 层级" }, { value: "urgency", label: "紧急程度" },
  { value: "owner", label: "Case Owner" }, { value: "department", label: "参与部门" }, { value: "product", label: "产品" },
  { value: "material", label: "物料" }, { value: "source", label: "来源" }, { value: "qualityTier", label: "质量等级" }, { value: "riskLevel", label: "风险等级" },
];
const METRICS: { value: Metric; label: string }[] = [
  { value: "caseCount", label: "Case 总数" }, { value: "openCaseCount", label: "Open Case 数" },
  { value: "overdueCaseCount", label: "逾期 Case 数" }, { value: "highRiskCaseCount", label: "高风险 Case 数" },
  { value: "urgentCaseCount", label: "非常紧急 Case 数" }, { value: "averageQualityScore", label: "平均质量评分" },
  { value: "averageProgress", label: "平均完成进度" }, { value: "highQualityCaseCount", label: "高质量 Case 数" },
  { value: "lowQualityCaseCount", label: "低质量 Case 数" }, { value: "taskCount", label: "任务总数" },
  { value: "completedTaskCount", label: "已完成任务数" },
];
const FILTERS: { key: FilterKey; label: string }[] = [
  { key: "status", label: "Case 状态" }, { key: "level", label: "Case 层级" }, { key: "urgency", label: "紧急程度" },
  { key: "overdue", label: "是否逾期" },
];
const LIST_FIELDS: { value: ListField; label: string; align?: "right" }[] = [
  { value: "code", label: "Case ID" }, { value: "name", label: "Case 名称" }, { value: "status", label: "状态" },
  { value: "level", label: "层级" }, { value: "urgency", label: "紧急程度" }, { value: "owner", label: "Owner" },
  { value: "product", label: "产品" }, { value: "material", label: "物料" }, { value: "source", label: "来源" },
  { value: "departments", label: "参与部门" }, { value: "taskCount", label: "任务总数", align: "right" },
  { value: "completedTaskCount", label: "已完成任务", align: "right" }, { value: "progress", label: "完成进度", align: "right" },
  { value: "qualityScore", label: "质量评分", align: "right" }, { value: "riskLevel", label: "风险等级" },
  { value: "overdue", label: "是否逾期" }, { value: "qualityIssues", label: "质量问题" }, { value: "updatedAt", label: "更新时间" },
];
const COLORS = ["#3370FF", "#14C9C9", "#2FC25B", "#F5A623", "#8B5CF6", "#F54A45", "#64748B", "#00A4FF"];
const PARTICIPATION_ROLES: { value: ParticipationRole; label: string }[] = [
  { value: "creator", label: "创建人" },
  { value: "owner", label: "Case Owner" },
  { value: "collaborator", label: "协作者" },
  { value: "participant", label: "任务负责人" },
];
const ALL_PARTICIPATION_ROLES = PARTICIPATION_ROLES.map(option => option.value);
function normalizedCaseStatus(status: string) {
  return ["已结束", "已关闭", "已归档"].includes(status) ? "已结案" : status;
}
function normalizeWidget(widget: StoredWidget, index: number): DashboardWidget {
  const filters = widget.filters || {};
  return {
    id: widget.id || crypto.randomUUID(),
    name: widget.name || `组件 ${index + 1}`,
    type: widget.type === "bar" ? "column" : widget.type,
    dimension: widget.dimension || "status",
    metric: widget.metric || "caseCount",
    filters: {
      status: filters.status,
      level: filters.level,
      urgency: filters.urgency,
      overdue: filters.overdue,
      qualityScoreMin: filters.qualityScoreMin,
      qualityScoreMax: filters.qualityScoreMax,
      progressMin: filters.progressMin,
      progressMax: filters.progressMax,
    },
    personnelScope: {
      roles: widget.personnelScope?.roles?.length ? widget.personnelScope.roles : [...ALL_PARTICIPATION_ROLES],
      people: widget.personnelScope?.people || [],
      departments: widget.personnelScope?.departments || [],
    },
    businessScope: {
      products: widget.businessScope?.products || [],
      platforms: widget.businessScope?.platforms || [],
      createdFrom: widget.businessScope?.createdFrom || "",
      createdTo: widget.businessScope?.createdTo || "",
    },
    width: widget.width || "half",
    listFields: widget.listFields?.length ? widget.listFields : [...DEFAULT_LIST_FIELDS],
    sortBy: widget.sortBy || "default",
    sortDirection: widget.sortDirection || "desc",
    limit: widget.limit || 20,
  };
}
function loadWidgets(): DashboardWidget[] {
  try {
    const parsed = JSON.parse(localStorage.getItem(KEY) || "[]") as LegacyDashboard[];
    if (!Array.isArray(parsed)) return [];
    const widgets = parsed.flatMap(item => item.widgets?.length ? item.widgets : item.type ? [{
      id: item.id, name: item.name, type: item.type, dimension: item.dimension || "status",
      metric: item.metric || "caseCount", filters: item.filters || {}, width: "full" as const,
    }] : []);
    return widgets.map(normalizeWidget);
  } catch {
    return [];
  }
}
function persistWidgets(widgets: DashboardWidget[]) {
  const now = new Date().toISOString();
  localStorage.setItem(KEY, JSON.stringify([{ id: "personal-workspace", name: "我的看板", widgets, createdAt: now, updatedAt: now }]));
}
function newWidget(type: ChartType, index: number): DashboardWidget {
  const label = CHART_TYPES.find(item => item.value === type)?.label ?? "组件";
  return {
    id: crypto.randomUUID(), name: `${label} ${index}`, type, dimension: "status", metric: "caseCount",
    filters: {}, personnelScope: { roles: [...ALL_PARTICIPATION_ROLES], people: [], departments: [] },
    businessScope: { products: [], platforms: [], createdFrom: "", createdTo: "" },
    width: type === "metric" ? "third" : "half", listFields: [...DEFAULT_LIST_FIELDS],
    sortBy: "default", sortDirection: "desc", limit: 20,
  };
}
function caseAnalytics(item: CaseItem) {
  const tasks = flattenTasks(item.tasks).filter(({ task }) => Boolean(task.code));
  const completed = tasks.filter(({ task }) => task.status === "已完成");
  const assigned = tasks.filter(({ task }) => task.owner && !["待指派", "待分派"].includes(task.owner));
  const progress = tasks.length ? Math.round(completed.length / tasks.length * 100) : 0;
  const completenessFields = [item.reason, item.background, item.impact, item.product, item.material, item.failStage, item.failMode];
  const completeness = completenessFields.filter(value => value && value !== "—").length / completenessFields.length * 40;
  const concluded = tasks.length ? tasks.filter(({ task }) => Boolean(task.conclusion?.trim())).length / tasks.length : 0;
  const valid = completed.length ? completed.filter(({ task }) => Boolean(task.validity)).length / completed.length : 0;
  const solution = item.solutionPath?.length ? 1 : 0;
  const validity = (concluded * 0.45 + valid * 0.35 + solution * 0.2) * 35;
  const collaboration = Math.min(25, (Math.min(item.departments.length, 4) / 4 * 8) + (Math.min(item.participants?.length ?? 0, 4) / 4 * 5) + (tasks.length ? assigned.length / tasks.length * 6 : 0) + (progress / 100 * 6));
  const qualityScore = Math.round(Math.min(100, completeness + validity + collaboration));
  const closed = normalizedCaseStatus(item.status) === "已结案";
  const dueTime = item.dueDate ? new Date(`${item.dueDate}T23:59:59`).getTime() : undefined;
  const overdue = !closed && (item.dueIn < 0 || Boolean(dueTime && dueTime < Date.now()));
  const highRisk = !closed && (overdue || qualityScore <= 45 || (item.urgency === "非常紧急" && progress < 50));
  const riskLevel = highRisk ? "高风险" : item.urgency === "非常紧急" || qualityScore < 70 ? "需关注" : "正常";
  const qualityTier = qualityScore >= 90 ? "高质量" : qualityScore <= 45 ? "低质量" : "一般";
  const qualityIssues = [
    !item.background || item.background === "—" ? "描述缺失" : "",
    !tasks.length ? "缺少任务拆解" : "",
    overdue ? "已逾期" : "",
    item.urgency === "非常紧急" && progress < 50 ? "紧急无进展" : "",
    tasks.length && concluded < 0.5 ? "结论不足" : "",
  ].filter(Boolean);
  return { tasks, completed, progress, qualityScore, qualityTier, overdue, highRisk, riskLevel, qualityIssues, open: !closed };
}
function dimensionValues(item: CaseItem, dimension: Dimension): string[] {
  if (dimension === "department") return item.departments?.length ? item.departments : ["未记录"];
  if (dimension === "status") return [normalizedCaseStatus(item.status)];
  if (dimension === "qualityTier") return [caseAnalytics(item).qualityTier];
  if (dimension === "riskLevel") return [caseAnalytics(item).riskLevel];
  const value = item[dimension as keyof CaseItem];
  return [typeof value === "string" && value.trim() ? value : "未记录"];
}
function metricValue(item: CaseItem, metric: Metric) {
  const analytics = caseAnalytics(item);
  if (metric === "caseCount") return 1;
  if (metric === "openCaseCount") return analytics.open ? 1 : 0;
  if (metric === "overdueCaseCount") return analytics.overdue ? 1 : 0;
  if (metric === "highRiskCaseCount") return analytics.highRisk ? 1 : 0;
  if (metric === "urgentCaseCount") return item.urgency === "非常紧急" ? 1 : 0;
  if (metric === "averageQualityScore") return analytics.qualityScore;
  if (metric === "averageProgress") return analytics.progress;
  if (metric === "highQualityCaseCount") return analytics.qualityTier === "高质量" ? 1 : 0;
  if (metric === "lowQualityCaseCount") return analytics.qualityTier === "低质量" ? 1 : 0;
  return metric === "taskCount" ? analytics.tasks.length : analytics.completed.length;
}
function isAverageMetric(metric: Metric) {
  return metric === "averageQualityScore" || metric === "averageProgress";
}
function casePeople(item: CaseItem) {
  const rows: { role: ParticipationRole; name: string; department: string }[] = [];
  const add = (role: ParticipationRole, name?: string, department?: string) => {
    const clean = name?.trim();
    if (!clean || clean === "待指派" || clean === "待分派") return;
    rows.push({ role, name: clean, department: department || ownerToDepartment[clean] || "未记录" });
  };
  add("creator", item.createdBy || item.owner);
  add("owner", item.owner);
  (item.participants ?? []).forEach(person => add("collaborator", person.name, person.department));
  flattenTasks(item.tasks).forEach(({ task }) => {
    add("participant", task.owner, task.department);
    (task.collaborators ?? []).forEach(person => add("participant", person.name, person.department));
  });
  return rows;
}
const DEPARTMENT_OPTIONS = [...new Set([...departments, ...mockCases.flatMap(item => casePeople(item).map(person => person.department))])].filter(item => item && item !== "未记录").sort((a, b) => a.localeCompare(b, "zh-CN"));
const PLATFORM_OPTIONS = [...new Set(mockCases.map(item => item.failPlatform).filter(item => item && item !== "—"))].sort((a, b) => a.localeCompare(b, "zh-CN"));
function matchesPersonnelScope(item: CaseItem, scope: PersonnelScope) {
  if (!scope.people.length && !scope.departments.length) return true;
  return casePeople(item).some(person =>
    (!scope.roles.length || scope.roles.includes(person.role))
    && (!scope.people.length || scope.people.includes(person.name))
    && (!scope.departments.length || scope.departments.includes(person.department)));
}
function matchesBusinessScope(item: CaseItem, scope: BusinessScope) {
  const created = item.createdAt.slice(0, 10);
  return (!scope.products.length || scope.products.includes(item.product || item.productId || ""))
    && (!scope.platforms.length || scope.platforms.includes(item.failPlatform))
    && (!scope.createdFrom || created >= scope.createdFrom)
    && (!scope.createdTo || created <= scope.createdTo);
}
function filteredCases(config: Pick<DashboardWidget, "filters" | "personnelScope" | "businessScope">) {
  return mockCases.filter(item => matchesPersonnelScope(item, config.personnelScope)
    && matchesBusinessScope(item, config.businessScope)
    && Object.entries(config.filters).every(([key, value]) => {
      if (!value) return true;
      const analytics = caseAnalytics(item);
      const actual = key === "status" ? normalizedCaseStatus(item.status)
        : key === "overdue" ? analytics.overdue ? "已逾期" : "未逾期"
        : String(item[key as keyof CaseItem] ?? "");
      if (key === "qualityScoreMin") return analytics.qualityScore >= Number(value);
      if (key === "qualityScoreMax") return analytics.qualityScore <= Number(value);
      if (key === "progressMin") return analytics.progress >= Number(value);
      if (key === "progressMax") return analytics.progress <= Number(value);
      return actual === value;
    }));
}
function aggregate(config: DashboardWidget) {
  const values = new Map<string, { total: number; count: number }>();
  filteredCases(config).forEach(item => dimensionValues(item, config.dimension).forEach(key => {
    const current = values.get(key) ?? { total: 0, count: 0 };
    values.set(key, { total: current.total + metricValue(item, config.metric), count: current.count + 1 });
  }));
  return [...values.entries()].map(([label, value]) => ({
    label,
    value: isAverageMetric(config.metric) && value.count ? Math.round(value.total / value.count) : value.total,
  })).sort((a, b) => b.value - a.value);
}
function optionsFor(key: FilterKey) {
  return [...new Set(mockCases.map(item => {
    const analytics = caseAnalytics(item);
    if (key === "status") return normalizedCaseStatus(item.status);
    if (key === "overdue") return analytics.overdue ? "已逾期" : "未逾期";
    return String(item[key] ?? "");
  }).filter(Boolean))].sort((a, b) => a.localeCompare(b, "zh-CN"));
}
function listFieldValue(item: CaseItem, field: ListField) {
  const analytics = caseAnalytics(item);
  if (field === "departments") return item.departments?.join("、") || "—";
  if (field === "taskCount") return analytics.tasks.length;
  if (field === "completedTaskCount") return analytics.completed.length;
  if (field === "progress") return `${analytics.progress}%`;
  if (field === "qualityScore") return analytics.qualityScore;
  if (field === "riskLevel") return analytics.riskLevel;
  if (field === "overdue") return analytics.overdue ? "已逾期" : "未逾期";
  if (field === "qualityIssues") return analytics.qualityIssues.join("、") || "—";
  if (field === "status") return normalizedCaseStatus(item.status);
  const value = item[field as keyof CaseItem];
  return typeof value === "string" && value.trim() ? value : "—";
}

function DashboardPreview({ config }: { config: DashboardWidget }) {
  const data = aggregate(config);
  const cases = filteredCases(config);
  const max = Math.max(...data.map(item => item.value), 1);
  const total = data.reduce((sum, item) => sum + item.value, 0);
  if (config.type === "metric") {
    const sum = cases.reduce((value, item) => value + metricValue(item, config.metric), 0);
    const value = isAverageMetric(config.metric) && cases.length ? Math.round(sum / cases.length) : sum;
    return <div className="flex h-[190px] flex-col items-center justify-center"><div className="text-5xl font-semibold tracking-tight text-slate-900">{value}</div><div className="mt-3 text-xs text-slate-500">{METRICS.find(item => item.value === config.metric)?.label}</div></div>;
  }
  if (config.type === "list") {
    const fields = config.listFields.length ? config.listFields : DEFAULT_LIST_FIELDS;
    const visibleCases = [...cases].sort((a, b) => {
      if (config.sortBy === "default") return 0;
      const value = (item: CaseItem) => config.sortBy === "qualityScore" ? caseAnalytics(item).qualityScore : config.sortBy === "progress" ? caseAnalytics(item).progress : new Date(item.updatedAt).getTime();
      return (value(a) - value(b)) * (config.sortDirection === "asc" ? 1 : -1);
    }).slice(0, config.limit);
    return <div className="max-h-[300px] overflow-auto border-y border-slate-100"><table className="min-w-full whitespace-nowrap text-left text-xs"><thead className="sticky top-0 bg-slate-50 text-slate-500"><tr>{fields.map(field => { const definition = LIST_FIELDS.find(item => item.value === field)!; return <th key={field} className={`px-3 py-2 font-medium ${definition.align === "right" ? "text-right" : ""}`}>{definition.label}</th>; })}</tr></thead><tbody>{visibleCases.map(item => <tr key={item.id} className="border-t border-slate-100 hover:bg-slate-50/70">{fields.map(field => { const definition = LIST_FIELDS.find(option => option.value === field)!; return <td key={field} className={`max-w-[240px] truncate px-3 py-2.5 ${field === "code" ? "font-mono text-slate-500" : ""} ${definition.align === "right" ? "text-right" : ""}`}>{listFieldValue(item, field)}</td>; })}</tr>)}</tbody></table></div>;
  }
  if (!data.length) return <div className="grid h-[220px] place-items-center text-xs text-slate-400">暂无数据</div>;
  if (config.type === "pie") {
    let offset = 0;
    const gradient = data.map((item, index) => { const start = offset; offset += total ? item.value / total * 100 : 0; return `${COLORS[index % COLORS.length]} ${start}% ${offset}%`; }).join(", ");
    return <div className="flex min-h-[230px] items-center justify-center gap-8"><div className="relative h-40 w-40 rounded-full" style={{ background: `conic-gradient(${gradient})` }}><div className="absolute inset-10 grid place-items-center rounded-full bg-white text-xl font-semibold">{total}</div></div><div className="max-h-[220px] space-y-2 overflow-auto">{data.map((item, index) => <div key={item.label} className="flex min-w-[150px] items-center gap-2 text-xs"><span className="h-2.5 w-2.5 rounded-sm" style={{ background: COLORS[index % COLORS.length] }} /><span className="min-w-0 flex-1 truncate text-slate-600">{item.label}</span><span className="font-medium">{item.value}</span></div>)}</div></div>;
  }
  if (config.type === "line") {
    const points = data.map((item, index) => ({ ...item, x: data.length === 1 ? 50 : index / (data.length - 1) * 100, y: 90 - item.value / max * 75 }));
    return <div className="relative h-[240px] px-4 pt-5"><svg viewBox="0 0 100 100" preserveAspectRatio="none" className="h-[190px] w-full overflow-visible"><line x1="0" y1="90" x2="100" y2="90" stroke="#E2E8F0" strokeWidth=".5" /><polyline fill="none" stroke="#3370FF" strokeWidth="2" vectorEffect="non-scaling-stroke" points={points.map(point => `${point.x},${point.y}`).join(" ")} />{points.map(point => <circle key={point.label} cx={point.x} cy={point.y} r="1.7" fill="white" stroke="#3370FF" strokeWidth="1" vectorEffect="non-scaling-stroke" />)}</svg><div className="absolute inset-x-4 bottom-1 flex justify-between text-[9px] text-slate-400">{data.map(item => <span key={item.label} className="max-w-[70px] truncate">{item.label}</span>)}</div></div>;
  }
  return <div className="flex min-h-[230px] items-end gap-3 overflow-x-auto border-b border-slate-200 px-3 pt-6">{data.map((item, index) => <div key={item.label} className="flex h-[200px] min-w-[48px] flex-1 flex-col items-center justify-end gap-1"><span className="text-[10px] font-medium">{item.value}</span><div className="w-full max-w-[54px] rounded-t" style={{ height: `${Math.max(4, item.value / max * 155)}px`, background: COLORS[index % COLORS.length] }} /><span className="h-8 text-center text-[9px] text-slate-500">{item.label}</span></div>)}</div>;
}

function WidgetCard({ widget, menuOpen, dragging, onMenu, onConfigure, onDuplicate, onDelete, onDragStart, onDragEnter, onDragEnd }: {
  widget: DashboardWidget; menuOpen: boolean; dragging: boolean; onMenu: () => void; onConfigure: () => void; onDuplicate: () => void; onDelete: () => void;
  onDragStart: (event: React.DragEvent<HTMLButtonElement>) => void; onDragEnter: () => void; onDragEnd: () => void;
}) {
  const col = widget.width === "full" ? "col-span-6" : widget.width === "third" ? "col-span-2" : "col-span-3";
  return <section onDragOver={event => event.preventDefault()} onDragEnter={onDragEnter} className={`${col} relative min-w-0 rounded-lg border border-slate-200 bg-white shadow-[0_1px_2px_rgba(15,23,42,.04)] transition ${dragging ? "scale-[.99] opacity-45" : ""}`}>
    <header className="flex h-11 items-center border-b border-slate-100 px-3"><button type="button" draggable aria-label={`拖动 ${widget.name} 调整顺序`} title="拖动调整顺序" onDragStart={onDragStart} onDragEnd={onDragEnd} className="mr-1 grid h-7 w-7 cursor-grab place-items-center rounded text-slate-300 hover:bg-slate-100 hover:text-slate-600 active:cursor-grabbing"><GripVertical size={15} /></button><h4 className="truncate text-sm font-medium text-slate-800">{widget.name}</h4><button aria-label={`${widget.name} 更多操作`} onClick={onMenu} className="ml-auto grid h-7 w-7 place-items-center rounded text-slate-400 hover:bg-slate-100 hover:text-slate-700"><MoreHorizontal size={16} /></button></header>
    {menuOpen && <div className="absolute right-3 top-9 z-20 w-28 rounded-lg border border-slate-200 bg-white p-1 shadow-xl"><button onClick={onConfigure} className="flex h-8 w-full items-center gap-2 rounded px-2 text-xs text-slate-600 hover:bg-slate-50"><Settings2 size={12} />配置</button><button onClick={onDuplicate} className="flex h-8 w-full items-center gap-2 rounded px-2 text-xs text-slate-600 hover:bg-slate-50"><Copy size={12} />复制</button><button onClick={onDelete} className="flex h-8 w-full items-center gap-2 rounded px-2 text-xs text-red-500 hover:bg-red-50"><Trash2 size={12} />删除</button></div>}
    <div className="p-4"><DashboardPreview config={widget} /></div>
  </section>;
}

function ScopeMultiSelect({ label, options, selected, disabled = false, placeholder, onToggle }: {
  label: string;
  options: string[];
  selected: string[];
  disabled?: boolean;
  placeholder: string;
  onToggle: (value: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const matches = options.filter(option => !query.trim() || option.toLowerCase().includes(query.trim().toLowerCase()));
  const summary = selected.length === 0 ? placeholder : selected.length === 1 ? selected[0] : `已选 ${selected.length} 项`;
  return <div className="relative" onBlur={event => {
    if (!event.currentTarget.contains(event.relatedTarget as Node | null)) {
      setOpen(false);
      setQuery("");
    }
  }}>
    <div className="mb-1 text-[11px] text-slate-500">{label}</div>
    <button type="button" disabled={disabled} onClick={() => setOpen(value => !value)} className="flex h-9 w-full items-center justify-between rounded-md border border-slate-200 bg-white px-3 text-left text-xs text-slate-600 disabled:cursor-not-allowed disabled:bg-slate-50 disabled:text-slate-300"><span className="truncate">{summary}</span><ChevronDown size={13} className={`shrink-0 text-slate-400 transition ${open ? "rotate-180" : ""}`} /></button>
    {open && !disabled && <div className="absolute left-0 right-0 top-[58px] z-50 overflow-hidden rounded-lg border border-slate-200 bg-white shadow-xl">
      <div className="relative border-b border-slate-100 p-2"><Search size={13} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" /><input autoFocus value={query} onChange={event => setQuery(event.target.value)} placeholder={`搜索${label}`} className="h-8 w-full rounded-md border border-slate-200 pl-8 pr-2 text-xs outline-none focus:border-[#3370FF]" /></div>
      <div className="max-h-52 overflow-auto py-1">{matches.length ? matches.map(option => {
        const checked = selected.includes(option);
        return <button key={option} type="button" onClick={() => onToggle(option)} className={`flex w-full items-center gap-2 px-3 py-2 text-left text-xs hover:bg-slate-50 ${checked ? "bg-blue-50/60 text-[#3370FF]" : "text-slate-600"}`}><span className={`grid h-4 w-4 shrink-0 place-items-center rounded border ${checked ? "border-[#3370FF] bg-[#3370FF] text-white" : "border-slate-300"}`}>{checked && <Check size={10} />}</span><span className="truncate">{option}</span></button>;
      }) : <div className="px-3 py-6 text-center text-xs text-slate-400">未找到匹配项</div>}</div>
    </div>}
  </div>;
}

function ConfigurationDrawer({ widget, onChange, onClose }: { widget: DashboardWidget; onChange: (widget: DashboardWidget) => void; onClose: () => void }) {
  const patch = (value: Partial<DashboardWidget>) => onChange({ ...widget, ...value });
  const [personnelMode, setPersonnelMode] = useState<"all" | "department" | "person">(
    widget.personnelScope.people.length ? "person" : widget.personnelScope.departments.length ? "department" : "all",
  );
  const toggleScopeValue = <K extends keyof PersonnelScope>(key: K, value: PersonnelScope[K][number]) => {
    const current = widget.personnelScope[key] as string[];
    if (key === "roles" && current.includes(value) && current.length === 1) return;
    patch({ personnelScope: { ...widget.personnelScope, [key]: current.includes(value) ? current.filter(item => item !== value) : [...current, value] } });
  };
  const toggleBusinessValue = (key: "products" | "platforms", value: string) => {
    const current = widget.businessScope[key];
    const next = current.includes(value) ? current.filter(item => item !== value) : [...current, value];
    if (key === "platforms") {
      const available = new Set(mockCases.filter(item => next.includes(item.failPlatform)).map(item => item.product || item.productId).filter(Boolean));
      patch({ businessScope: { ...widget.businessScope, platforms: next, products: widget.businessScope.products.filter(item => available.has(item)) } });
      return;
    }
    patch({ businessScope: { ...widget.businessScope, products: next } });
  };
  const availableProducts = widget.businessScope.platforms.length
    ? [...new Set(mockCases.filter(item => widget.businessScope.platforms.includes(item.failPlatform)).map(item => item.product || item.productId).filter((item): item is string => Boolean(item && item !== "—")))].sort((a, b) => a.localeCompare(b, "zh-CN"))
    : [];
  const changePersonnelMode = (mode: "all" | "department" | "person") => {
    setPersonnelMode(mode);
    patch({
      personnelScope: {
        ...widget.personnelScope,
        roles: mode === "all" ? [] : widget.personnelScope.roles.length ? widget.personnelScope.roles : [...ALL_PARTICIPATION_ROLES],
        people: mode === "person" ? widget.personnelScope.people : [],
        departments: mode === "department" ? widget.personnelScope.departments : [],
      },
    });
  };
  const selectedFields = widget.listFields.length ? widget.listFields : DEFAULT_LIST_FIELDS;
  const toggleField = (field: ListField) => {
    if (selectedFields.includes(field)) {
      if (selectedFields.length > 1) patch({ listFields: selectedFields.filter(item => item !== field) });
    } else patch({ listFields: [...selectedFields, field] });
  };
  return <aside role="dialog" aria-modal="false" aria-label="配置组件" className="fixed inset-y-0 right-0 z-[170] flex w-[420px] flex-col border-l border-slate-200 bg-white shadow-[-12px_0_30px_rgba(15,23,42,.12)]">
    <header className="flex h-14 items-center border-b border-slate-200 px-5"><h3 className="text-sm font-semibold">配置组件</h3><button onClick={onClose} className="ml-auto grid h-8 w-8 place-items-center rounded hover:bg-slate-100"><X size={16} /></button></header>
    <div className="min-h-0 flex-1 space-y-6 overflow-auto p-5">
      <section><h4 className="mb-3 text-xs font-semibold text-slate-800">基础设置</h4><label className="block text-xs text-slate-500">组件名称<input aria-label="组件名称" value={widget.name} onChange={event => patch({ name: event.target.value })} className="mt-1 h-9 w-full rounded-md border border-slate-200 px-3 text-sm outline-none focus:border-[#3370FF]" /></label><div className="mt-3 grid grid-cols-5 gap-1.5">{CHART_TYPES.map(({ value, label, Icon }) => <button key={value} onClick={() => patch({ type: value })} className={`flex h-14 flex-col items-center justify-center gap-1 rounded-md border text-[10px] ${widget.type === value ? "border-[#3370FF] bg-blue-50 text-[#3370FF]" : "border-slate-200 text-slate-500"}`}><Icon size={15} />{label}</button>)}</div></section>
      <section>
        <h4 className="text-xs font-semibold text-slate-800">数据范围</h4>
        <p className="mt-1 text-[10px] text-slate-400">先确定人员范围及其与 Case 的关系，再叠加产品、平台和时间等业务条件</p>
        <div className="mt-4 space-y-4">
          <div>
            <div className="mb-2 text-[11px] font-medium text-slate-500">人员范围</div>
            <div className="inline-flex rounded-md bg-slate-100 p-1">{([
              { value: "all" as const, label: "不限人员" },
              { value: "department" as const, label: "按部门" },
              { value: "person" as const, label: "按人员" },
            ]).map(option => <button key={option.value} type="button" aria-pressed={personnelMode === option.value} onClick={() => changePersonnelMode(option.value)} className={`h-8 rounded px-4 text-[11px] ${personnelMode === option.value ? "bg-white font-medium text-[#3370FF] shadow-sm" : "text-slate-500"}`}>{option.label}</button>)}</div>
          </div>
          <>
            {personnelMode === "department" && <div>
              <ScopeMultiSelect label="选择部门" options={DEPARTMENT_OPTIONS} selected={widget.personnelScope.departments} placeholder="请选择部门" onToggle={value => toggleScopeValue("departments", value)} />
            </div>}
            {personnelMode === "person" && <div>
              <div className="mb-2 flex items-center justify-between text-[11px] font-medium text-slate-500"><span>选择具体人员</span>{widget.personnelScope.people.length > 0 && <span className="font-normal text-[#3370FF]">已选 {widget.personnelScope.people.length} 人</span>}</div>
              <MultiPersonInput value={widget.personnelScope.people} onChange={people => patch({ personnelScope: { ...widget.personnelScope, people } })} placeholder="输入姓名或部门搜索人员" selectedInside />
            </div>}
          </>
          {personnelMode !== "all" && <div>
            <div className="mb-2 flex items-center justify-between text-[11px] font-medium text-slate-500"><span>参与方式</span><span className="font-normal text-slate-400">默认包含全部参与方式</span></div>
            <div className="flex flex-wrap gap-2">{PARTICIPATION_ROLES.map(option => { const selected = widget.personnelScope.roles.includes(option.value); return <button key={option.value} type="button" aria-pressed={selected} onClick={() => toggleScopeValue("roles", option.value)} className={`inline-flex h-8 items-center gap-1 rounded-md border px-2.5 text-[11px] ${selected ? "border-[#3370FF] bg-blue-50 text-[#3370FF]" : "border-slate-200 text-slate-500 hover:border-slate-300"}`}>{selected && <Check size={11} />}{option.label}</button>; })}</div>
          </div>}
        </div>
        <div className="mt-4 border-t border-slate-100 pt-4">
          <div className="mb-3 text-[11px] font-medium text-slate-500">业务范围</div>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <ScopeMultiSelect label="平台" options={PLATFORM_OPTIONS} selected={widget.businessScope.platforms} placeholder="请选择平台" onToggle={value => toggleBusinessValue("platforms", value)} />
              <ScopeMultiSelect label="产品" options={availableProducts} selected={widget.businessScope.products} disabled={!widget.businessScope.platforms.length} placeholder={widget.businessScope.platforms.length ? "请选择产品" : "请先选择平台"} onToggle={value => toggleBusinessValue("products", value)} />
            </div>
            <div><div className="mb-2 text-[11px] text-slate-500">Case 创建时间</div><div className="grid grid-cols-[1fr_auto_1fr] items-center gap-2"><input aria-label="开始日期" type="date" value={widget.businessScope.createdFrom} max={widget.businessScope.createdTo || undefined} onChange={event => patch({ businessScope: { ...widget.businessScope, createdFrom: event.target.value } })} className="h-8 rounded-md border border-slate-200 px-2 text-xs text-slate-600" /><span className="text-[10px] text-slate-400">至</span><input aria-label="结束日期" type="date" value={widget.businessScope.createdTo} min={widget.businessScope.createdFrom || undefined} onChange={event => patch({ businessScope: { ...widget.businessScope, createdTo: event.target.value } })} className="h-8 rounded-md border border-slate-200 px-2 text-xs text-slate-600" /></div></div>
          </div>
        </div>
        <div className="mt-4 border-t border-slate-100 pt-4">
          <div className="mb-2 text-[11px] font-medium text-slate-500">Case 条件</div>
          <div className="grid grid-cols-2 gap-2">{FILTERS.map(filter => <label key={filter.key} className="text-[11px] text-slate-500">{filter.label}<select value={widget.filters[filter.key] ?? ""} onChange={event => patch({ filters: { ...widget.filters, [filter.key]: event.target.value || undefined } })} className="mt-1 h-8 w-full rounded-md border border-slate-200 bg-white px-2 text-xs"><option value="">全部</option>{optionsFor(filter.key).map(option => <option key={option}>{option}</option>)}</select></label>)}</div>
          <div className="mt-3 grid grid-cols-2 gap-3">
            <div><div className="mb-1 text-[11px] text-slate-500">质量评分区间</div><div className="grid grid-cols-[1fr_auto_1fr] items-center gap-2"><input aria-label="最低质量评分" type="number" min="0" max="100" placeholder="0" value={widget.filters.qualityScoreMin ?? ""} onChange={event => patch({ filters: { ...widget.filters, qualityScoreMin: event.target.value || undefined } })} className="h-8 min-w-0 rounded-md border border-slate-200 px-2 text-xs" /><span className="text-[10px] text-slate-400">至</span><input aria-label="最高质量评分" type="number" min="0" max="100" placeholder="100" value={widget.filters.qualityScoreMax ?? ""} onChange={event => patch({ filters: { ...widget.filters, qualityScoreMax: event.target.value || undefined } })} className="h-8 min-w-0 rounded-md border border-slate-200 px-2 text-xs" /></div></div>
            <div><div className="mb-1 text-[11px] text-slate-500">完成进度区间</div><div className="grid grid-cols-[1fr_auto_1fr] items-center gap-2"><input aria-label="最低完成进度" type="number" min="0" max="100" placeholder="0" value={widget.filters.progressMin ?? ""} onChange={event => patch({ filters: { ...widget.filters, progressMin: event.target.value || undefined } })} className="h-8 min-w-0 rounded-md border border-slate-200 px-2 text-xs" /><span className="text-[10px] text-slate-400">至</span><input aria-label="最高完成进度" type="number" min="0" max="100" placeholder="100" value={widget.filters.progressMax ?? ""} onChange={event => patch({ filters: { ...widget.filters, progressMax: event.target.value || undefined } })} className="h-8 min-w-0 rounded-md border border-slate-200 px-2 text-xs" /></div></div>
          </div>
        </div>
      </section>
      <section><h4 className="mb-3 text-xs font-semibold text-slate-800">数据维度</h4>{widget.type === "list" ? <><div className="flex flex-wrap gap-2">{LIST_FIELDS.map(field => { const selected = selectedFields.includes(field.value); return <button key={field.value} aria-pressed={selected} onClick={() => toggleField(field.value)} className={`inline-flex h-8 items-center gap-1 rounded-md border px-2.5 text-[11px] ${selected ? "border-[#3370FF] bg-blue-50 text-[#3370FF]" : "border-slate-200 text-slate-500"}`}>{selected && <Check size={11} />}{field.label}</button>; })}</div><div className="mt-3 grid grid-cols-3 gap-2"><label className="text-[11px] text-slate-500">排序依据<select value={widget.sortBy} onChange={event => patch({ sortBy: event.target.value as SortBy })} className="mt-1 h-8 w-full rounded-md border border-slate-200 bg-white px-2 text-xs"><option value="default">默认</option><option value="qualityScore">质量评分</option><option value="progress">完成进度</option><option value="updatedAt">更新时间</option></select></label><label className="text-[11px] text-slate-500">排序方式<select value={widget.sortDirection} onChange={event => patch({ sortDirection: event.target.value as SortDirection })} className="mt-1 h-8 w-full rounded-md border border-slate-200 bg-white px-2 text-xs"><option value="desc">从高到低</option><option value="asc">从低到高</option></select></label><label className="text-[11px] text-slate-500">显示数量<select value={widget.limit} onChange={event => patch({ limit: Number(event.target.value) })} className="mt-1 h-8 w-full rounded-md border border-slate-200 bg-white px-2 text-xs">{[5, 10, 20, 50].map(value => <option key={value} value={value}>{value} 条</option>)}</select></label></div></> : <div className="grid grid-cols-2 gap-3">{widget.type !== "metric" && <label className="text-xs text-slate-500">分类维度<select value={widget.dimension} onChange={event => patch({ dimension: event.target.value as Dimension })} className="mt-1 h-9 w-full rounded-md border border-slate-200 bg-white px-2 text-sm">{DIMENSIONS.map(item => <option key={item.value} value={item.value}>{item.label}</option>)}</select></label>}<label className="text-xs text-slate-500">统计指标<select value={widget.metric} onChange={event => patch({ metric: event.target.value as Metric })} className="mt-1 h-9 w-full rounded-md border border-slate-200 bg-white px-2 text-sm">{METRICS.map(item => <option key={item.value} value={item.value}>{item.label}</option>)}</select></label></div>}</section>
      <section><h4 className="mb-3 text-xs font-semibold text-slate-800">组件宽度</h4><div className="inline-flex rounded-md bg-slate-100 p-1">{([{ value: "third", label: "1/3 行" }, { value: "half", label: "1/2 行" }, { value: "full", label: "整行" }] as { value: WidgetWidth; label: string }[]).map(option => <button key={option.value} onClick={() => patch({ width: option.value })} className={`h-8 rounded px-4 text-xs ${widget.width === option.value ? "bg-white font-medium text-[#3370FF] shadow-sm" : "text-slate-500"}`}>{option.label}</button>)}</div></section>
    </div>
    <footer className="flex justify-end border-t border-slate-200 p-4"><button onClick={onClose} className="h-9 rounded-md bg-[#3370FF] px-5 text-sm text-white">完成</button></footer>
  </aside>;
}

export function UniversalDashboard({ onOpenCase, onOpenTask }: { onOpenCase: (id: string) => void; onOpenTask: (caseId: string, taskId: string) => void }) {
  const [view, setView] = useState<"department" | "product">("department");

  return <section aria-label="万能看板" className="mx-auto w-full max-w-[1500px] px-6 py-7">
    <header className="flex items-center border-b border-slate-200">
      <div className="flex items-center gap-2 pb-4"><LayoutDashboard size={19} className="text-[#3370FF]" /><h2 className="text-lg font-semibold">万能看板</h2></div>
      <div className="ml-auto flex items-center gap-3 pb-3">
        {view === "product" && <div id="product-analysis-global-tools" />}
        <Tabs.Root value={view} onValueChange={value => { if (value === "department" || value === "product") setView(value); }}>
          <Tabs.List aria-label="万能看板视角" className="inline-flex shrink-0 gap-1 rounded-lg bg-slate-100 p-1">
            {([{ value: "department", label: "部门视角", Icon: LayoutDashboard }, { value: "product", label: "产品视角", Icon: Package }] as const).map(({ value, label, Icon }) => <Tabs.Trigger key={value} value={value} className="inline-flex h-8 items-center gap-1.5 whitespace-nowrap rounded-md px-3 text-xs text-slate-500 data-[state=active]:bg-white data-[state=active]:font-medium data-[state=active]:text-[#0052D9] data-[state=active]:shadow-sm"><Icon size={12} />{label}</Tabs.Trigger>)}
          </Tabs.List>
        </Tabs.Root>
      </div>
    </header>
    <div className="mt-5">
      {view === "department" ? <CaseTatDashboard onOpenCase={onOpenCase} onOpenTask={onOpenTask} /> : <ProductAnalysisRestored onOpenCase={onOpenCase} onOpenTask={onOpenTask} cycleTimeCards />}
    </div>
  </section>;
}
