import { Ban, CheckCheck, Pause, Play, RotateCcw, XCircle } from "lucide-react";

export function TaskDetailActions({ status, recoveryTools, onCancel, onAccept, onReject, onWait, onResume, onTerminate, onComplete, completeForm, terminateReason, completeReason, responseReason, waitingReason, completeLabel = "完成", hint }: {
  status: "待接受" | "进行中" | "等待反馈" | "整改中" | "已拒绝" | "已完成" | "已中止";
  recoveryTools?: import("react").ReactNode;
  onCancel: () => void;
  onAccept?: () => void;
  onReject?: () => void;
  onWait?: () => void;
  onResume?: () => void;
  onTerminate: () => void;
  onComplete?: () => void;
  completeForm?: string;
  terminateReason?: string;
  completeReason?: string;
  responseReason?: string;
  waitingReason?: string;
  completeLabel?: string;
  hint: string;
}) {
  return <footer aria-label="任务操作" className="sticky bottom-0 z-20 -mx-6 flex items-center gap-3 border-t border-slate-200 bg-white/95 px-6 py-3 backdrop-blur">
    <span className="min-w-0 truncate text-[11px] text-slate-400" title={hint}>{hint}</span>
    <div className="ml-auto flex shrink-0 items-center gap-2">
      {recoveryTools}
      <button type="button" onClick={onCancel} title="返回任务列表，不改变任务状态" className="h-9 rounded-md border border-slate-200 bg-white px-4 text-sm text-slate-600 hover:bg-slate-50">取消</button>
      {status === "待接受" && <>
        <button type="button" onClick={onReject} disabled={Boolean(responseReason)} title={responseReason || "拒绝任务并填写理由"} className="inline-flex h-9 items-center gap-1.5 rounded-md border border-rose-200 bg-rose-50/60 px-4 text-sm text-rose-600 hover:bg-rose-50 disabled:cursor-not-allowed disabled:opacity-40"><XCircle size={14} />拒绝</button>
        <button type="button" onClick={onAccept} disabled={Boolean(responseReason)} title={responseReason || "接受任务并开始执行"} className="inline-flex h-9 items-center gap-1.5 rounded-md bg-[#0052D9] px-5 text-sm text-white hover:bg-[#003FA8] disabled:cursor-not-allowed disabled:opacity-40"><Play size={14} />接受并开始</button>
      </>}
      {status === "进行中" && <>
        <button type="button" onClick={onWait} disabled={Boolean(waitingReason)} title={waitingReason || "暂停推进并开始记录等待反馈时间"} className="inline-flex h-9 items-center gap-1.5 rounded-md border border-amber-200 bg-amber-50/70 px-4 text-sm text-amber-700 hover:bg-amber-100 disabled:cursor-not-allowed disabled:opacity-40"><Pause size={14} />等待反馈</button>
        <button type="button" onClick={onTerminate} disabled={Boolean(terminateReason)} title={terminateReason || "填写中止原因并停止任务"} className="inline-flex h-9 items-center gap-1.5 rounded-md border border-red-200 bg-red-50/60 px-4 text-sm text-red-600 hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-40"><Ban size={14} />中止</button>
        <button type={completeForm ? "submit" : "button"} form={completeForm} onClick={onComplete} disabled={Boolean(completeReason)} title={completeReason || "保存结果并标记任务已完成"} className="inline-flex h-9 items-center gap-1.5 rounded-md bg-gradient-to-r from-[#00B578] to-[#0F9F6E] px-5 text-sm text-white hover:shadow-md disabled:cursor-not-allowed disabled:opacity-40"><CheckCheck size={15} />{completeLabel}</button>
      </>}
      {status === "等待反馈" && <button type="button" onClick={onResume} disabled={Boolean(waitingReason)} title={waitingReason || "收到反馈并恢复任务推进"} className="inline-flex h-9 items-center gap-1.5 rounded-md bg-[#0052D9] px-5 text-sm text-white hover:bg-[#003FA8] disabled:cursor-not-allowed disabled:opacity-40"><RotateCcw size={14} />重新启动</button>}
      {status === "整改中" && <button type={completeForm ? "submit" : "button"} form={completeForm} onClick={onComplete} disabled={Boolean(completeReason)} title={completeReason || "保存修改并重新提交任务"} className="inline-flex h-9 items-center gap-1.5 rounded-md bg-gradient-to-r from-[#F59E0B] to-[#EA580C] px-5 text-sm text-white hover:shadow-md disabled:cursor-not-allowed disabled:opacity-40"><CheckCheck size={15} />重新提交</button>}
    </div>
  </footer>;
}