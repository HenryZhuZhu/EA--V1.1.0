import type { TaskNode } from "./data";
import type { WaitingTask } from "./waitingTasks";

export type VerificationDisplayNode =
  | { kind: "verification"; parent: TaskNode }
  | { kind: "specialTask"; parent: TaskNode; specialTask: WaitingTask };

// 展示节点参与布局，但不写入普通任务树，避免影响执行任务数量和完成率。
export function verificationMindMap(nodes: TaskNode[]) {
  const displayNodes = new Map<string, VerificationDisplayNode>();
  const project = (items: TaskNode[]): TaskNode[] => items.map(parent => {
    const children = parent.children ? project(parent.children) : [];
    if (!parent.code || (!parent.verificationNode && !parent.waitingTasks?.length)) {
      return { ...parent, children };
    }
    const id = `verification-view:${parent.id}`;
    const specialTasks = (parent.waitingTasks ?? []).map(specialTask => {
      const taskId = `special-view:${parent.id}:${specialTask.id}`;
      displayNodes.set(taskId, { kind: "specialTask", parent, specialTask });
      return {
        id: taskId, code: specialTask.id, title: specialTask.title, owner: specialTask.owner,
        department: parent.department, urgency: parent.urgency, status: specialTask.status,
        progress: specialTask.status === "已完成" ? 100 : 0,
      } satisfies TaskNode;
    });
    displayNodes.set(id, { kind: "verification", parent });
    children.push({
      id, title: "验证", owner: parent.owner, department: parent.department, urgency: parent.urgency,
      status: "进行中", progress: 0, children: specialTasks,
    });
    return { ...parent, children };
  });
  return { tasks: project(nodes), displayNodes };
}
